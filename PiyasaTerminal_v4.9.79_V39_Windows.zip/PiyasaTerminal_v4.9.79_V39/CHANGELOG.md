## 4.9.79 PRO
- Deneysel BIST günlük kalkış radarı ve bağımsız geçmiş strateji testi (Analiz menüsü).
- GitHub varsayılan yayın kanalı: asistan71/PiyasaTerminal-Windows; yayın henüz yapılmadı.
- Mevcut puanlama ve grafik motoru değiştirilmedi.

## v4.9.77
- Mum gruplari icin sinirli onbellek; FVRP fiyat kenarlari onceden hesaplanir.
- Ortak FRVP ve pozisyon tutamac degisiklikleri kaynak kayda iletilir.

## v4.9.76
- Görünür alan dışında kalan sınırlı şekillerin geometrisi atlanır; aynı sürükleme koordinatları yeniden çizilmez.
- Ortak çizimlerin genel nokta tutamaçlarıyla taşıma/boyutlandırma değişiklikleri kaynak kayda yazılır.
- Stil şablonlarını yeniden adlandırma ve silme eklendi.

## v4.9.75
- Grafik sekmesinde üst uygulama başlığı gizlenir; sol menü ve grafik araçları korunur.
- İsimli birden fazla çizim stil şablonu; eski tek şablon Varsayılan olarak taşınır.
- Paylaşılan çizimlere çift tıklayarak kaynak çizimin stilini ve görünürlük kapsamını düzenleme. Geometri kaynak zaman diliminde düzenlenir.
- FVRP önbelleği 64 kayıtla sınırlandı; boş fiyat sınırları için koruma eklendi.

## v4.9.74
- Etkileşimli grafikte filigran mumların arkasına taşındı; renk zemin ile %15 nötr gri karışımından hesaplanıyor.
- Alarm geçmişine CSV aktarımı, çizim özelliklerine kalıcı tek stil şablonu eklendi.
- Paylaşılan çizim yoksa tarih eşleştirme işlemi atlanıyor.
- Kilitli çizim özellikleri korunuyor; iptal edilen özellikler kaydı değiştirmiyor.

## v4.9.73
- Zaman dilimleri arasında çizimleri kaynağı değiştirmeden gösterme; paylaşılan çizimler yalnızca görüntülenir, USD hariç.
- Alarm geçmişi JSON dosyasına kalıcı olarak yazılır.
- Çizim özelliklerine sekiz renkli hızlı palet eklendi.

## v4.9.72
- Delete ve Ctrl+C/Ctrl+V çizim kısayolları etkinleştirildi; Ctrl+V sonrası grafikte konum seçilir. Arama alanı odaktayken kısayollar devre dışı.

## v4.9.71
- Tüm çizim araçlarında fareyle taşıma ve tutamaçla boyutlandırma desteği genişletildi.
- Çizimlere çift tıklayarak özellikler penceresi (renk, opaklık %0-100, stil).
- Özel renk paleti ve serbest opaklık ayarı.
- Çizimlerin tüm zaman dilimlerinde gösterilmesi seçeneği.
- Alarm yönetim paneli ve alarm geçmişi.
- Klavye kısayolları: Delete (sil), Ctrl+Z (geri al), Ctrl+Y (ileri al), Ctrl+C (kopyala), Ctrl+V (yapıştır).
- Grafik kaydırma ve yakınlaştırma performansı için ek önbellekleme ve throttling.
- Mevcut v4.9.70 özellikleri korundu.

## v4.9.70
- Kapalı şekiller ve desteklenen kanallarda dolgu; seçili sözlük tabanlı çizimlerde taşıma ve tutamaçla düzenleme.
- Grafik dışı fiyat alarmı: uygulama açıkken 60 saniye arayla kontrol (USD hariç).

## v4.9.69
- Favori çizim araçları, oturum içi geri/ileri alma (50 kayıt), grafik veri yenilemesinde yatay fiyat alarmı, çizgi opaklığı ve kesik/noktalı çizgiler, dikdörtgen dolgusu.
- Canlı Windows/Flet testi yapılmadı.

## v4.9.68
- Flet WEB_BROWSER modu geri getirildi; baslatma_log.txt ile acilis hatalari kaydedilir.
- Program kapandiginda baslatici acik kalir.

## v4.9.67
- Windows BAT satır sonları CRLF olarak düzeltildi. Web tarayıcı açılışı Windows yerel API üzerinden yapılıyor.

## v4.9.66
- Nesne listesi, çizim kilidi ve gizle/göster eklendi. Toplu silme onaylı olarak korunur.

## v4.9.65
- Grafik zeminine açık gri hisse filigranı eklendi.
- Sol üstteki hisse adı kaldırıldı.
- Hisse arama kutusu zaman dilimi düğmelerinin önüne taşındı.

## v4.9.64
- Long/Short pozisyon çizimleri: giriş, hedef, stop, risk/kazanç, yüzde ve seçili seviyeleri sürükleme. Manuel analiz; emir göndermez.

## v4.9.63
- 13 manuel formasyon ve Elliott çizim aracı, nokta etiketleri, canlı ön izleme ve OBO/TOBO boyun çizgisi. Otomatik formasyon doğrulaması yoktur.

## v4.9.62
- Çokgen (sağ tıkla bitir), Fibonacci uzatma, kanal, daireler, Gann kutusu ve fanı.
- Açık grafikteki çizimleri onay ile topluca silme.

## v4.9.61
- Üçgen, yay, kuadratik eğri ve döndürülmüş dikdörtgen eklendi.

## v4.9.60
- Trend açısı (ekran ölçeği), kapanış fiyatlarına dayalı regresyon kanalı (±2 artık standart sapma), ayrık ve yatay sınır kanalları ile dört Pitchfork türü eklendi.

## v4.9.59
- Sekiz kategorili çizim menüsü; yatay ışın, sonsuz çizgi, elips, Fibonacci zaman bölgeleri ve fanı, fiyat ve tarih aralığı eklendi.

## v4.9.58
- Üç tıklamalı paralel kanal, orta çizgi ve canlı ön izleme eklendi.

## v4.9.57
- Çizim araçlarına iki tıklamalı, canlı ön izlemeli Dikdörtgen aracı eklendi. Seçim, kopyalama, silme ve stil değiştirme desteği mevcut.

## v4.9.56
- FVRP hacim profili v4.9.51 renklerine ve %55 opaklığa döndürüldü; dolgusuz takas aralığı korundu.

## v4.9.55
- Alt hacim çubukları fiyat mumlarıyla aynı yatay konuma bağlandı. Boş alanlarda hacim çizilmez.
- Çift yönlü kaydırma ve çizim araçları korundu.

## v4.9.54
- Işın, Ölçüm / Ölçek ve Daire araçları; iki tıklama, canlı ön izleme, kayıt ve mevcut çizim menüsü desteği.

# Sürüm geçmişi

## v4.9.53
- Mum grafiği ilk mumdan önce ve son mumdan sonra boş alan bırakacak şekilde iki yönlü kaydırılabilir. Alt hacim çubukları kaydırmada sabit kalır; yakınlaştırmada yeniden hesaplanır.

## v4.9.52
- FRVP gelişen takas aralığı dolgusu kaldırıldı; beyaz sınırlar ve POC korundu. Hacim profili VAL–VAH içinde yeşil, dışında pembe.
- Grafik panelinin ve çizim alanının genişleme ayarları düzenlendi; fiyat ve tarih etiketleri korunarak arka plan ızgarası kaldırıldı.

## v4.9.51
- Etkileşimli grafikte sola sürükleme son mumdan sonra boş alan açar. Tekerlekle uzaklaştırmada 240 mum sınırı kaldırıldı.

## v4.9.50
- Grafiğin alt satırındaki İşlem planı kutusu, plan bilgilerini ve bunlara ait fiyat çizgilerini birlikte açıp kapatır.

## v4.9.49
- Grafik sayfasında tarayıcı sağ tık menüsü engellenir. Mum grafiği pencerenin kullanılabilir yüksekliğini doldurur.

## v4.9.48
- İmleç ayarı kaldırıldı. Sol tuşla kaydırmada hazır grafik katmanı hareket eder.

## v4.9.47
- Grafikte çizime sağ tıklayıp Kopyala seçeneğini kullanarak başka bir konuma yerleştirebilirsiniz. Yerleştirmeden önce sağ tıklayarak iptal edebilirsiniz.

## v4.9.46
- FRVP seçildiğinde başlangıç ve bitiş tutamaçları sürüklenebilir. Sağ tık menüsünden sabit POC çizgisi açılıp kapatılabilir.

## v4.9.45
- Sabit hacim profilinde gelişen takas aralığının üst ve alt sınırları beyaz basamaklı çizgilerle gösterilir.

## v4.9.44
- Camarilla seviyeleri seçilen takvim döneminin ilk mumundan son mumuna kadar uzanır.

## v4.9.43
- Sabit hacim profilinde Gelişen POC ve yüzde 70 hacmi kapsayan Gelişen TA bandı gösterilir.

## v4.9.42
- Çizim sağ tık menüsüne renk, kalınlık ve varsayılan biçime dönüş eklendi.

## v4.9.41
- Dip Alarm, Dip Hafıza, EVRE ve EVRE Alarm taramalarında Durdur düğmesi bekleyen veri isteklerinden bağımsız çalışır.

## v4.9.40
- Kaydırma ve yakınlaştırmada mumlar, hacim ve gösterge çizgileri toplu çizilir. Akümülasyon tepeleri her harekette yeniden hesaplanmaz.

## v4.9.39
- Uzun geçmişte görünür mum çizimi ekran genişliğine uyarlandı. İmleç hareketi ayrı bir katmanda güncellenir.

## v4.9.38
- Dip Hafıza günlük grafiğinde hissenin tüm olayları işaretlenir. Olay menüsünden tarihe odaklanılabilir.

## v4.9.37
- Grafik dönemleri TradingView satırında altı küçük düğmeyle seçilir.

## v4.9.36
- Grafik göstergeleri sol üstteki küçük yazılı açılır menüde toplandı.

## v4.9.35
- Grafik piyasa etiketi TradingView satırının sağına, işlem planı tarih ve hacim satırına taşındı.

## v4.9.34
- BİST ekranına yenileme süresi, sinyal ve hazırlık seçimleri eklendi.

## v4.9.33
- BİST zaman kutuları ve etiketleri küçültüldü, aralarındaki boşluk daraltıldı.

## v4.9.32
- BİST işlem düğmeleri ilk satıra taşındı. Pazar seçimi ve zaman kutuları aynı satırda.

## v4.9.31
- Çizim tamamlanınca imlece dönülür. Çizime sağ tıklayıp Sil seçilerek o çizim kaldırılır.

## v4.9.30
- v4.9.26 arayüzü ve v4.9.29 güncelleme, web ve günlük veri desteği birleştirildi. Grafiklere beş EMA dönemi ve sol çizim çubuğu eklendi.

## v4.9.29
- Yazılım güncelleme: yeni **Güncelleme** sekmesi (Sistem). İnternetten (manifest.json veya `github:kullanici/depo`) ya da indirilmiş ZIP'ten güncelleme; sha256 doğrulama, eksik/iskelet paketleri reddetme, her güncellemeden önce otomatik yedek ve **Önceki sürüme dön**. Favoriler, işlemler, arşivler ve `.venv` korunur; güncelleme sonrası uygulama kendini yeniden başlatır.
- `BASLAT_WINDOWS.bat`: paketler yalnızca ilk kurulumda veya `requirements.txt` değiştiğinde kurulur; güncelleme sonrası otomatik yeniden başlatma.
- **Web arayüzü:** `BASLAT_WEB.bat` aynı uygulamayı tarayıcıda açar (http://localhost:8550); `BASLAT_WEB_AG.bat` yerel ağdaki cihazlara açar. Tarayıcıda CSV indirme bağlantısıyla kaydedilir.
- `guncelleme_hazirla.py`: yayınlanacak ZIP için manifest.json üretir.

## v4.9.28
- Tam uygulama paketi yeniden hazırlandı. v4.9.27 "temiz" paketi yalnızca küçük bir iskeletti (arayüz ve veri modülleri yoktu), bu yüzden pencere açılmıyordu. Sürüm numarası v4.9.27'nin üstüne alındı.
- Rapordan grafiğe geçişte her zaman GÜNLÜK mumlar gelir. Rapor mum taşımıyorsa veya mumlar haftalık/aylık ise günlük grafik yeniden alınır.
- Veri katmanı: Yahoo uzun aralıkta haftalık/aylık mum döndürürse istek 4 yıllık parçalara bölünüp günlük mumlar toplanır. Önbellekte haftalık kayıt varsa bir sonraki yenilemede günlükle değiştirilir.
- `version.py` v4.9.27 uyumlu `get_version_info()` içerir.

## v4.9.26
- Grafik ekranında hisse ve şirket adı, arama, zaman dilimi ve imleç ayarı başlığın sağına taşındı.

## v4.9.25
- BİST zaman kutuları soldan sağa sıralandı. Hisse filtresi düğmesi yapılacak işlemi gösteriyor. BİST ve Binance ekranlarında CSV düğmesi canlı taramanın sağına alındı.

## v4.9.24
- BIST zaman dilimleri yatay sıraya alındı. Filtre ve periyodik tarama düğmeleri düzenlendi. Sinyaller ekranındaki CSV ve kapsam seçimi kaldırıldı.

## v4.9.23
- Binance piyasa seçimi ve canlı tarama ayarları düğmeye dönüştürüldü.

## v4.9.22
- TradingView, tam ekran, görünüm ve Sanal AL düğmeleri grafik işlem satırına taşındı.

## v4.9.21
- Piyasalar sayfalarında tek/tüm seçimi, CSV ve sıralanabilir sonuç tablosu.

## v4.9.20
- Grafik açıklamasının yerine beş küçük işlem düğmesi eklendi.

## v4.9.19
- VWAP bantları tek düğmede, görünür hacim profili grafiğin sol kenarında.

## v4.9.18
- Grafik sekmesinden doğrudan günlük hisse grafiği açılır. Kontroller sembolün yanına taşındı.

## v4.9.17
- EVRE sayfasında tek/tüm tarama paneli ve sıralanabilir sonuç tablosu.

## v4.9.16
- Hisse raporlarında günlük mum verisi ve günlük TradingView bağlantısı.

## v4.9.15
- Dip Hafıza ve Dip Alarm (Dip Radarı): kutular ve düğmeler tek satırda toplandı. Tara yeşil, Dip arşivi (Dip Hafıza) turuncu.
- Durum yüzde çubuğu bu sayfalarda Analiz ile aynı (turuncu, 8 px, sağda yüzde yazısı, altında durum metni).

## v4.9.14
- Analiz: Tek/Çalıştır/CSV satırının altına durum yüzde çubuğu eklendi. Çok hisseli taramada "12/500" ilerlemesinden yüzde hesaplanır; tek hissede çalışırken kayan çubuk, bitince %100 gösterilir. Durum yazısı çubuğun altında.

## v4.9.13
- Açılır menü ve metin kutularının genişliği 1/4 oranında kısaltıldı (240 → 180 px).

## v4.9.12
- Açılır menü ve metin kutuları aynı boya (40 px) getirildi; metin kutuları eskiden 28 px kalıyordu.
- Parametre kutusunun uzun etiketi iki satıra taşıp değerin üstüne biniyordu; "Puan / mum / hedef / stop %" olarak kısaltıldı.

## v4.9.11
- Analiz: Kayıtlı veri ve Kalkış alarmı sesi anahtarları CSV kaydet düğmesinin sağına, aynı satıra taşındı.

## v4.9.10
- Düzeltme: ListView `on_scroll_interval` hatası giderildi (uygulama açılmıyordu). Kaydırma izleme ve tablo sıralaması Flet sürümüne göre parametre adlarını dener; desteklenmezse sütun başlığı yerine "Sırala" menüsü kullanılır.

## v4.9.9
- Analiz: Tek hisse / Tüm hisseler (ve Kod listesi) tek geçiş düğmesi oldu: Tek kırmızı, Tüm yeşil. Rapor satırının altında; Çalıştır (turuncu) ve CSV kaydet sağında.
- Kayıtlı veri ve Kalkış alarmı sesi yan yana.
- Listede grafik simgesi sarı.
- Rapor tablosunda sütun başlığına tıklayarak sıralama (sayılar sayı gibi, CSV de sıralı kaydedilir).
- Seçilen satır belirgin renkle vurgulanır (hücreye, menü veya grafik simgesine tıklayınca).
- Grafikten Analiz'e dönünce liste aynı sayfada, aynı kaydırma konumunda ve seçili satırla açılır.

## v4.9.8
- Açılır menüler ve metin kutuları aynı en (240) ve boyda (48) oldu; araç çubuğu, tarama ayarları, rapor ve portföy formlarında hizalı.

## v4.9.7
- BASLAT_WINDOWS.bat: sanal ortamda pip yoksa önce onarır (ensurepip), olmazsa .venv'i silip yeniden oluşturur; yine olmazsa nedenini Türkçe açıklar.

## v4.9.6
- Akümülasyon: diptan önceki ve sonraki tepelerden yükseğinin yatay çizgisi, turuncu; çizgi seviyeye ilk ulaşan mumda biter. VWAP yanında kısayol düğmesi.
- VWAP ±3σ / ±4σ bantları (otomatik fiyat ölçeğini bozmaz).
- Görünür hacim: görünen aralığın hacim profili (POC / VAH / VAL).
- Dikey çizgi aracı, yukarı ok ve aşağı ok çizim araçları.
- İmleç ayarındaki "Dikey çizgi" seçeneği "Dikey imleç" olarak yeniden adlandırıldı.

## v4.9.5
- Fibonacci geri çekilme aracı.
- Fiyat ekseninde tekerlek ve sürükleme ile fiyat ölçeği büyütme/küçültme, sıfırlama.
- Sol tuşla basılı tutup grafiği her yöne taşıma.
- İmleç ayarları: çapraz, mıknatıslı, dikey çizgi, sadece bilgi; tarih etiketi.
- Sürüm numarası pencere başlığında, üst başlıkta ve ZIP adında.

## v4.9.4
- Grafik görünmeme sorunu için tek tuval düzenine dönüş, önbellekli sabit şekiller.

## v4.9.3
- Rapor satırı ayrıntılarında önem sırasına göre renklendirme.

## v4.9.2
- İmleç takılmasına karşı sabit şekil önbelleği ve gereksiz fare olaylarını atlama.

## v4.9.1
- Genişletilmiş grafik alanı, pencere yüksekliğine uyum ve Tam ekran grafik.

## 4.9.78
- ChatGPT sürümleri için GitHub/HTTPS yayın kanalı arayüzü, SHA-256 ve sürüm eşleşmesi zorunluluğu.
- Windows ZIP seçimi ve yayıncı için GitHub CLI yardımcısı; doğrudan sohbet erişimi yoktur.
