def vol_ratio(vol):
    if not vol or len(vol) < 12: return 1.0
    prior = vol[-11:-1]
    avg = sum(prior) / len(prior) if prior else 0
    return float(vol[-1]) / avg if avg > 0 else 1.0

def obv(close, volume):
    if len(close) != len(volume) or len(close) < 2:
        return []
    result = [0.0]
    for i in range(1, len(close)):
        if close[i] > close[i-1]:
            result.append(result[-1] + volume[i])
        elif close[i] < close[i-1]:
            result.append(result[-1] - volume[i])
        else:
            result.append(result[-1])
    return result

def obv_analysis(close, volume):
    """OBV eğimi ve divergence"""
    obv_vals = obv(close, volume)
    if len(obv_vals) < 15:
        return {"OBVTrend": "BELİRSİZ", "OBVDiv": False, "OBVSlope": 0}
    # Son 10 bar eğimi
    recent = obv_vals[-10:]
    slope = (recent[-1] - recent[0]) / 10 if recent[0] != 0 else 0
    trend = "YUKARI" if slope > 0 else "ASAGI" if slope < 0 else "YATAY"
    # Basit divergence: fiyat yeni yüksek, OBV değil (veya tersi)
    price_high = max(close[-10:])
    obv_high = max(obv_vals[-10:])
    prev_price_high = max(close[-20:-10]) if len(close) >= 20 else price_high
    prev_obv_high = max(obv_vals[-20:-10]) if len(obv_vals) >= 20 else obv_high
    div = False
    if close[-1] >= price_high * 0.995 and obv_vals[-1] < obv_high * 0.95:
        div = True  # fiyat yüksek, OBV düşük → bearish div
    elif close[-1] <= min(close[-10:]) * 1.005 and obv_vals[-1] > min(obv_vals[-10:]) * 1.05:
        div = True  # fiyat düşük, OBV yüksek → bullish div (basitleştirilmiş)
    return {"OBVTrend": trend, "OBVDiv": div, "OBVSlope": round(slope, 2)}

def deep_volume_analysis(volume, close, high, low):
    if not volume or len(volume) < 20:
        return {"VolScore": 0, "VolTrend": "BELİRSİZ", "BreakoutVol": False, "VolProfile": "NORMAL", "VolRatio": 1.0}
    vr = vol_ratio(volume)
    last_vol = volume[-1]
    avg20 = sum(volume[-20:]) / 20
    avg5 = sum(volume[-5:]) / 5
    score = 0
    if vr >= 2.5: score += 40
    elif vr >= 1.8: score += 30
    elif vr >= 1.5: score += 20
    elif vr >= 1.2: score += 10
    if avg5 > avg20 * 1.15: score += 20
    if last_vol > max(volume[-10:-1]): score += 20
    score = min(100, score)
    if avg5 > avg20 * 1.2:
        trend = "ARTIŞ"
    elif avg5 < avg20 * 0.8:
        trend = "AZALIŞ"
    else:
        trend = "YATAY"
    price_change = abs(close[-1] - close[-2]) / close[-2] if len(close) > 1 else 0
    breakout = vr >= 1.8 and price_change >= 0.015
    if vr >= 2.2 and trend == "ARTIŞ":
        profile = "PATLAMA"
    elif vr >= 1.5 and trend == "ARTIŞ":
        profile = "GÜÇLÜ"
    elif vr >= 1.2:
        profile = "NORMAL+"
    elif vr < 0.8:
        profile = "ZAYIF"
    else:
        profile = "NORMAL"
    return {"VolScore": score, "VolTrend": trend, "BreakoutVol": breakout, "VolProfile": profile, "VolRatio": round(vr, 2)}

