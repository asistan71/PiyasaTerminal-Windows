"""Non-destructive projections of drawings onto another chart interval."""
from bisect import bisect_right
from copy import deepcopy
from datetime import datetime

def project_drawings(records, key, bars, sources=None):
    if not bars or key.endswith('|USD'): return []
    candidates = [d for other, drawings in records.items()
                  if other != key and not other.endswith('|USD') and other.rsplit('|',1)[0]==key.rsplit('|',1)[0]
                  for d in drawings if isinstance(d,dict) and d.get('all_timeframes') and not d.get('hidden')]
    if not candidates: return []
    try: times = [datetime.fromisoformat(b[0]) for b in bars]
    except (ValueError, TypeError): return []
    def date(value):
        try:
            t = datetime.fromisoformat(value)
            i = bisect_right(times, t)-1
            if i < 0 or t > times[-1]: return None
            return bars[i][0]
        except (ValueError, TypeError): return None
    def point(p):
        d = date(p[0]); return [d,p[1]] if d is not None else None
    output=[]
    for original in candidates:
        d=deepcopy(original); valid=True
        for field in ('date','start','end'):
            if field in d:
                d[field]=date(d[field]); valid &= d[field] is not None
        for field in ('a','b','c','point'):
            if field in d:
                d[field]=point(d[field]); valid &= d[field] is not None
        if 'points' in d:
            old=d['points']; d['points']=[point(p) if p is not None else None for p in old]
            valid &= all(a is None or b is not None for a,b in zip(old,d['points']))
        if valid:
            output.append(d)
            if sources is not None:
                sources[id(d)] = original
    return output


def commit_projection(original, before, after):
    """Commit only changed anchors; preserve original dates for price-only edits."""
    if original.get('locked') or original.get('hidden'):
        return False
    def merge(old, a, b):
        if a == b or a is None or b is None:
            return old
        return [old[0] if a[0] == b[0] else b[0], b[1]]
    for key in ('a','b','c','point'):
        if key in before and key in after:
            original[key] = merge(original[key], before[key], after[key])
    if 'points' in before:
        original['points'] = [merge(o,a,b) for o,a,b in zip(original['points'],before['points'],after['points'])]
    for key in ('date','start','end'):
        if key in before and before[key] != after[key]:
            original[key] = after[key]
    return True
