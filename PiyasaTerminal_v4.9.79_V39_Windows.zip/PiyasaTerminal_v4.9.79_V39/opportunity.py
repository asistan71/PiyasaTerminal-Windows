"""Experimental readiness ranking, independent from trade/alert rules."""
def evaluate(r):
    st=r['structure']; phase=r['phase']['phase']; price=r['price']; plan=r['plan']
    maturity=sum(w for k,w in [('dip',15),('fake',25),('real',25),('retest',35)] if st.get(k) is not None)
    target=plan.get('target'); stop=plan.get('stop')
    upside=(target/price-1)*100 if target and target>price>0 else None
    risk=(1-stop/price)*100 if stop and 0<stop<price else None
    rr=upside/risk if upside is not None and risk else None
    # Relative position within the phase is an experimental proxy, not a validated rule.
    z=r['z']; fit= (20 if z<-.5 else 10) if phase=='TL' else (20 if abs(z)<=.5 else 10 if abs(z)<=1 else 0) if phase in ('Dolar','Pivot') else 0
    a=round(maturity*.4); b=fit
    c=15 if price>=r['vah'] else 10 if price>=r['poc'] else 5 if price>=r['val'] else 0
    d=min(10,round(max(0,r['ratio']-1)*5))
    e=min(15,round(rr*5)) if rr is not None else 0
    score=min(100,a+b+c+d+e)
    ready=phase!='Belirsiz' and st.get('retest') is not None and st.get('signal') is None
    return dict(maturity=maturity,early_score=score,ready=ready,risk_pct=risk,rr=rr,upside=upside,parts=(a,b,c,d,e))

def top_candidates(results,phase='Tümü',limit=10):
    return sorted(((s,r) for s,r in results.items() if r['opportunity']['ready'] and (phase=='Tümü' or r['phase']['phase']==phase)),key=lambda x:(-x[1]['opportunity']['early_score'],x[0]))[:limit]
