"""Deneysel pivot pencereleri; canlı stratejiye dokunmadan karşılaştırma."""
from structure import detect
import calibration

VARIANTS=(('Mevcut (3 mum)',3),('Hassas (2 mum)',2),('Dengeli (5 mum)',5),('Seçici (8 mum)',8))

def evaluate(results, notes, profile, tolerance=3):
    out=[]
    for name, window in VARIANTS:
        rows=[]
        for sym, result in results.items():
            manual=notes.get(sym)
            if not isinstance(manual,dict) or not any(k in manual for k in ('fake','real')): continue
            candidate=dict(result)
            if window!=3:
                candidate['structure']=detect(result['series'],result['phase']['peak'],profile,window=window)
            rows.extend(calibration.compare(sym,candidate,manual,tolerance))
        metrics=calibration.summarize(rows)
        out.append(dict(name=name, **metrics, rows=rows))
    return out
