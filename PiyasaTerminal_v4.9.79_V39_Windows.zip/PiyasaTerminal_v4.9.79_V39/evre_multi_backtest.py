"""Sequential, consistent EVRE early-liftoff comparisons for multiple BIST tickers."""
import csv
import re

MAX_SYMBOLS = 20
DEFAULT_SYMBOLS = 'BORLS OZATD THYAO TUPRS ASELS PEKGY DURDO ANELE'


def parse_symbols(raw):
    codes = []
    for value in re.split(r'[,;\s]+', str(raw).strip().upper()):
        if not value:
            continue
        if not re.fullmatch(r'[A-Z0-9]{1,12}', value):
            raise ValueError('Geçersiz hisse kodu: ' + value)
        if value not in codes:
            codes.append(value)
    if not codes:
        raise ValueError('En az bir hisse kodu girin.')
    if len(codes) > MAX_SYMBOLS:
        raise ValueError(f'Bir seferde en fazla {MAX_SYMBOLS} hisse taranabilir.')
    return codes


def compare(symbols, loader, evaluator, progress=None):
    """Loader yields (daily_bars, provenance); exceptions are visible, not discarded."""
    items=[]
    for number,symbol in enumerate(symbols,1):
        try:
            bars, source=loader(symbol)
            summary, circles, signals=evaluator(bars)
            items.append(dict(symbol=symbol, state='OK', source=source, candles=len(bars),
                              signals=summary['total'], resolved=summary['resolved'],
                              wins=summary['wins'], failed=summary['failed'],
                              unknown=summary['unknown'], win_rate=summary['win_rate'],
                              first_signal=signals[0]['date'] if signals else None,
                              rows=signals, bars=bars, error=''))
        except Exception as exc:
            items.append(dict(symbol=symbol, state='HATA', error=str(exc),
                              source='', candles=0, signals=0, resolved=0, wins=0,
                              failed=0, unknown=0, win_rate=None, first_signal=None,
                              rows=[], bars=[]))
        if progress:
            progress(number, len(symbols), symbol, items[-1]['state'])
    valid=[item for item in items if item['state']=='OK']
    wins=sum(item['wins'] for item in valid)
    resolved=sum(item['resolved'] for item in valid)
    summary=dict(successful_symbols=len(valid), failed_symbols=len(items)-len(valid),
                 total_signals=sum(item['signals'] for item in valid),
                 resolved=resolved, wins=wins,
                 win_rate=round(wins*100/resolved,1) if resolved else None)
    return summary, items


def export_csv(path, items):
    keys=('symbol','state','candles','signals','resolved','wins','failed','unknown','win_rate','first_signal','source','error')
    with open(path,'w',newline='',encoding='utf-8-sig') as file:
        writer=csv.DictWriter(file,fieldnames=keys,extrasaction='ignore')
        writer.writeheader()
        for item in items: writer.writerow(item)
