"""v39 fırsat alarmı hesaplamaları."""
from datetime import date
import launch_study

def data_freshness(last_date, today=None, offline=False):
    """Calendar-age warning, NOT an exchange-calendar guarantee."""
    today = today or date.today()
    if not last_date:
        return 'Veri yok'
    try:
        age = (today - date.fromisoformat(str(last_date))).days
    except (ValueError, TypeError):
        return 'Tarih geçersiz'
    if age < 0:
        return 'İleri tarihli veri'
    if offline:
        return f'Önbellek ({age} gün)'
    return f'Eski veri ({age} gün)' if age > 4 else f'Yakın tarihli ({age} gün)'


def missing_launch_conditions(check, early=False):
    """Keep diagnostic's actual labels and measurements, never guess POC."""
    checks = check.get('checks', {})
    if not checks:
        return check.get('reason', 'Kalkış koşulları hesaplanamadı')
    selected = list(checks.items())[4:] if early else list(checks.items())[:4]
    if early:
        selected = [(k, v) for k, v in checks.items()
                    if k == 'Yeşil mum' or k.startswith('Erken:')]
    failed = [f'{name} ({detail})' for name, (passed, detail) in selected if not passed]
    return '; '.join(failed) if failed else 'Eksik koşul yok'


def classify_candidate(bars, row, minimum=70, today=None, offline=False):
    """Only completed candles; preserves v0.27 scoring and launch thresholds."""
    today = today or date.today()
    if float(row.get('score') or 0) < minimum:
        return None
    bars = sorted((b for b in (bars or []) if b[0] < today.isoformat()), key=lambda b: b[0])
    latest = bars[-1][0] if bars else ''
    freshness = data_freshness(latest, today, offline)
    common = {'symbol': '', 'score': row.get('score'),
              'phase': row.get('phase', {}).get('phase', '—'),
              'date': latest, 'data_status': freshness,
              'bars_count': len(bars), 'windows': {}, 'recovery': False,
              'volume_score': row.get('volume_time', {}).get('score'),
              'relative_volume': None, 'daily_pct': None, 'bars': bars}
    if len(bars) < 131:
        return {**common, 'state': 'Veri yetersiz',
                'listing_decision': 'DEĞERLENDİRİLEMEDİ',
                'missing': f'En az 131 tamamlanmış mum gerekli; mevcut: {len(bars)}',
                'note': f'En az 131 tamamlanmış mum gerekli; mevcut: {len(bars)}'}
    i = len(bars)-1
    check = launch_study.launch_diagnostic(bars, i)
    listing = launch_study.launch_listing_audit(bars).get(i, {})
    recovery = launch_study.recovery_diagnostic(bars, i-1)
    windows = {}
    for preset in launch_study.VOLUME_PRESETS:
        windows['/'.join(map(str, preset))] = {
            d: launch_study.before_window(bars, i, d) for d in preset
        }
    decision = listing.get('status', 'KARAR YOK')
    missing = missing_launch_conditions(check)
    if check['confirmed']:
        missing = 'Eksik koşul yok'
        if decision == 'BEKLEME FİLTRESİYLE ELENDİ':
            state = 'Kalkış / bekleme filtresi'
            note = ('Koşullar geçti; önceki kalkış: ' +
                    listing.get('blocking_date', '—') +
                    f"; aralık {listing.get('distance', '—')}/15 işlem günü")
        else:
            state, note = 'Kalkışta', '4/4 otomatik kalkış koşulu geçti'
    elif check['early']:
        state, note = 'Erken kalkış adayı', 'Erken fiyat/hacim koşulları geçti'
    elif recovery.get('candidate'):
        state, note = 'Yeniden güçlenme', 'Hacim toparlanıyor; fiyat kırılımı teyitsiz'
    else:
        state, note = 'Hazırlık / izleme', 'Otomatik kalkış koşulları eksik'
    return {**common, 'state': state, 'note': note, 'listing_decision': decision,
            'missing': missing, 'windows': windows,
            'recovery': bool(recovery.get('candidate')),
            'relative_volume': check.get('relative_volume'),
            'daily_pct': check.get('daily_pct')}


def window_text(windows, preset):
    periods = windows.get(preset, {})
    if not periods: return '—'
    values=[]
    for d in (60,30,10) if preset == '60/30/10' else (70,40,10):
        v=periods.get(d) or {}
        values.append(str(v.get('spike_count', '—')))
    return '/'.join(values)


