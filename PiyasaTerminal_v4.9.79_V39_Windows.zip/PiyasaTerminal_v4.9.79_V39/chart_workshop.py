"""V39 chart workshop with candle-aligned drawings and price levels."""
from copy import deepcopy
from datetime import datetime
import math

from evre_core import profile_bins

import flet as ft
import flet.canvas as cv

CHART_BG = "#101B24"

def watermark_color(background=CHART_BG):
    # Blend a small amount of neutral gray into the actual chart background.
    rgb = [int(background[i:i+2], 16) for i in (1, 3, 5)]
    return "#" + "".join(f"{round(v*.85+180*.15):02X}" for v in rgb)

UP, DOWN, TEXT = "#089981", "#F23645", "#B1B7C5"
PROFILE_INSIDE, PROFILE_OUTSIDE = "#628FC1", "#758094"
CAMARILLA = {
    "1 Hafta": 0, "1 Ay": 1, "3 Ay": 3, "6 Ay": 6,
    "1 Yıl": 12, "2 Yıl": 24, "3 Yıl": 36, "5 Yıl": 60, "10 Yıl": 120,
}
FIB_LEVELS = (
    (0, "#B1B7C5"), (0.236, "#F23645"), (0.382, "#FF9800"), (0.5, "#089981"),
    (0.618, "#2962FF"), (0.786, "#B388FF"), (1, "#B1B7C5"), (1.272, "#FACC15"), (1.618, "#FACC15"),
)
CURSOR_STYLES = ("Çapraz", "Mıknatıslı çapraz", "Dikey imleç", "Sadece bilgi")
ACCUMULATION = "#FF8A00"
ARROWS = {"Yukarı ok": ("up", "#089981"), "Aşağı ok": ("down", "#F23645")}
SINGLE_CLICK = ("Yatay çizgi", "Dikey çizgi", *ARROWS)
EXTRA_TOOLS = {"Işın": "ray", "Ölçüm / Ölçek": "measure", "Daire": "circle", "Dikdörtgen": "rectangle", "Yatay ışın": "horizontal_ray", "Sonsuz çizgi": "extended_line", "Elips": "ellipse", "Fibonacci zaman bölgeleri": "fib_time", "Fibonacci fanı": "fib_fan", "Fiyat aralığı": "price_range", "Tarih aralığı": "date_range"}
CHANNEL_TOOLS = {"Paralel Kanal": "channel", "Ayrık kanal": "disjoint_channel", "Yatay sınır kanalı": "flat_channel", "Pitchfork": "pitchfork", "Schiff Pitchfork": "schiff", "Modifiye Schiff": "modified_schiff", "İç Pitchfork": "inside_pitchfork"}
EXTRA_TOOLS.update({"Trend açısı": "trend_angle", "Regresyon kanalı": "regression"})
SHAPE_TOOLS = {"Üçgen": "triangle", "Yay": "arc", "Eğri": "curve", "Döndürülmüş dikdörtgen": "rotated_rect"}
CHANNEL_TOOLS.update(SHAPE_TOOLS)
EXTRA_TOOLS.update({"Gann kutusu": "gann_box", "Gann fanı": "gann_fan", "Fibonacci daireleri": "fib_circles"})
CHANNEL_TOOLS.update({"Fibonacci uzatma": "fib_extension", "Fibonacci kanalı": "fib_channel"})
PATTERN_TOOLS = {
    "XABCD": ("xabcd", ("X", "A", "B", "C", "D")),
    "ABCD": ("abcd", ("A", "B", "C", "D")),
    "Gartley": ("gartley", ("X", "A", "B", "C", "D")),
    "Bat": ("bat", ("X", "A", "B", "C", "D")),
    "Butterfly": ("butterfly", ("X", "A", "B", "C", "D")),
    "Cypher": ("cypher", ("X", "A", "B", "C", "D")),
    "OBO": ("head_shoulders", ("Sol taban", "Sol omuz", "Boyun", "Baş", "Boyun", "Sağ omuz", "Sağ taban")),
    "TOBO": ("inverse_head_shoulders", ("Sol tepe", "Sol omuz", "Boyun", "Baş", "Boyun", "Sağ omuz", "Sağ tepe")),
    "Elliott itki": ("elliott_impulse", ("0", "1", "2", "3", "4", "5")),
    "Elliott düzeltme": ("elliott_abc", ("0", "A", "B", "C")),
    "Elliott üçgen": ("elliott_triangle", ("0", "A", "B", "C", "D", "E")),
    "Elliott çift kombinasyon": ("elliott_wxy", ("0", "W", "X", "Y")),
    "Elliott üçlü kombinasyon": ("elliott_wxyxz", ("0", "W", "X", "Y", "X", "Z")),
}
PATTERN_LABELS = dict(PATTERN_TOOLS.values())
POSITION_TOOLS = {"Long pozisyon": "long_position", "Short pozisyon": "short_position"}
CHANNEL_TOOLS.update(POSITION_TOOLS)
TWO_CLICK = ("Trend çizgisi", "Sabit hacim (FRVP)", "Fibonacci", *EXTRA_TOOLS)
_KEEP = object()
PIVOTS = (
    ("Adil Değer", "#FFFFFF"), ("Bedava", "#FACC15"),
    ("Keskin Düzeltme", "#F23645"), ("Kar Al", "#FB923C"),
)


def pivots(bars, period):
    groups = []
    for index, bar in enumerate(bars):
        day = datetime.fromisoformat(bar[0]).date()
        months = CAMARILLA[period]
        key = (day.year * 12 + day.month - 1) // months if months else day.isocalendar()[:2]
        if not groups or groups[-1][0] != key:
            groups.append((key, []))
        groups[-1][1].append((index, bar))
    segments = []
    for (_, previous), (_, current) in zip(groups, groups[1:]):
        hi = max(bar[2] for _, bar in previous)
        lo = min(bar[3] for _, bar in previous)
        close = previous[-1][1][4]
        if hi <= lo or lo <= 0:
            continue
        values = ((hi + lo + close) / 3, close - 0.55 * (hi - lo),
                  close + 0.55 * (hi - lo), hi / lo * close)
        left = current[0][0]
        right = current[-1][0] + 1
        segments.extend((left, right, value, name, color)
                        for value, (name, color) in zip(values, PIVOTS))
    return segments[-60:]


def swing_highs(bars, k=5):
    """Her iki yanında k muma göre en yüksek olan tepelerin sıra numaraları."""
    found = []
    for i in range(k, len(bars) - k):
        high = bars[i][2]
        if all(high >= bars[j][2] for j in range(i - k, i)) and all(high > bars[j][2] for j in range(i + 1, i + k + 1)):
            found.append(i)
    return found


def accumulation(history, start, span, k=5, highs=None):
    """Dip (görünen aralığın en düşüğü) öncesi ve sonrası tepelerden yüksek olanın yatay çizgisi.

    Çizgi tepeden sağa uzanır ve yüksek seviyesine ilk ulaşan mumda biter (end=None ise henüz ulaşılmamıştır).
    """
    window = history[start:start + span]
    if len(window) < 3:
        return None
    dip = start + min(range(len(window)), key=lambda i: (window[i][3], -i))
    if highs is None:
        highs = swing_highs(history, k)
    candidates = []
    before = [i for i in highs if i < dip]
    after = [i for i in highs if i > dip]
    if before:
        candidates.append(before[-1])
    if after:
        candidates.append(after[0])
    if not candidates:
        return None
    peak = max(candidates, key=lambda i: (history[i][2], -i))
    level = history[peak][2]
    end = next((j for j in range(peak + 1, len(history)) if history[j][2] >= level), None)
    return {"dip": dip, "peak": peak, "level": level, "end": end}


def clamp_view_start(start, bar_count, span):
    # Keep at least one actual candle visible, even at the rightmost pan position.
    keep = min(bar_count, max(1, span // 5))
    return max(keep - span, min(start, bar_count - keep)) if bar_count else 0


class Workshop:
    def __init__(self, bars, levels, segments, overlays, drawings, tool, height=420, on_change=None,
                 marks=None, focus=None, start=0, span=None, on_view=None, note_at=None, fit_levels=True,
                 price_range=None, on_range=None, cursor_style="Çapraz", accumulation_line=False,
                 visible_volume=False, on_finish=None, readout=None, watermark=None, on_properties=None, shared_drawings=None, on_shared_edit=None):
        self.readout = readout
        self.watermark = watermark
        self.shared_drawings = shared_drawings or []
        self.on_shared_edit = on_shared_edit
        self.on_properties = on_properties
        self.accumulation_line = accumulation_line
        self.visible_volume = visible_volume
        self.volume_cache = {}
        self.accumulation_cache = {}
        self.swing_indices = None
        self.price_range = tuple(price_range) if price_range else None
        self.on_range = on_range
        self.cursor_style = cursor_style
        self.note_at = note_at
        self.fit_levels = fit_levels
        self.stroke = []
        self.profile_cache = {}
        self.bar_index = {bar[0]: i for i, bar in enumerate(bars)}
        self.history = bars
        self.span = span or len(bars)
        self.start = clamp_view_start(start, len(bars), self.span)
        self.on_view = on_view
        self.pan_frame = None
        self.drag_origin = None
        self.levels = levels
        self.segments = segments
        self.overlays = overlays
        self.drawings = drawings
        self.tool = tool
        self.menu_origin = None
        self.pending_copy = None
        self.menu_target = None
        self.selected_profile = None
        self.selected_position = None
        self.position_drag = None
        self.drag_endpoint = None
        self.preview_date = None
        self.on_finish = on_finish
        self.on_change = on_change
        self.anchor = None
        self.channel_end = None
        self.polygon_points = []
        self.pattern_points = []
        self.cursor = None
        self.marks = marks or {}
        self.focus = focus
        self.width = 640
        self.height = height
        self.canvas = cv.Canvas(on_resize=self.resize)
        self.overlay = cv.Canvas()
        layers = ft.Stack([self.canvas, self.overlay], fit=ft.StackFit.EXPAND)
        pen = tool == "Kalem"
        options = dict(
            content=ft.Container(content=layers, bgcolor=CHART_BG, clip_behavior=ft.ClipBehavior.HARD_EDGE),
            on_tap_up=self.tap, on_double_tap=self.double_tap, on_secondary_tap_up=self.open_drawing_menu, on_hover=self.hover, on_exit=self.leave, hover_interval=40,
            on_scroll=self.scroll,
            on_pan_start=self.pen if pen else self.begin_drag,
            on_pan_update=self.pen if pen else self.drag,
            on_pan_end=self.finish_pen if pen else self.end_drag,
            on_pan_cancel=self.cancel_pen if pen else self.cancel_drag,
            drag_interval=32,
        )
        shapes_cursor = getattr(ft, "MouseCursor", None)
        wanted = getattr(shapes_cursor, "PRECISE" if tool != "İmleç" else "MOVE", None) if shapes_cursor else None
        try:
            self.control = ft.GestureDetector(**options, **({"mouse_cursor": wanted} if wanted else {}))
        except TypeError:
            self.control = ft.GestureDetector(**options)
        items = [ft.PopupMenuItem(content="Sil", icon=ft.Icons.DELETE_OUTLINE, data=("delete", None))]
        items.append(ft.PopupMenuItem(content="Kopyala", icon=ft.Icons.CONTENT_COPY, data=("copy", None)))
        for name, color in (("Sarı", "#FACC15"), ("Mavi", "#60A5FA"), ("Yeşil", "#4ADE80"),
                            ("Kırmızı", "#FF7070"), ("Mor", "#C4A1FF"), ("Beyaz", "#FFFFFF")):
            items.append(ft.PopupMenuItem(content=f"Renk · {name}", height=32,
                                          icon=ft.Icon(ft.Icons.CIRCLE, color=color, size=14),
                                          data=("color", color)))
        for width in (1, 2, 3, 4, 6):
            items.append(ft.PopupMenuItem(content=f"Kalınlık · {width} px", height=32, data=("width", width)))
        items.append(ft.PopupMenuItem(content="Varsayılan biçime dön", data=("reset", None)))
        for caption, action, value in [("Çizgi · Düz", "dash", "solid"), ("Çizgi · Kesik", "dash", "dash"), ("Çizgi · Noktalı", "dash", "dot"), ("Opaklık · %25", "opacity", .25), ("Opaklık · %50", "opacity", .5), ("Opaklık · %100", "opacity", 1), ("Dolgu · Yok", "fill", 0), ("Dolgu · %15", "fill", .15), ("Dolgu · %30", "fill", .3), ("Yatay fiyat alarmı aç/kapat", "alarm", None)]:
            items.append(ft.PopupMenuItem(content=caption, data=(action, value)))
        self.drawing_menu_items = list(items)
        self.control = ft.ContextMenu(content=self.control, secondary_trigger=None,
                                      items=items, on_select=self.edit_selected)
        self.redraw(update=False)

    @property
    def bars(self):
        return self.history[max(0, self.start):self.start + self.span]

    def set_view(self, start, span, price_range=_KEEP, *, render=True):
        span = max(1, min(max(1000, len(self.history)), span))
        start = clamp_view_start(start, len(self.history), span)
        range_changed = price_range is not _KEEP and price_range != self.price_range
        view_changed = (self.start, self.span) != (start, span)
        if not (range_changed or view_changed):
            return
        self.start, self.span = start, span
        self.cursor = None
        if range_changed:
            self.price_range = price_range
            if self.on_range:
                self.on_range(price_range)
        if view_changed and self.on_view:
            self.on_view(start, span)
        if render:
            self.redraw()

    def _zoomed_range(self, price, factor):
        low, high = self.price_range or (self.low, self.high)
        new = (price - (price - low) * factor, price + (high - price) * factor)
        return new if new[1] - new[0] > 1e-9 else self.price_range

    def scroll(self, event):
        amount = event.scroll_delta.y
        if not amount:
            return
        position = event.local_position
        if position.x >= self.plot_width:
            fraction = max(0, min(1, position.y / self.plot_height))
            price = self.high - fraction * (self.high - self.low)
            self.set_view(self.start, self.span, self._zoomed_range(price, 0.85 if amount < 0 else 1 / 0.85))
            return
        minimum = min(12, len(self.history))
        span = (max(minimum, int(self.span * 0.8)) if amount < 0
                else min(max(1000, len(self.history)), math.ceil(self.span * 1.25)))
        fraction = max(0, min(1, position.x / self.plot_width))
        start = round(self.start + (self.span - span) * fraction)
        if span > self.span and self.start + self.span <= len(self.history):
            start = min(start, len(self.history) - span)
        self.set_view(start, span)

    def profile_handles(self):
        target = self.selected_profile
        if target is None or target.get("locked") or target.get("hidden"):
            return
        indices = {key: self.bar_index[target[key]] for key in ("start", "end")}
        if max(indices.values()) < self.start or min(indices.values()) >= self.start + self.span:
            return
        for order, field in enumerate(sorted(indices, key=indices.get)):
            index = self.bar_index[self.preview_date] if self.drag_endpoint == field and self.preview_date else indices[field]
            px = min(self.plot_width - 6, max(6, self._x(index - self.start)))
            yield field, px, 48 + order * 22, "Başlangıç" if order == 0 else "Bitiş"

    def begin_drag(self, event):
        position = event.local_position
        self.cursor = None
        for field, px, py in self.position_handles():
            if self.tool == "İmleç" and abs(position.x-px)<=10 and abs(position.y-py)<=10:
                self.position_drag = (field, self.selected_position[field])
                self._position_before = deepcopy(self.selected_position)
                return
        for field, px, py, _ in self.profile_handles():
            if abs(position.x - px) <= 12 and abs(position.y - py) <= 12:
                self.drag_endpoint = field
                self.preview_date = None
                return
        if self.tool == "İmleç" and position.x < self.plot_width and position.y <= self.plot_height:
            selected = getattr(self,"selected_drawing",None)
            handle = next((key for key,px,py in self.shape_handles() if abs(position.x-px)<=9 and abs(position.y-py)<=9),None)
            target = selected if handle is not None else self.drawing_at(position.x,position.y, include_shared=True)
            if isinstance(target,dict) and not target.get("locked") and not target.get("hidden") and target.get("tool") not in ("frvp", "vline", *POSITION_TOOLS.values()) and self._anchor_items(target):
                self._last_shape_drag = None
                self.shape_drag = (target,deepcopy(target),position.x,position.y,handle,self.step,(self.high-self.low)/self.plot_height)
                self.selected_drawing = target
                return
        mode = "scale" if position.x >= self.plot_width else "move"
        self.drag_origin = (position.x, position.y, self.start, (self.low, self.high), mode)

    @staticmethod
    def _anchor_items(drawing):
        items = [(key,drawing[key]) for key in ("a","b","c","point") if drawing.get(key)]
        items += [(i,p) for i,p in enumerate(drawing.get("points",[])) if p is not None]
        return items

    def shape_handles(self):
        d=getattr(self,"selected_drawing",None)
        if not isinstance(d,dict) or d.get("hidden") or d.get("locked") or d.get("tool") in ("frvp",*POSITION_TOOLS.values()): return
        if not any(item is d for item in [*self.drawings, *getattr(self,"shared_drawings",[])]): return
        for key,p in self._anchor_items(d):
            pos=self._coords(p)
            if pos and 0<=pos[0]<=self.plot_width and 0<=pos[1]<=self.plot_height: yield key,*pos

    def drag(self, event):
        if getattr(self,"shape_drag",None):
            target,original,x,y,handle,step,scale=self.shape_drag
            items=self._anchor_items(original)
            if handle is not None: items=[(k,p) for k,p in items if k==handle]
            if any(p[0] not in self.bar_index for _,p in items): return
            shift=round((event.local_position.x-x)/step)
            indices=[self.bar_index[p[0]] for _,p in items]
            shift=max(-min(indices),min(shift,len(self.history)-1-max(indices)))
            delta=(y-event.local_position.y)*scale
            for key,p in items:
                value=(self.history[self.bar_index[p[0]]+shift][0],p[1]+delta)
                if isinstance(key,int): target["points"][key]=value
                else: target[key]=value
            if getattr(self,"_last_shape_drag",None) != (shift,delta,id(target)):
                self._last_shape_drag = (shift,delta,id(target))
                self.redraw()
            return
        if getattr(self, "position_drag", None):
            field, original = self.position_drag
            target = self.selected_position
            price = self.high - max(0,min(self.plot_height,event.local_position.y))/self.plot_height*(self.high-self.low)
            candidate = dict(target, **{field:(original[0],price)})
            if self.position_metrics(candidate["tool"], candidate["a"], candidate["b"], candidate["c"]):
                if target[field] != candidate[field]:
                    target[field] = candidate[field]
                    self.redraw()
            return
        if self.drag_endpoint:
            index = max(-self.start, min(len(self.history) - 1 - self.start, int(event.local_position.x / self.step)))
            day = self.history[self.start + index][0]
            if self.preview_date != day:
                self.preview_date = day
                self.redraw_overlay()
            return
        if self.drag_origin is None:
            return
        x0, y0, start, (low, high), mode = self.drag_origin
        x, y = event.local_position.x, event.local_position.y
        if mode == "scale":
            half = (high - low) / 2 * math.exp((y - y0) / 220)
            middle = (low + high) / 2
            new = (middle - half, middle + half)
            self.set_view(self.start, self.span, new if new[1] - new[0] > 1e-9 else _KEEP)
            return
        price_range = _KEEP
        if self.price_range is not None or abs(y - y0) >= 8:
            shift = (y - y0) / self.plot_height * (high - low)
            price_range = (low + shift, high + shift)
        # Render price and volume in the same viewport; keep the axis fixed.
        self.set_view(start - round((x - x0) / self.step), self.span, price_range)

    def finish_pan(self):
        self.drag_origin = None
        self.pan_frame = None
        self.canvas.offset = None

    def end_drag(self, _):
        if getattr(self,"shape_drag",None):
            target,original,*_=self.shape_drag
            self.shape_drag=None
            if target!=original:
                if any(d is target for d in getattr(self,"shared_drawings",[])):
                    callback = getattr(self,"on_shared_edit",None)
                    if callback: callback(target, original)
                elif self.on_change: self.on_change()
            self.redraw()
            return
        if getattr(self,"position_drag",None):
            self.position_drag = None
            target = self.selected_position
            before = getattr(self, "_position_before", None)
            if before is not None and target != before:
                self._commit_special(target, before)
            self.redraw()
            return
        self.finish_pan()
        if self.drag_endpoint:
            field, day = self.drag_endpoint, self.preview_date
            self.drag_endpoint = self.preview_date = None
            if day and self.selected_profile[field] != day:
                before = deepcopy(self.selected_profile)
                self.selected_profile[field] = day
                self._commit_special(self.selected_profile, before)
            self.redraw()

    def _commit_special(self, target, before):
        if any(d is target for d in getattr(self, "shared_drawings", [])):
            callback = getattr(self, "on_shared_edit", None)
            if callback: callback(target, before)
        elif self.on_change:
            self.on_change()

    def cancel_drag(self, _):
        if getattr(self,"shape_drag",None):
            target,original,*_=self.shape_drag
            target.clear(); target.update(original); self.shape_drag=None
            self.redraw()
            return
        if getattr(self,"position_drag",None):
            field, original = self.position_drag
            self.selected_position[field] = original
            self.position_drag = None
            self.redraw()
            return
        self.finish_pan()
        if self.drag_endpoint:
            self.drag_endpoint = self.preview_date = None
            self.redraw_overlay()

    def pen(self, event):
        point = self.point(event)
        if self.tool == "Kalem" and point and (not self.stroke or point != self.stroke[-1]):
            self.stroke.append(point)
            self.redraw_overlay()

    def finish_pen(self, _):
        if self.stroke:
            self.drawings.append({"tool": "pen", "points": self.stroke})
            self.stroke = []
            self.complete_drawing()

    def cancel_pen(self, _):
        self.stroke = []
        self.redraw_overlay()

    def resize(self, event):
        width = max(160, event.width)
        height = max(120, event.height)
        if (width, height) != (self.width, self.height):
            self.width, self.height = width, height
            self.redraw()

    def point(self, event):
        position = event.local_position
        if position is None:
            return None
        x, y = position.x, position.y
        if not 0 <= x < self.plot_width or not 0 <= y <= self.plot_height:
            return None
        index = min(self.span - 1, int(x / self.step))
        if not 0 <= self.start + index < len(self.history):
            return None
        price = self.high - y / self.plot_height * (self.high - self.low)
        if self.cursor_style == "Mıknatıslı çapraz" and self.tool != "Kalem":
            _, op, high, low, close, _ = self.history[self.start + index]
            best = min((op, high, low, close), key=lambda value: abs(self._y(value) - y))
            if abs(self._y(best) - y) <= 14:
                price = best
        return self.history[self.start + index][0], price

    def tap(self, event):
        position = event.local_position
        if (position is not None and position.x >= self.plot_width and 0 <= position.y <= self.plot_height
                and self.price_range is not None):
            self.set_view(self.start, self.span, None)
            return
        point = self.point(event)
        if point is None:
            return
        if self.pending_copy is not None:
            drawing, origin = self.pending_copy
            self.pending_copy = None
            self.place_copy(drawing, origin, point)
            self.complete_drawing()
            return
        if self.tool == "İmleç":
            hit = self.drawing_at(position.x, position.y, include_shared=True)
            self.selected_drawing = hit
            self.selected_position = hit if isinstance(hit,dict) and hit.get("tool") in POSITION_TOOLS.values() else None
            self.selected_profile = hit if isinstance(hit, dict) and hit.get("tool") == "frvp" else None
            self.cursor = point
            self.redraw_overlay()
            return
        if self.tool == "Metin" and self.note_at:
            self.note_at(point)
            return
        if self.tool == "Yatay çizgi":
            self.drawings.append((point, None))
        elif self.tool == "Dikey çizgi":
            self.drawings.append({"tool": "vline", "date": point[0]})
        elif self.tool in ARROWS:
            self.drawings.append({"tool": "arrow", "dir": ARROWS[self.tool][0], "point": point})
        elif self.tool in PATTERN_TOOLS:
            kind, labels = PATTERN_TOOLS[self.tool]
            if not self.pattern_points or point != self.pattern_points[-1]:
                self.pattern_points.append(point)
            self.cursor = point
            if len(self.pattern_points) == len(labels):
                self.drawings.append({"tool": kind, "points": list(self.pattern_points)})
                self.pattern_points = []
                self.complete_drawing()
            else:
                self.redraw_overlay()
            return
        elif self.tool == "Çokgen":
            if not self.polygon_points or point != self.polygon_points[-1]:
                self.polygon_points.append(point)
            self.cursor = point
            self.redraw_overlay()
            return
        elif self.tool in CHANNEL_TOOLS:
            if self.anchor is None:
                self.anchor = point
                self.channel_end = None
            elif self.channel_end is None:
                if (point[0] != self.anchor[0] or (self.tool in SHAPE_TOOLS and point != self.anchor)) and (self.tool not in POSITION_TOOLS or (point[1]>self.anchor[1] if self.tool=="Long pozisyon" else 0<point[1]<self.anchor[1])):
                    self.channel_end = point
            else:
                if self.tool in POSITION_TOOLS and not self.position_metrics(POSITION_TOOLS[self.tool], self.anchor,self.channel_end,point):
                    return
                self.drawings.append({"tool": CHANNEL_TOOLS[self.tool], "a": self.anchor, "b": self.channel_end, "c": point})
                self.anchor = self.channel_end = None
                self.cursor = point
                self.complete_drawing()
                return
        elif self.tool in TWO_CLICK:
            if self.anchor is None:
                self.anchor = point
            else:
                if self.tool == "Sabit hacim (FRVP)":
                    self.drawings.append({"tool": "frvp", "start": self.anchor[0], "end": point[0]})
                elif self.tool == "Fibonacci":
                    self.drawings.append({"tool": "fib", "a": self.anchor, "b": point})
                elif self.tool in EXTRA_TOOLS:
                    self.drawings.append({"tool": EXTRA_TOOLS[self.tool], "a": self.anchor, "b": point})
                else:
                    self.drawings.append((self.anchor, point))
                self.anchor = None
        self.cursor = point
        if self.tool in SINGLE_CLICK or (self.tool in TWO_CLICK and self.anchor is None):
            self.complete_drawing()
        else:
            self.redraw()

    def double_tap(self, event):
        """Open properties dialog on double-click of a drawing."""
        if self.tool != "İmleç":
            return
        position = event.local_position
        if position is None:
            return
        hit = self.drawing_at(position.x, position.y, include_shared=True)
        if not isinstance(hit, dict):
            return
        self.selected_drawing = hit
        if hasattr(self, "on_properties") and self.on_properties:
            self.on_properties(hit)
        else:
            # Fallback: open a simple properties dialog if page is available via callback later.
            pass

    def place_copy(self, drawing, origin, destination):
        if not isinstance(drawing, dict):
            drawing = {"tool": "line", "points": list(drawing)}
        date_keys = [key for key in ("date", "start", "end") if key in drawing]
        point_keys = [key for key in ("point", "a", "b", "c") if key in drawing]
        dates = [drawing[key] for key in date_keys]
        dates.extend(drawing[key][0] for key in point_keys)
        dates.extend(p[0] for p in drawing.get("points", []) if p is not None)
        indices = [self.bar_index[d] for d in dates if d in self.bar_index]
        offset = self.bar_index[destination[0]] - self.bar_index[origin[0]]
        if indices:
            offset = max(-min(indices), min(offset, len(self.history) - 1 - max(indices)))
        price_delta = destination[1] - origin[1]

        def shifted_date(date):
            index = self.bar_index.get(date)
            return date if index is None else self.history[index + offset][0]

        def shifted_point(point):
            return shifted_date(point[0]), point[1] + price_delta

        for key in date_keys:
            drawing[key] = shifted_date(drawing[key])
        for key in point_keys:
            drawing[key] = shifted_point(drawing[key])
        if "points" in drawing:
            drawing["points"] = [shifted_point(p) if p is not None else None for p in drawing["points"]]
        self.drawings.append(drawing)

    def complete_drawing(self):
        self.tool = "İmleç"
        if self.on_change:
            self.on_change()
        if self.on_finish:
            self.on_finish()
        else:
            self.redraw()

    def drawing_at(self, x, y, include_shared=False):
        def hits(shape):
            if isinstance(shape, cv.Line):
                dx, dy = shape.x2 - shape.x1, shape.y2 - shape.y1
                length = dx * dx + dy * dy
                t = min(1, max(0, ((x-shape.x1)*dx + (y-shape.y1)*dy) / length)) if length else 0
                return math.hypot(x - shape.x1 - t*dx, y - shape.y1 - t*dy) <= 6
            if isinstance(shape, cv.Text):
                size = shape.style.size or 12
                width = min(shape.max_width or self.plot_width, len(shape.value) * size * .65)
                return shape.x <= x <= shape.x + width and shape.y <= y <= shape.y + size * 1.4
            return False

        # Prefer visible strokes over background fills when two drawings overlap.
        candidates = [*getattr(self, "shared_shapes", []), *self.drawing_shapes] if include_shared else self.drawing_shapes
        for drawing, shapes in reversed(candidates):
            if any(hits(shape) for shape in shapes):
                return drawing
        for drawing, shapes in reversed(candidates):
            if any(isinstance(s, cv.Rect) and s.x <= x <= s.x+s.width
                   and s.y <= y <= s.y+s.height for s in shapes):
                return drawing
        return None

    async def open_drawing_menu(self, event):
        pos = event.local_position
        if self.tool in PATTERN_TOOLS:
            self.pattern_points = []
            self.cursor = None
            self.redraw_overlay()
            return
        if self.tool == "Çokgen":
            if len(self.polygon_points) >= 3:
                self.drawings.append({"tool": "polygon", "points": list(self.polygon_points)})
                self.polygon_points = []
                self.complete_drawing()
            else:
                self.polygon_points = []
                self.redraw_overlay()
            return
        if self.pending_copy is not None:
            self.pending_copy = None
            self.redraw_overlay()
            return
        self.menu_target = self.drawing_at(pos.x, pos.y) if pos else None
        if self.menu_target is not None:
            self.menu_origin = self.point(event)
            if self.menu_origin is None:
                index = max(-self.start, min(len(self.history) - 1 - self.start, int(pos.x / self.step)))
                self.menu_origin = self.history[self.start + index][0], self.low
            items = list(self.drawing_menu_items)
            if isinstance(self.menu_target, dict) and self.menu_target.get("tool") == "frvp":
                enabled = self.menu_target.get("fixed_poc", False)
                items.append(ft.PopupMenuItem(content="Sabit POC çizgisini " + ("kapat" if enabled else "aç"),
                                              checked=enabled, data=("fixed_poc", None)))
            if len(items) != len(self.control.items) or len(items) > len(self.drawing_menu_items):
                self.control.items = items
                self.control.update()
            await self.control.open(local_position=pos)

    def edit_selected(self, event):
        if event.item_index is None or not 0 <= event.item_index < len(self.control.items):
            return
        action, value = self.control.items[event.item_index].data
        target, self.menu_target = self.menu_target, None
        for index, drawing in enumerate(self.drawings):
            if drawing is target:
                if isinstance(drawing, dict) and drawing.get("locked") and action != "copy":
                    return
                if action == "copy":
                    self.pending_copy = deepcopy(drawing), self.menu_origin
                    self.anchor = None
                    self.redraw_overlay()
                    return
                if action == "delete":
                    self.drawings.pop(index)
                    if drawing is self.selected_profile:
                        self.selected_profile = None
                elif action == "fixed_poc":
                    drawing["fixed_poc"] = not drawing.get("fixed_poc", False)
                else:
                    if not isinstance(drawing, dict):
                        drawing = {"tool": "line", "points": list(drawing)}
                        self.drawings[index] = drawing
                    if action == "alarm":
                        point = drawing.get("point") or drawing.get("a") or next((p for p in drawing.get("points", []) if p), None)
                        if point is not None:
                            drawing["alarm"] = not drawing.get("alarm", False)
                            drawing["alarm_level"] = point[1]
                    elif action == "reset":
                        drawing.pop("style", None)
                    else:
                        drawing.setdefault("style", {})[action] = value
                if self.on_change:
                    self.on_change()
                self.redraw()
                break

    def hover(self, event):
        if self.drag_origin is not None or self.drag_endpoint or getattr(self,"shape_drag",None):
            return
        cursor = self.point(event)
        if cursor == self.cursor:
            return
        self.cursor = cursor
        self.redraw_overlay()

    def leave(self, _):
        if self.cursor is None:
            return
        self.cursor = None
        self.redraw_overlay()

    def _candle_groups(self, bars, stride):
        # Cache numeric aggregates, not mutable canvas controls. History is fixed per workshop.
        cache = getattr(self, "_group_cache", None)
        if cache is None:
            cache = self._group_cache = {}
        key = (self.start, self.span, stride)
        if key not in cache:
            result = []
            for index in range(0, len(bars), stride):
                group = bars[index:index+stride]
                result.append((index, len(group), group[0][1], max(b[2] for b in group), min(b[3] for b in group), group[-1][4], max(b[5] for b in group)))
            if len(cache) >= 24: cache.pop(next(iter(cache)))
            cache[key] = result
        return cache[key]

    def redraw(self, update=True):
        bars = self.bars
        axis_width = 62
        self.plot_width = self.width - axis_width
        self.plot_height = self.height - (80 if self.readout is not None else 103)
        self.step = self.plot_width / self.span
        visible_overlays = [(item[0][max(0, self.start):self.start + self.span], item[1], item[2] if len(item) > 2 else True)
                            for item in self.overlays]
        if self.price_range:
            self.low, self.high = self.price_range
        else:
            bounds = [bar[3] for bar in bars] + [bar[2] for bar in bars]
            if self.fit_levels:
                bounds += [price for _, price, _ in self.levels]
            bounds += [value for series, _, bounded in visible_overlays if bounded for value in series
                       if math.isfinite(value) and value > 0]
            lo, hi = (min(bounds), max(bounds)) if bounds else (0.0, 1.0)
            margin = max((hi - lo) * 0.07, abs(hi) * 0.001, 1e-8)
            self.low, self.high = lo - margin, hi + margin
        shapes = []

        def y(price):
            return (self.high - price) / (self.high - self.low) * self.plot_height

        def x(index):
            return (index + 0.5) * self.step

        def line(x1, y1, x2, y2, color, width=1):
            shapes.append(cv.Line(x1, y1, x2, y2, paint=ft.Paint(color=color, stroke_width=width)))

        def text(px, py, value, color=TEXT, size=10):
            shapes.append(cv.Text(px, py, value, style=ft.TextStyle(size=size, color=color)))

        if getattr(self, "watermark", None):
            mark = str(self.watermark).strip().upper()
            if mark:
                size = max(10, min(96, int(self.plot_width / max(4, len(mark) * 0.75)), int(self.plot_height * .25)))
                px = max(8, (self.plot_width - len(mark) * size * 0.58) / 2)
                py = max(0, (self.plot_height - size * 1.2) / 2)
                shapes.append(cv.Text(px, py, mark, max_width=max(1, self.plot_width - px),
                                      style=ft.TextStyle(size=size, color=watermark_color())))
        for index in range(6):
            py = index * self.plot_height / 5
            text(self.plot_width + 4, max(0, py - 8), f"{self.high - index * (self.high - self.low) / 5:.6g}", size=9)
        volume_base = self.plot_height + 56
        left_pad = max(0, -self.start)
        max_volume = max((bar[5] for bar in bars), default=0) or 1
        stripes = min(len(bars), max(2, int(self.plot_width // 125)))
        for i in range(stripes):
            index = i * (len(bars) - 1) // max(1, stripes - 1)
            px = x(index + left_pad)
            stamp = bars[index][0]
            text(max(0, min(px - 24, self.plot_width - 75)), volume_base + 1, stamp)
        text(self.plot_width + 4, self.plot_height + 8, "Hacim")
        # Subpixel candles share a screen column. Keep their price envelope and peak volume.
        stride = max(1, math.ceil(2 / self.step))
        batches = {}

        def batch_line(color, width, x1, y1, x2, y2):
            points = batches.setdefault((color, width), [])
            points.extend((ft.Offset(x1, y1), ft.Offset(x2, y2)))

        for index, count, op, high, low, close, volume in self._candle_groups(bars, stride):
            color = UP if close > op else DOWN if close < op else TEXT
            px = x(left_pad + index + (count - 1) / 2)
            half = max(0.45, count * self.step * 0.32)
            y_high, y_low, y_open, y_close = y(high), y(low), y(op), y(close)
            if y_low >= 0 and y_high <= self.plot_height:
                batch_line(color, 1, px, max(0, y_high), px, min(self.plot_height, y_low))
                top, bottom = max(0, min(y_open, y_close)), min(self.plot_height, max(y_open, y_close))
                if bottom >= top:
                    batch_line(color, 2 * half, px, top, px, max(top + 1, bottom))
            volume_height = max(0, volume) / max_volume * 40
            if volume_height:
                batch_line(ft.Colors.with_opacity(0.60, color), 2 * half, px, volume_base - volume_height, px, volume_base)
        for values, color, _ in visible_overlays:
            indices_to_draw = list(range(0, len(values), stride))
            if values and indices_to_draw[-1] != len(values) - 1:
                indices_to_draw.append(len(values) - 1)
            for i, j in zip(indices_to_draw, indices_to_draw[1:]):
                a, b = values[i], values[j]
                if a > 0 and b > 0:
                    clipped = self._clipped_segment((x(i + left_pad), y(a)), (x(j + left_pad), y(b)))
                    if clipped:
                        batch_line(color, 1.4, *clipped)
        for (color, width), points in batches.items():
            shapes.append(cv.Points(points=points, point_mode=cv.PointMode.LINES,
                                    paint=ft.Paint(color=color, stroke_width=width, stroke_cap=ft.StrokeCap.BUTT)))
        for name, price, color in self.levels:
            py = y(price)
            if not 0 <= py <= self.plot_height:
                continue
            line(0, py, self.plot_width, py, color)
            text(4, max(0, py - 14), f"{name} {price:.6g}", color)
        for first, last, price, name, color in self.segments:
            first, last = max(first, self.start) - self.start, min(last, self.start + self.span) - self.start
            if first < last and self.low <= price <= self.high:
                py = y(price)
                line(first * self.step, py, last * self.step, py, color)
                text(first * self.step, max(0, py - 14), name, color)

        if self.visible_volume:
            self._visible_volume(shapes, bars)
        if self.accumulation_line:
            self._accumulation(shapes)

        indices = {bar[0]: i + left_pad for i, bar in enumerate(bars)}
        self.indices = indices
        self.volume_base = volume_base
        self.axis_width = axis_width
        coords = self._coords
        segment = lambda a, b: self._segment(shapes, a, b)
        for day in set(self.marks) | {self.focus}:
            if day in indices:
                i = indices[day]
                px = x(i)
                line(px, y(bars[i - left_pad][3]) + 4, px, min(self.plot_height, y(bars[i - left_pad][3]) + 13), "#FACC15", 3)
                if day == self.focus:
                    text(max(2, min(px - 30, self.plot_width - 80)), 2, "Dip olayı" if self.marks.get(day, "").startswith("Dip olayı") else "Test mumu", "#FACC15")
        def draw_profile(drawing):
            first = self.bar_index.get(drawing["start"])
            last = self.bar_index.get(drawing["end"])
            if first is None or last is None:
                return
            first, last = sorted((first, last))
            left = max(0, (first - self.start) * self.step)
            right = min(self.plot_width, (last + 1 - self.start) * self.step)
            if right <= left:
                return
            key = (first, last)
            if key not in self.profile_cache:
                if len(self.profile_cache) >= 64:
                    self.profile_cache.pop(next(iter(self.profile_cache)))
                developing = []
                profile = profile_bins(self.history[first:last + 1], developing=developing)
                self.profile_cache[key] = profile, developing
            profile, developing = self.profile_cache[key]
            val, poc, vah, low, step, volumes = profile
            peak = max(volumes)
            if peak <= 0:
                text(left, 16, "Hacim verisi yok")
                return
            width = (right - left) * 0.48
            for i, volume in enumerate(volumes):
                lower = low + i * step
                upper = lower + step
                top = max(0, y(upper))
                bottom = min(self.plot_height, y(lower) + (1 if step == 0 else 0))
                if bottom > top and volume > 0:
                    color = PROFILE_INSIDE if val <= (lower + upper) / 2 <= vah else PROFILE_OUTSIDE
                    shapes.append(cv.Rect(left, top, width * volume / peak, bottom - top,
                                          data="frvp_volume", paint=ft.Paint(color=ft.Colors.with_opacity(.55, color))))
            # Represent adjacent identical levels as one step, sampling only at subpixel zoom.
            begin = max(first, self.start)
            end = min(last + 1, self.start + self.span)
            stride = max(1, math.ceil(2 / self.step))
            i = begin
            previous = None
            while i < end:
                levels = developing[i-first]
                j = min(i+stride, end)
                while j < end and developing[j-first] == levels:
                    j = min(j+stride, end)
                if levels is not None:
                    lower, center, upper = levels
                    x1 = (i-self.start) * self.step
                    x2 = (j-self.start) * self.step
                    # Hit-test geometry is kept separately; never painted on the canvas.
                    top, bottom = max(0, y(upper)), min(self.plot_height, y(lower))
                    if bottom >= top:
                        hit_regions.append(cv.Rect(x1, top, x2-x1, max(1, bottom-top), data="ta_hit"))
                    for index, color, width, role in ((0, "#FFFFFF", 1, "ta_lower"),
                                                      (2, "#FFFFFF", 1, "ta_upper"),
                                                      (1, "#FFBE55", 2, "poc")):
                        py = y(levels[index])
                        self._segment(shapes, (x1, py), (x2, py), color, width, data=role)
                        if previous is not None and previous[index] != levels[index]:
                            self._segment(shapes, (x1, y(previous[index])), (x1, py), color, width, data=role)
                    previous = levels
                i = j
            if drawing.get("fixed_poc") and 0 <= y(poc) <= self.plot_height:
                line(left, y(poc), right, y(poc), "#FF8C42", 2)
                text(left + 2, max(0, y(poc) - 12), f"Sabit POC {poc:.6g}", "#FF8C42")
            label_x = max(left, right-89)
            text(label_x, 16, "Gelişen POC", "#FFBE55")
            text(label_x, 29, "Gelişen TA", "#64C9E8")

        self.drawing_shapes = []
        self.shared_shapes = []
        local_ids = {id(d) for d in self.drawings}
        for drawing in [*getattr(self, "shared_drawings", []), *self.drawings]:
            if isinstance(drawing, dict) and drawing.get("hidden"):
                continue
            # Bounded shapes entirely outside the horizontal viewport need no geometry.
            if isinstance(drawing, dict) and drawing.get("tool") in ("rectangle", "triangle", "polygon", "pen", "line"):
                anchors = self._anchor_items(drawing)
                ix = [self.bar_index.get(p[0]) for _, p in anchors]
                if len(ix) >= 2 and all(i is not None for i in ix):
                    if max(ix) < self.start or min(ix) >= self.start + self.span:
                        continue
            first_shape = len(shapes)
            hit_regions = []
            if isinstance(drawing, dict) and drawing.get("tool") != "line":
                if drawing.get("tool") == "frvp":
                    draw_profile(drawing)
                elif drawing.get("tool") == "vline":
                    index = self.bar_index.get(drawing["date"])
                    if index is not None:
                        px = x(index - self.start)
                        if 0 <= px <= self.plot_width:
                            line(px, 0, px, volume_base, "#D4A3FF")
                            text(min(px + 3, self.plot_width - 70), 2, drawing["date"][:10], "#D4A3FF")
                elif drawing.get("tool") == "arrow":
                    self._arrow(shapes, drawing["point"], drawing["dir"])
                elif drawing.get("tool") == "fib":
                    self._fib(shapes, drawing["a"], drawing["b"])
                elif drawing.get("tool") in CHANNEL_TOOLS.values():
                    self._channel(shapes, drawing["a"], drawing["b"], drawing["c"], drawing["tool"])
                elif drawing.get("tool") in EXTRA_TOOLS.values():
                    self._extra_drawing(shapes, drawing["tool"], drawing["a"], drawing["b"])
                elif drawing.get("tool") in PATTERN_LABELS:
                    self._pattern(shapes, drawing["tool"], drawing["points"])
                elif drawing.get("tool") == "polygon":
                    points = drawing["points"]
                    if len(points) >= 3:
                        self._stroke(shapes, points + [points[0]])
                elif drawing.get("tool") == "pen":
                    self._stroke(shapes, drawing["points"])
                elif drawing.get("tool") == "text":
                    pos = coords(drawing["point"])
                    if pos and 0 <= pos[0] < self.plot_width and 0 <= pos[1] < self.plot_height:
                        shapes.append(cv.Text(*pos, drawing["text"], max_width=max(1, self.plot_width-pos[0]),
                                              max_lines=1, style=ft.TextStyle(size=12, color="#FACC15")))
            else:
                start, end = drawing["points"] if isinstance(drawing, dict) else drawing
                py = y(start[1])
                if end is None and 0 <= py <= self.plot_height:
                    line(0, py, self.plot_width, py, "#D4A3FF")
                elif end is not None:
                    segment(coords(start), coords(end))
            parts = shapes[first_shape:]
            if isinstance(drawing, dict) and drawing.get("style"):
                color = drawing["style"].get("color")
                width = drawing["style"].get("width")
                for part in parts:
                    if isinstance(part, cv.Line):
                        if color and part.data not in ("ta_lower", "ta_upper"):
                            part.paint.color = color
                        if width:
                            part.paint.stroke_width = width
                    elif isinstance(part, cv.Rect) and color and part.data != "frvp_volume":
                        opacity = .07 if drawing["tool"] == "fib" else .55
                        part.paint.color = ft.Colors.with_opacity(opacity, color)
                    elif isinstance(part, cv.Text):
                        if color:
                            part.style.color = color
                        if width and drawing["tool"] == "text":
                            part.style.weight = {1: ft.FontWeight.W_300, 2: ft.FontWeight.W_400,
                                                 3: ft.FontWeight.W_500, 4: ft.FontWeight.W_700,
                                                 6: ft.FontWeight.W_900}[width]
            if isinstance(drawing, dict) and drawing.get("style") and drawing.get("tool") != "frvp":
                style = drawing["style"]
                fill = style.get("fill")
                if fill:
                    parts[0:0] = self._drawing_fill(drawing, fill, style.get("color"))
                rendered = []
                for part in parts:
                    if isinstance(part, cv.Line):
                        if "opacity" in style:
                            part.paint.color = ft.Colors.with_opacity(style["opacity"], part.paint.color)
                        dash = style.get("dash")
                        if dash in ("dash", "dot"):
                            dx,dy = part.x2-part.x1,part.y2-part.y1
                            length = math.hypot(dx,dy)
                            step, ink = (12,7) if dash=="dash" else (6,2)
                            if length:
                                for i in range(0,math.ceil(length),step):
                                    a,b = i/length,min(length,i+ink)/length
                                    rendered.append(cv.Line(part.x1+dx*a,part.y1+dy*a,part.x1+dx*b,part.y1+dy*b,paint=part.paint))
                            continue
                    rendered.append(part)
                shapes[first_shape:] = rendered
            if id(drawing) in local_ids:
                self.drawing_shapes.append((drawing, parts + hit_regions))
            else:
                self.shared_shapes.append((drawing, parts + hit_regions))
        self.canvas.shapes = shapes
        if update:
            self.canvas.update()
        self.redraw_overlay(update=update)

    def _drawing_fill(self, drawing, opacity, color=None):
        tool = drawing.get("tool")
        if tool not in ("rectangle", "circle", "ellipse", "triangle", "polygon", "rotated_rect", "channel", "flat_channel", "disjoint_channel", "fib_channel"):
            return []
        if tool == "polygon":
            points = [self._coords(p) for p in drawing["points"]]
        else:
            a,b = (self._coords(drawing[k]) for k in ("a","b"))
            if a is None or b is None: return []
            if tool == "rectangle":
                points = [a,(b[0],a[1]),b,(a[0],b[1])]
            elif tool in ("circle","ellipse"):
                if tool == "circle":
                    cx,cy = a; rx = ry = math.dist(a,b)
                else:
                    cx,cy = (a[0]+b[0])/2,(a[1]+b[1])/2
                    rx,ry = abs(a[0]-b[0])/2,abs(a[1]-b[1])/2
                points = [(cx+rx*math.cos(i*math.tau/96),cy+ry*math.sin(i*math.tau/96)) for i in range(96)]
            else:
                c = self._coords(drawing["c"])
                if c is None: return []
                dx,dy = b[0]-a[0],b[1]-a[1]
                if tool == "triangle": points = [a,b,c]
                elif tool == "rotated_rect":
                    length = math.hypot(dx,dy)
                    if not length: return []
                    nx,ny = -dy/length,dx/length
                    offset = (c[0]-a[0])*nx+(c[1]-a[1])*ny
                    points = [a,b,(b[0]+nx*offset,b[1]+ny*offset),(a[0]+nx*offset,a[1]+ny*offset)]
                elif tool == "flat_channel": points = [a,b,(b[0],c[1]),(a[0],c[1])]
                elif tool == "disjoint_channel": points = [a,b,(c[0]+dx,c[1]+dy),c]
                else:
                    if not dx: return []
                    offset = c[1]-a[1]-dy*(c[0]-a[0])/dx
                    points = [a,b,(b[0],b[1]+offset),(a[0],a[1]+offset)]
        if len(points)<3 or any(p is None for p in points): return []
        # Nonoverlapping clipped scanlines support concave polygons without a native path dependency.
        top = max(0,min(p[1] for p in points)); bottom = min(self.plot_height,max(p[1] for p in points))
        paint = ft.Paint(color=ft.Colors.with_opacity(opacity,color or ("#80CFFF" if "channel" in tool else "#D4A3FF")))
        edges = list(zip(points,points[1:]+points[:1])); result=[]
        y=top
        while y<bottom:
            h=min(2,bottom-y); mid=y+h/2
            xs=sorted(a[0]+(mid-a[1])*(b[0]-a[0])/(b[1]-a[1]) for a,b in edges if min(a[1],b[1])<=mid<max(a[1],b[1]))
            for l,r in zip(xs[::2],xs[1::2]):
                l,r=max(0,l),min(self.plot_width,r)
                if r>l: result.append(cv.Rect(l,y,r-l,h,paint=paint,data="drawing_fill"))
            y+=h
        return result

    def _x(self, index):
        return (index + 0.5) * self.step

    def _y(self, price):
        return (self.high - price) / (self.high - self.low) * self.plot_height

    def _coords(self, point):
        index = self.bar_index.get(point[0])
        if index is not None:
            return self._x(index - self.start), self._y(point[1])

    def _segment(self, shapes, a, b, color="#D4A3FF", width=2, data=None):
        clipped = self._clipped_segment(a, b)
        if clipped:
            shapes.append(cv.Line(*clipped, data=data, paint=ft.Paint(color=color, stroke_width=width)))

    def _clipped_segment(self, a, b, ray=False):
        # Clip in both dimensions so partially visible drawings survive zoom and pan.
        if a is None or b is None:
            return
        left, right = 0.0, math.inf if ray else 1.0
        for origin, target, limit in zip(a, b, (self.plot_width, self.plot_height)):
            delta = target - origin
            if delta == 0:
                if not 0 <= origin <= limit:
                    return
                continue
            first, last = sorted((-origin / delta, (limit - origin) / delta))
            left, right = max(left, first), min(right, last)
            if left > right:
                return
        dx, dy = b[0] - a[0], b[1] - a[1]
        if not math.isfinite(right):
            return
        return a[0] + left * dx, a[1] + left * dy, a[0] + right * dx, a[1] + right * dy

    @staticmethod
    def position_metrics(tool,a,b,c):
        entry, target, stop = a[1], b[1], c[1]
        direction = 1 if tool == "long_position" else -1
        reward, risk = direction*(target-entry), direction*(entry-stop)
        if min(entry,target,stop,risk,reward)<=1e-9:
            return None
        return reward/risk, 100*reward/entry, 100*risk/entry

    def position_handles(self):
        target = getattr(self,"selected_position",None)
        if not target or target.get("locked") or target.get("hidden") or not any(d is target for d in [*self.drawings, *getattr(self, "shared_drawings", [])]): return
        a,b = self._coords(target["a"]),self._coords(target["b"])
        if a is None or b is None: return
        left,right=sorted((a[0],b[0]))
        if right<0 or left>self.plot_width: return
        px=max(5,min(self.plot_width-5,right))
        for field in ("a","b","c"):
            py=self._y(target[field][1])
            if 0<=py<=self.plot_height: yield field,px,py

    def _position(self,shapes,tool,a,b,c):
        metrics=self.position_metrics(tool,a,b,c)
        pa,pb=self._coords(a),self._coords(b)
        if not metrics or pa is None or pb is None: return
        left,right=max(0,min(pa[0],pb[0])),min(self.plot_width,max(pa[0],pb[0]))
        if right<=left: return
        rr,gain,loss=metrics
        for price,color,role in ((b[1],"#089981","reward"),(c[1],"#F23645","risk")):
            top=max(0,min(self._y(price),pa[1])); bottom=min(self.plot_height,max(self._y(price),pa[1]))
            if bottom>top: shapes.append(cv.Rect(left,top,right-left,bottom-top,data="position_"+role,paint=ft.Paint(color=ft.Colors.with_opacity(.22,color))))
        for price,color,label in ((b[1],"#4ADE80",f"Hedef {b[1]:.6g} (+{gain:.2f}%)"),(a[1],"#FFFFFF",f"Giriş {a[1]:.6g} | R/K {rr:.2f}"),(c[1],"#FF7070",f"Stop {c[1]:.6g} (-{loss:.2f}%)")):
            py=self._y(price)
            if 0<=py<=self.plot_height:
                self._segment(shapes,(left,py),(right,py),color)
                shapes.append(cv.Text(left+3,max(0,py-15),label,max_width=max(1,self.plot_width-left-3),style=ft.TextStyle(size=11,color=color)))

    def _channel(self, shapes, a, b, c, tool="channel"):
        if tool in POSITION_TOOLS.values():
            self._position(shapes,tool,a,b,c)
            return
        pa, pb, pc = self._coords(a), self._coords(b), self._coords(c)
        if pa is None or pb is None or pc is None:
            return
        if tool == "fib_extension":
            self._segment(shapes, pa, pb)
            self._segment(shapes, pb, pc)
            for ratio, color in FIB_LEVELS:
                py = self._y(c[1] + (b[1]-a[1])*ratio)
                self._segment(shapes, (pc[0], py), (self.plot_width, py), color, 1)
            return
        if tool == "fib_channel":
            if pa[0] == pb[0]:
                return
            offset = pc[1] - (pa[1]+(pb[1]-pa[1])*(pc[0]-pa[0])/(pb[0]-pa[0]))
            for ratio, color in FIB_LEVELS:
                self._segment(shapes, (pa[0],pa[1]+offset*ratio), (pb[0],pb[1]+offset*ratio), color, 1)
            return
        if tool in SHAPE_TOOLS.values():
            self._geometric(shapes, pa, pb, pc, tool)
            return
        if pa[0] == pb[0]:
            return
        if tool in ("pitchfork", "schiff", "modified_schiff", "inside_pitchfork"):
            origin = pa
            if tool == "schiff":
                origin = (pa[0], (pa[1]+pb[1])/2)
            elif tool == "modified_schiff":
                origin = ((pa[0]+pb[0])/2, (pa[1]+pb[1])/2)
            elif tool == "inside_pitchfork":
                origin = ((pa[0]+pb[0])/2, pa[1])
            mid = ((pb[0]+pc[0])/2, (pb[1]+pc[1])/2)
            dx, dy = mid[0]-origin[0], mid[1]-origin[1]
            if abs(dx)+abs(dy) < 1e-9:
                return
            self._segment(shapes, pb, pc, "#80CFFF", 1)
            for point, width in ((origin, 1), (pb, 2), (pc, 2)):
                clipped = self._clipped_segment(point, (point[0]+dx, point[1]+dy), ray=True)
                if clipped:
                    shapes.append(cv.Line(*clipped, paint=ft.Paint(color="#80CFFF", stroke_width=width)))
            return
        if tool == "disjoint_channel":
            self._segment(shapes, pa, pb, "#80CFFF")
            self._segment(shapes, pc, (pc[0]+pb[0]-pa[0], pc[1]+pb[1]-pa[1]), "#80CFFF")
            return
        if tool == "flat_channel":
            self._segment(shapes, pa, pb, "#80CFFF")
            self._segment(shapes, (pa[0],pc[1]), (pb[0],pc[1]), "#80CFFF")
            return
        offset = pc[1] - (pa[1] + (pb[1]-pa[1]) * (pc[0]-pa[0]) / (pb[0]-pa[0]))
        for fraction, width in ((0, 2), (1, 2), (.5, 1)):
            dy = offset * fraction
            self._segment(shapes, (pa[0], pa[1]+dy), (pb[0], pb[1]+dy), "#80CFFF", width)

    def _geometric(self, shapes, a, b, c, tool):
        if tool == "triangle":
            points = [a,b,c,a]
        elif tool == "rotated_rect":
            dx,dy = b[0]-a[0],b[1]-a[1]
            length = math.hypot(dx,dy)
            if length < 1:
                return
            nx,ny = -dy/length,dx/length
            offset = (c[0]-a[0])*nx+(c[1]-a[1])*ny
            points = [a,b,(b[0]+nx*offset,b[1]+ny*offset),(a[0]+nx*offset,a[1]+ny*offset),a]
        elif tool == "curve":
            points = [((1-t)**2*a[0]+2*t*(1-t)*c[0]+t*t*b[0], (1-t)**2*a[1]+2*t*(1-t)*c[1]+t*t*b[1]) for t in (i/64 for i in range(65))]
        elif tool == "arc":
            # Circular arc from a to b through c, or a polyline for collinear points.
            ax,ay=a; bx,by=b; cx,cy=c
            d=2*(ax*(by-cy)+bx*(cy-ay)+cx*(ay-by))
            if abs(d)<1e-8:
                points=[a,c,b]
            else:
                aa=ax*ax+ay*ay; bb=bx*bx+by*by; cc=cx*cx+cy*cy
                ux=(aa*(by-cy)+bb*(cy-ay)+cc*(ay-by))/d
                uy=(aa*(cx-bx)+bb*(ax-cx)+cc*(bx-ax))/d
                start=math.atan2(ay-uy,ax-ux); end=(math.atan2(by-uy,bx-ux)-start)%math.tau
                middle=(math.atan2(cy-uy,cx-ux)-start)%math.tau
                if middle>end: end-=math.tau
                r=math.hypot(ax-ux,ay-uy)
                points=[(ux+r*math.cos(start+end*i/96),uy+r*math.sin(start+end*i/96)) for i in range(97)]
        else:
            return
        for u,v in zip(points,points[1:]):
            self._segment(shapes,u,v,"#D4A3FF")

    def _extra_drawing(self, shapes, tool, a, b):
        """Two candle/price anchors; same renderer for live preview and saved drawings."""
        pa, pb = self._coords(a), self._coords(b)
        if pa is None or pb is None:
            return
        if tool == "gann_box":
            for ratio in (0,.25,.5,.75,1):
                x = pa[0]+(pb[0]-pa[0])*ratio
                y = pa[1]+(pb[1]-pa[1])*ratio
                self._segment(shapes,(x,pa[1]),(x,pb[1]),"#80CFFF",1)
                self._segment(shapes,(pa[0],y),(pb[0],y),"#80CFFF",1)
            self._segment(shapes,pa,pb,"#D4A3FF")
        elif tool == "gann_fan":
            for ratio in (.125,.25,.333333,.5,1,2,3,4,8):
                target=(pb[0],pa[1]+(pb[1]-pa[1])*ratio)
                clipped=self._clipped_segment(pa,target,ray=True)
                if clipped:
                    shapes.append(cv.Line(*clipped,paint=ft.Paint(color="#80CFFF",stroke_width=1)))
        elif tool == "fib_circles":
            radius=math.hypot(pb[0]-pa[0],pb[1]-pa[1])
            for ratio,color in FIB_LEVELS:
                if not ratio: continue
                points=[(pa[0]+radius*ratio*math.cos(i*math.tau/64),pa[1]+radius*ratio*math.sin(i*math.tau/64)) for i in range(65)]
                for u,v in zip(points,points[1:]): self._segment(shapes,u,v,color,1)
        elif tool == "trend_angle":
            self._segment(shapes, pa, pb, "#80CFFF")
            self._segment(shapes, pa, (pb[0], pa[1]), "#80CFFF", 1)
            angle = math.degrees(math.atan2(pa[1]-pb[1], abs(pb[0]-pa[0])))
            if 0 <= pa[0] < self.plot_width and 0 <= pa[1] < self.plot_height:
                shapes.append(cv.Text(pa[0], max(0,pa[1]-18), f"{angle:+.1f}° (ekran)", style=ft.TextStyle(size=12,color="#80CFFF")))
        elif tool == "regression":
            first, last = sorted((self.bar_index[a[0]], self.bar_index[b[0]]))
            values = [bar[4] for bar in self.history[first:last+1]]
            n = len(values)
            if n < 2:
                return
            center = (n-1)/2
            mean = sum(values)/n
            slope = sum((i-center)*(v-mean) for i,v in enumerate(values))/sum((i-center)**2 for i in range(n))
            base = mean-slope*center
            sd = math.sqrt(sum((v-base-slope*i)**2 for i,v in enumerate(values))/n)
            for factor, width in ((-2,2),(0,1),(2,2)):
                self._segment(shapes,(self._x(first-self.start),self._y(base+factor*sd)),(self._x(last-self.start),self._y(base+slope*(n-1)+factor*sd)),"#80CFFF",width)
        elif tool == "ray":
            clipped = self._clipped_segment(pa, pb, ray=True)
            if clipped:
                shapes.append(cv.Line(*clipped, paint=ft.Paint(color="#80CFFF", stroke_width=2)))
        elif tool in ("horizontal_ray", "extended_line"):
            if tool == "horizontal_ray":
                pb = (pb[0], pa[1])
                if pb == pa:
                    return
            pairs = [(pa, pb)] if tool == "horizontal_ray" else [(pa, pb), (pb, pa)]
            for u, v in pairs:
                clipped = self._clipped_segment(u, v, ray=True)
                if clipped:
                    shapes.append(cv.Line(*clipped, paint=ft.Paint(color="#80CFFF", stroke_width=2)))
        elif tool == "ellipse":
            cx, cy = (pa[0]+pb[0])/2, (pa[1]+pb[1])/2
            rx, ry = abs(pb[0]-pa[0])/2, abs(pb[1]-pa[1])/2
            if min(rx, ry) < 1:
                return
            points = [(cx+rx*math.cos(i*math.tau/96), cy+ry*math.sin(i*math.tau/96)) for i in range(97)]
            for u,v in zip(points,points[1:]):
                self._segment(shapes,u,v)
        elif tool == "fib_time":
            step = pb[0]-pa[0]
            if not step:
                return
            for n in (0,1,2,3,5,8,13,21,34,55):
                px = pa[0]+n*step
                if 0 <= px <= self.plot_width:
                    self._segment(shapes,(px,0),(px,self.plot_height),"#80CFFF",1)
        elif tool == "fib_fan":
            for ratio,color in FIB_LEVELS:
                if not 0 < ratio <= 1:
                    continue
                target = (pb[0],pa[1]+ratio*(pb[1]-pa[1]))
                clipped = self._clipped_segment(pa,target,ray=True)
                if clipped:
                    shapes.append(cv.Line(*clipped,paint=ft.Paint(color=color,stroke_width=1)))
        elif tool in ("price_range", "date_range"):
            if tool == "price_range":
                end = (pa[0],pb[1])
                delta = b[1]-a[1]
                label = f"{delta:+.6g} ({delta/a[1]*100:+.2f}%)" if a[1] else f"{delta:+.6g}"
            else:
                end = (pb[0],pa[1])
                count = abs(self.bar_index[b[0]]-self.bar_index[a[0]])
                label = f"{count} mum"
                try:
                    elapsed = abs(datetime.fromisoformat(b[0])-datetime.fromisoformat(a[0]))
                    label += f" · {elapsed}"
                except ValueError:
                    pass
            self._segment(shapes,pa,end,"#80CFFF")
            if self._clipped_segment(pa,end):
                px = max(0,min(pa[0],self.plot_width-100))
                py = max(0,min(pa[1]-18,self.plot_height-18))
                shapes.append(cv.Text(px,py,label,max_width=max(1,self.plot_width-px),style=ft.TextStyle(size=12,color="#80CFFF")))
        elif tool == "circle":
            # A true screen circle: first point is center, second point is on its rim.
            radius = math.hypot(pb[0]-pa[0], pb[1]-pa[1])
            if radius < 1:
                return
            # Clipped line segments also support existing selection and styling.
            n = min(256, max(48, math.ceil(radius / 3)))
            points = [(pa[0] + radius * math.cos(2*math.pi*i/n),
                       pa[1] + radius * math.sin(2*math.pi*i/n)) for i in range(n+1)]
            for u, v in zip(points, points[1:]):
                self._segment(shapes, u, v, "#D4A3FF")
        elif tool == "measure":
            delta = b[1] - a[1]
            color = "#4ADE80" if delta >= 0 else "#F472B6"
            self._segment(shapes, pa, (pb[0], pa[1]), color)
            self._segment(shapes, (pb[0], pa[1]), pb, color)
            self._segment(shapes, pa, pb, color, 1)
            pct = f"{100*delta/a[1]:+.2f}%" if a[1] else "—%"
            count = abs(self.bar_index[b[0]] - self.bar_index[a[0]])
            value = f"{delta:+.6g} ({pct}) · {count} mum"
            if self._clipped_segment(pa, pb):
                px = max(0, min((pa[0]+pb[0])/2, self.plot_width-len(value)*7))
                py = max(0, min(min(pa[1], pb[1])-18, self.plot_height-18))
                shapes.append(cv.Text(px, py, value, max_width=max(1, self.plot_width-px),
                                      style=ft.TextStyle(size=12, color=color)))
        elif tool == "rectangle":
            left, right = sorted((pa[0], pb[0]))
            top, bottom = sorted((pa[1], pb[1]))
            if right - left < 1 or bottom - top < 1:
                return
            self._segment(shapes, (left, top), (right, top), "#D4A3FF")
            self._segment(shapes, (right, top), (right, bottom), "#D4A3FF")
            self._segment(shapes, (right, bottom), (left, bottom), "#D4A3FF")
            self._segment(shapes, (left, bottom), (left, top), "#D4A3FF")

    def _arrow(self, shapes, point, direction):
        position = self._coords(point)
        if position is None or not (0 <= position[0] <= self.plot_width and 0 <= position[1] <= self.plot_height):
            return
        px, py = position
        sign = 1 if direction == "up" else -1  # yukarı ok: gövde ucun altında
        color = ARROWS["Yukarı ok" if direction == "up" else "Aşağı ok"][1]
        for x1, y1, x2, y2, width in ((px, py + sign * 26, px, py + sign * 2, 4),
                                      (px, py, px - 8, py + sign * 11, 4), (px, py, px + 8, py + sign * 11, 4),
                                      (px - 5, py + sign * 8, px + 5, py + sign * 8, 3)):
            shapes.append(cv.Line(x1, y1, x2, y2, paint=ft.Paint(color=color, stroke_width=width)))

    def _accumulation(self, shapes):
        key = (self.start, self.span)
        if key not in self.accumulation_cache:
            if self.swing_indices is None:
                self.swing_indices = swing_highs(self.history)
            if len(self.accumulation_cache) >= 128:
                self.accumulation_cache.clear()
            self.accumulation_cache[key] = accumulation(self.history, max(0, self.start), self.span + min(0, self.start), highs=self.swing_indices)
        info = self.accumulation_cache[key]
        if not info:
            return
        py = self._y(info["level"])
        if not 0 <= py <= self.plot_height:
            return
        first = self._x(info["peak"] - self.start)
        if first > self.plot_width:
            return
        end = info["end"]
        if end is None or end - self.start >= self.span:
            last, reached = self.plot_width, False
        else:
            last, reached = self._x(end - self.start), True
        if last < 0:
            return
        first = max(0, first)
        shapes.append(cv.Line(first, py, last, py, paint=ft.Paint(color=ACCUMULATION, stroke_width=2)))
        shapes.append(cv.Text(first + 4, max(0, py - 14), f"Akümülasyon  {info['level']:.6g}",
                              style=ft.TextStyle(size=11, color=ACCUMULATION)))
        if reached:
            shapes.append(cv.Rect(last - 3, py - 3, 6, 6, paint=ft.Paint(color=ACCUMULATION)))

    def _visible_volume(self, shapes, bars):
        key = (self.start, self.span)
        if key not in self.volume_cache:
            if len(self.volume_cache) >= 128:
                self.volume_cache.clear()
            self.volume_cache[key] = profile_bins(bars)
        val, poc, vah, low, step, volumes = self.volume_cache[key]
        peak = max(volumes)
        if peak <= 0 or step == 0:
            return
        reach = self.plot_width * 0.30
        for i, volume in enumerate(volumes):
            lower = low + i * step
            upper = lower + step
            top, bottom = max(0, self._y(upper)), min(self.plot_height, self._y(lower))
            if bottom > top and volume > 0:
                color = "#628FC1" if val <= (lower + upper) / 2 <= vah else "#758094"
                width = reach * volume / peak
                shapes.append(cv.Rect(0, top, width, bottom - top,
                                      paint=ft.Paint(color=ft.Colors.with_opacity(0.5, color))))
        for name, price, color in (("VAH", vah, "#80CFFF"), ("VAL", val, "#80CFFF"), ("POC", poc, "#FFBE55")):
            py = self._y(price)
            if 0 <= py <= self.plot_height:
                shapes.append(cv.Line(0, py, reach, py,
                                      paint=ft.Paint(color=color, stroke_width=1)))
                shapes.append(cv.Text(2, max(0, py - 12), f"{name} {price:.6g}",
                                      style=ft.TextStyle(size=10, color=color)))

    def _fib(self, shapes, a, b):
        start, end = self._coords(a), self._coords(b)
        if start is None or end is None:
            return
        left = max(0, min(start[0], end[0]))
        if left >= self.plot_width:
            return
        width = self.plot_width - left
        prices = [(level, color, b[1] + (a[1] - b[1]) * level) for level, color in FIB_LEVELS]
        for (first, color, upper), (second, _, lower) in zip(prices, prices[1:]):
            if second > 1:
                break
            top = max(0, min(self._y(upper), self._y(lower)))
            bottom = min(self.plot_height, max(self._y(upper), self._y(lower)))
            if bottom > top:
                shapes.append(cv.Rect(left, top, width, bottom - top,
                                      paint=ft.Paint(color=ft.Colors.with_opacity(0.07, color))))
        self._segment(shapes, start, end, "#D4A3FF", 1)
        for level, color, price in prices:
            py = self._y(price)
            if 0 <= py <= self.plot_height:
                shapes.append(cv.Line(left, py, self.plot_width, py, paint=ft.Paint(color=color, stroke_width=1)))
                shapes.append(cv.Text(left + 3, max(0, py - 12), f"{level:g}  ({price:.6g})",
                                      style=ft.TextStyle(size=10, color=color)))

    def _stroke(self, shapes, points):
        if not points:
            return
        previous = self._coords(points[0])
        if len(points) == 1 and previous:
            self._segment(shapes, previous, (previous[0] + 1, previous[1]))
        for point in points[1:]:
            current = self._coords(point)
            self._segment(shapes, previous, current)
            previous = current

    def _pattern(self, shapes, kind, points):
        labels = PATTERN_LABELS[kind]
        coords = [self._coords(p) for p in points]
        color = "#80CFFF" if kind.startswith("elliott") else "#D4A3FF"
        for a, b in zip(coords, coords[1:]):
            self._segment(shapes, a, b, color)
        if kind in ("head_shoulders", "inverse_head_shoulders") and len(coords) >= 5:
            self._segment(shapes, coords[2], coords[4], "#FACC15", 1)
        for pos, label in zip(coords, labels):
            if pos is not None and 0 <= pos[0] <= self.plot_width and 0 <= pos[1] <= self.plot_height:
                shapes.append(cv.Text(max(0, min(pos[0]+4, self.plot_width-55)),
                                      max(0, pos[1]-15), label, style=ft.TextStyle(size=11, color=color)))

    def redraw_overlay(self, update=True):
        """Cheap layer: pen stroke, anchors, crosshair and OHLC line. Redrawn on every hover."""
        shapes = []
        x, y, indices = self._x, self._y, self.indices
        volume_base, axis_width = self.volume_base, self.axis_width

        def line(x1, y1, x2, y2, color, width=1):
            shapes.append(cv.Line(x1, y1, x2, y2, paint=ft.Paint(color=color, stroke_width=width)))

        def text(px, py, value, color=TEXT, size=10):
            shapes.append(cv.Text(px, py, value, style=ft.TextStyle(size=size, color=color)))

        self._stroke(shapes, self.stroke)
        for _,px,py in self.shape_handles():
            shapes.append(cv.Rect(px-4,py-4,8,8,paint=ft.Paint(color="#FFFFFF")))
        for field,px,py in self.position_handles():
            shapes.append(cv.Rect(px-4,py-4,8,8,paint=ft.Paint(color="#FFFFFF")))
        if self.tool in PATTERN_TOOLS and self.pattern_points:
            points = self.pattern_points + ([self.cursor] if self.cursor and self.cursor != self.pattern_points[-1] else [])
            self._pattern(shapes, PATTERN_TOOLS[self.tool][0], points)
        if self.tool == "Çokgen" and self.polygon_points:
            self._stroke(shapes, self.polygon_points + ([self.cursor] if self.cursor else []))
        if self.anchor and self.cursor:
            if self.tool == "Sabit hacim (FRVP)":
                for point in (self.anchor, self.cursor):
                    px, _ = self._coords(point)
                    if 0 <= px <= self.plot_width:
                        line(px, 0, px, self.plot_height, "#80CFFF")
            elif self.tool == "Fibonacci":
                self._fib(shapes, self.anchor, self.cursor)
            elif self.tool in CHANNEL_TOOLS and self.channel_end is not None:
                self._channel(shapes, self.anchor, self.channel_end, self.cursor, CHANNEL_TOOLS[self.tool])
            elif self.tool in EXTRA_TOOLS:
                self._extra_drawing(shapes, EXTRA_TOOLS[self.tool], self.anchor, self.cursor)
            else:
                self._segment(shapes, self._coords(self.anchor), self._coords(self.cursor))
        if self.anchor and self.anchor[0] in indices:
            line(x(indices[self.anchor[0]]) - 4, y(self.anchor[1]), x(indices[self.anchor[0]]) + 4,
                 y(self.anchor[1]), "#D4A3FF", 2)
        if self.cursor is not None:
            date, price = self.cursor
            index = indices[date]
            _, op, high, low, close, volume = self.history[self.start + index]
            style = self.cursor_style
            if style != "Sadece bilgi":
                line(x(index), 0, x(index), volume_base, TEXT)
                label = date if len(date) > 10 else date[:10]
                label_width = 8 * len(label) + 6
                left = max(0, min(x(index) - label_width / 2, self.plot_width - label_width))
                shapes.append(cv.Rect(left, volume_base + 1, label_width, 14, paint=ft.Paint(color="#34485A")))
                text(left + 3, volume_base + 2, label, "#FFFFFF", size=9)
            if style in ("Çapraz", "Mıknatıslı çapraz"):
                line(0, y(price), self.plot_width, y(price), TEXT)
                shapes.append(cv.Rect(self.plot_width, y(price) - 7, axis_width, 15, paint=ft.Paint(color="#34485A")))
                text(self.plot_width + 4, y(price) - 7, f"{price:.6g}", "#FFFFFF", size=9)
            if style == "Mıknatıslı çapraz":
                shapes.append(cv.Rect(x(index) - 3, y(price) - 3, 6, 6, paint=ft.Paint(color="#FFFFFF")))
        else:
            date, op, high, low, close, volume = self.bars[-1]
        color = UP if close > op else DOWN if close < op else TEXT
        caption = f"{date}   A {op:.5g}   Y {high:.5g}   D {low:.5g}   K {close:.5g}   Hacim {volume:.5g}"
        if date in self.marks:
            caption += f"   {self.marks[date]}"
        if self.readout is None:
            text(4, volume_base + 21, caption, color)
        elif self.readout.value != caption or self.readout.color != color:
            self.readout.value = caption
            self.readout.color = color
            if update:
                self.readout.update()
        for field, px, py, caption in self.profile_handles():
            shapes.append(cv.Rect(px-5, py-5, 10, 10, paint=ft.Paint(color="#80CFFF")))
            if self.drag_endpoint == field and self.preview_date:
                caption += " " + self.preview_date
            text(max(0, min(px+8, self.plot_width - len(caption)*6)), py-6, caption, "#80CFFF")
        if self.pending_copy is not None:
            text(8, 18, "Kopyayı yerleştirmek için tıkla · Sağ tıkla iptal et", "#80CFFF")
        self.overlay.shapes = shapes
        if update:
            self.overlay.update()
