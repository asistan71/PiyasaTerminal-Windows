# -*- coding: utf-8 -*-
"""Yeni sürüm yayınlama yardımcısı: ZIP için manifest.json üretir.

  python guncelleme_hazirla.py PiyasaTerminal_v4.9.30_V39.zip --notlar "Kısa açıklama"
  python guncelleme_hazirla.py PiyasaTerminal_v4.9.30_V39.zip --adres https://site.com/dosyalar/PiyasaTerminal_v4.9.30_V39.zip

manifest.json ile ZIP'i aynı web klasörüne (GitHub Pages, kendi sunucunuz, paylaşılan bağlantı) yükleyin;
Güncelleme sekmesine manifest.json adresini yazın. --adres verilmezse ZIP, manifest'in yanından aranır.
"""
import argparse
import hashlib
import json
from pathlib import Path

import updater


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("zip")
    parser.add_argument("--adres", default="", help="ZIP'in tam web adresi (boşsa manifest'e göre göreli)")
    parser.add_argument("--notlar", default="")
    parser.add_argument("--cikti", default="", help="manifest.json yolu (varsayılan: ZIP'in yanı)")
    args = parser.parse_args()
    path = Path(args.zip)
    _, version = updater.inspect_zip(path)
    manifest = {"version": version, "url": args.adres or path.name,
                "sha256": hashlib.sha256(path.read_bytes()).hexdigest(), "notes": args.notlar}
    target = Path(args.cikti) if args.cikti else path.with_name("manifest.json")
    target.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"{target} yazıldı · sürüm {version}")


if __name__ == "__main__":
    main()
