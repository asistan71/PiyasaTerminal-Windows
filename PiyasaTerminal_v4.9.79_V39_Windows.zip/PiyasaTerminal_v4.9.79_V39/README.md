# Piyasa Terminali v4.9.56 + V39

Bu sürüm, v4.9'un on sekmeli Flet mobil arayüzüne V39 analiz işlevlerini ekler.
Dar ekranlarda alt menüyü yatay kaydırarak diğer sekmelere ulaşabilirsiniz.
Sinyaller ekranında Analiz ve Ayarlar düğmeleri bulunur.

```bash
python -m pip install -r requirements.txt
python piyasa_mobile.py
```

| Sekme | İçerik |
| --- | --- |
| BIST | 631 hisselik liste, pazar veya tek hisse seçimi, 1W/1D/1H analizi, canlı tarama ve CSV |
| EVRE | TL/Dolar/Pivot, ilk 10 erken fırsat, kayıtlı veri, 15 dk yenileme, yapı ve işlem planı |
| EVRE Alarm | Fırsat alarmı taraması, puan eşiği, isteğe bağlı ses |
| Dip Alarm ve Dip Hafıza | V39 Dip Hacim Radarı ve Dip Patlama Hafızası, SQLite arşivi, geçmiş olaylar ve CSV |
| Binance | TR ve USDT vadeli, 5m/15m/1h, BTC bağlamı, hazırlık etiketleri, canlı tarama ve CSV |
| Analiz | Geçmiş testler, kalkış takibi, sinyal geçmişi, hacim raporları, FRVP, veri ve algoritma karşılaştırması, tahmini para akışı ve Binance derinliği |
| Grafik | Mum ve hacim, TL/USD, EMA 20, VWAP, mum işaretleme, yatay FRVP profili ve fiyat seviyeleri |
| Favoriler ve İşlemler | Kalıcı favoriler, sanal alış/short, TL bakiye, işlem kapatma ve güncel K/Z |

BIST için V39 Android uyarlamasındaki Yahoo Finance katmanı kullanılır.
Windows V39'un borsapy verileriyle fiyat ve hacim farkları oluşabilir.
V39’un Windows’a özgü ayrı grafik penceresi, serbest çizgi/kalem araçları ve
BIST takas sağlayıcısı bu pakette bulunmaz. Grafik işaretleme seçilen muma uygulanır.

Önceki Flet V39 ile aynı veri dizini ve kayıt biçimleri kullanılır.
Android'de uygulama veri dizini, masaüstünde `~/.piyasa-terminali-flet`.
BIST ve Binance taramaları ve CSV oluşturma örnek veriyle sınanmıştır.
Android APK, canlı servisler ve cihazdaki kaydetme ekranı ayrıca doğrulanmalıdır.

`python -m unittest discover -s tests` ile testleri çalıştırabilirsiniz.

## Windows ve V39 tamamlamaları

ZIP dosyasını bir klasöre ayıklayın ve `BASLAT_WINDOWS.bat` dosyasını açın.
Python 3.10 veya daha yeni bir sürüm gerekir. İlk çalıştırmada bağımlılıklar
internet üzerinden uygulamaya özel sanal ortama kurulur.

Grafikte **Grafik Atölyesi** düğmesi çapraz imleci, yatay çizgi ve iki noktalı
trend çizgisini açar. Çizimler piyasa, sembol ve zaman dilimine göre saklanır.
İşlem seviyeleri mum grafiğinde yer alır. EMA ve VWAP etkinleştirildiğinde
aynı ölçeğe çizilir. Camarilla önceki dönemin verisini kullanır.
Uzun Camarilla dönemlerinde yeterli veri gerekiyorsa BIST günlük grafiğinde
**Tüm BIST geçmişini al** seçeneği bulunur.

Analiz bölümüne satış emilimi, erken hacimli kırılım, kalkış liste denetimi
ve 60/30/10 ile 70/40/10 karşılaştırması eklendi. Çoklu EVRE testinde her
hissenin test ayrıntısı ve ilgili sinyal mumu açılabilir.

Atölye uygulamanın Grafik sekmesinde çalışır. Windows V39'un ayrı Tkinter
penceresi, serbest kalem ve BIST takas sağlayıcısı henüz bulunmaz.

## Etkileşimli grafik

Bir hisse veya parite kartındaki grafik simgesine tıklayın. Fare tekerleği
imlecin altındaki mumu merkez alarak yakınlaştırır. İmleç aracı seçiliyken
fareyi basılı tutup sağa veya sola sürükleyerek geçmişe gidebilirsiniz.
Alt hacim sütunları fiyat mumlarıyla aynı zaman eksenini kullanır.
Çapraz imleç tarih, imleç fiyatı, açılış, yüksek, düşük, kapanış ve hacmi
gösterir. Son mum düğmesi görünümü mevcut verinin sonuna taşır.

## Geniş grafik alanı

Grafik yüksekliği artık pencere yüksekliğine göre otomatik ayarlanır. Grafik
sekmesinde kenar boşlukları daraltıldı. **Büyüt** düğmesi grafiği daha da uzatır.
**Tam ekran grafik** düğmesi başlığı, yan menüyü ve alt menüyü gizleyip yalnızca
grafiği ve araç çubuğunu bırakır. **Tam ekrandan çık** ile eski görünüme dönülür.

## İmleç performansı

Grafik tek tuvalde çizilir ama sabit şekiller önbelleğe alınır. Mumlar, hacim, seviyeler ve çizimler önbellekte,
çapraz imleç, fiyat etiketi, OHLC satırı ve kalem çizgisi her harekette yeniden üretilir.
Fare hareketinde yalnızca bu küçük kısım hesaplanır. Aynı noktada tekrar eden
fare olayları atlanır. Önbellek yalnızca kaydırma, yakınlaştırma veya yeni
çizimde yeniden çizilir.

## Rapor satırı ayrıntıları

Rapor tablosundaki üç çizgi simgesi satırın tüm alanlarını önem sırasına göre
listeler ve renklendirir: turuncu **Kritik** (sembol, tarih, puan, durum, sonuç),
mavi **Önemli** (giriş, başarı oranı, getiriler, POC/VAL/VAH, hacim oranı),
açık gri **Destekleyici** ve soluk gri **Teknik ayrıntı** (ham mum ve sayaç alanları).

## Grafik araçları (v4.9.5)

- **Sürükleyerek taşıma:** Sol tuşu basılı tutup sürükleyin, grafik yatay ve dikey her yöne
  taşınır. Çizim aracı seçiliyken de çalışır (Kalem hariç).
- **Fiyat ölçeği:** Sağdaki fiyat ekseninin üzerinde fare tekerleği veya yukarı/aşağı sürükleme
  fiyat ölçeğini büyütür ve küçültür. Eksene tıklamak ya da **Fiyat ölçeğini sıfırla**
  düğmesi otomatik ölçeğe döner.
- **Fibonacci:** Çizim aracı listesinden seçin, başlangıç ve bitiş noktasına tıklayın.
  Seviyeler 0, 0.236, 0.382, 0.5, 0.618, 0.786, 1, 1.272 ve 1.618'dir (1 başlangıçta,
  0 bitişte). Çizimler diğer çizimler gibi kaydedilir ve geri alınabilir.
- Çapraz imleç, mumun tarihini ve fiyatını gösterir.

## Akümülasyon, görünür hacim ve yeni araçlar (v4.9.6)

- **Akümülasyon:** VWAP düğmesinin yanındaki düğme. Görünen aralığın en düşük mumu dip kabul edilir.
  Dipten önceki son tepe ile dipten sonraki ilk tepe karşılaştırılır (her iki yanında 5 muma göre en
  yüksek mum tepedir). Yüksek olanın en yüksek fiyatından sağa turuncu yatay çizgi çekilir ve çizgi,
  seviyeye ilk ulaşan mumda biter. O muma henüz ulaşılmadıysa çizgi sağ kenara kadar uzar.
- **VWAP bantları ±1–4σ:** Tek düğme dört bant çiftini birlikte açıp kapatır. Geniş bantlar fiyat ölçeğini sıkıştırmasın diye
  otomatik ölçeğe katılmaz; gerekirse fiyat ekseninden ölçeği küçültün.
- **Görünür hacim:** Görünen mumların hacim profili sol kenarda, POC / VAH / VAL çizgileriyle.
  Kaydırma ve yakınlaştırmayla yeniden hesaplanır.
- **Dikey çizgi, Yukarı ok, Aşağı ok:** Çizim aracı listesinde. Çizimler kaydedilir ve geri alınır.

## Analiz sayfası (v4.9.9)

- **Kapsam düğmesi:** Rapor satırının altındaki tek düğme Tek (kırmızı), Tüm (yeşil) ve
  çoklu EVRE testinde Liste (mavi) arasında geçiş yapar.
- **Sıralama:** Tablo sütun başlığına tıklayın; yeniden tıklayınca yön değişir. Sayılar sayısal,
  metinler alfabetik sıralanır. Yeni rapor çalıştırınca sıralama sıfırlanır.
- **Seçili satır:** Bir hücreye, satır menüsüne veya grafik simgesine tıklayınca satır mavi ve kalın
  vurgulanır.
- **Kaldığın yerden devam:** Listeden grafiğe gidip Analiz'e dönünce aynı sayfa, kaydırma konumu ve
  seçili satır korunur.

## Güncelleme ve web arayüzü (v4.9.56)

**Bir kez kurun, sonra güncelleyin.** Paketi kalıcı bir klasöre (örneğin `C:\PiyasaTerminal`) çıkarıp
`BASLAT_WINDOWS.bat` ile açın. Sonraki sürümlerde ZIP'i yeniden çıkarmanız, `.venv` kurmanız veya
paket yüklemeniz gerekmez. Sol menüdeki **Sistem → Güncelleme** sekmesini kullanın:

- **ZIP dosyasından (internet gerekmez):** Yeni ZIP'i `Downloads` klasöründe bırakın veya programın
  `guncelleme` klasörüne koyun, **Yerel güncellemeleri ara** → **uygula**. Uygulama kendini yeniden açar.
- **İnternetten:** Güncelleme adresi alanına `manifest.json` adresini veya `github:kullanici/depo`
  yazın. Açılışta otomatik denetlenir, yeni sürüm varsa uyarır. Yayınlamak için
  `python guncelleme_hazirla.py PiyasaTerminal_vX_V39.zip` ZIP'in yanına `manifest.json` üretir;
  ikisini aynı web klasörüne yükleyin.
- **Güvenlik:** İndirilen dosya manifest'teki sha256 ile doğrulanır. İskelet veya eksik paketler uygulanmaz.
- **Geri alma:** Her güncellemeden önce değişen dosyaların yedeği alınır (son 5). **Önceki sürüme dön** düğmesi geri yükler.
- Favoriler, işlemler, SQLite arşivleri ve `.venv` güncellemede dokunulmaz. `requirements.txt`
  değişirse başlatıcı paketleri bir sonraki açılışta kendisi kurar.

**Web arayüzü:** `BASLAT_WEB.bat` aynı uygulamayı tarayıcıda açar (`http://localhost:8550`).
`BASLAT_WEB_AG.bat` yerel ağdaki telefon ve tabletlere açar; şifre yoktur, yalnızca güvendiğiniz ağda
kullanın. Komut satırı: `python piyasa_mobile.py --web [--lan] [--port 8550]`.
Tarayıcıda CSV kaydet, dosya penceresi yerine indirme bağlantısı açar.

### Yeni çizim araçları
- Işın: başlangıç ve yön noktası.
- Ölçüm / Ölçek: iki nokta arasında fiyat farkı, yüzde ve mum sayısı.
- Daire: merkez ve çember noktası.
