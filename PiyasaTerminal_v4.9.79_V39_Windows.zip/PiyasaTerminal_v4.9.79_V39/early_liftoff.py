"""Nedensel (ileri bakmayan) EVRE erken kalkış adayları.

İşaretlenen BORLS örneklerinden esinlenen genel fiyat/hacim davranış kurallarıdır;
gerçek BORLS serisinde kalibre edildiği iddia edilmez. POC teyidi üretmez.
"""
from __future__ import annotations
from statistics import mean
from math import isfinite
from prebreakout import prebreakout_candidates
from poc_context import approximate_poc


def _bar(bar):
    o, h, l, c, v = [float(bar[k]) for k in (1, 2, 3, 4, 5)]
    if not all(isfinite(x) for x in (o,h,l,c,v)) or not (0 < l <= min(o,c) <= max(o,c) <= h and v >= 0):
        raise ValueError('Geçersiz OHLCV')
    return o,h,l,c,v


def early_liftoff_signals(bars, asof_index=None, lookback=45, cooldown=4):
    """Sinyal i sadece bars[:i+1] ile hesaplanır; kapanıştan önce geçerli değildir.

    Başlangıç: düşük oynaklıklı taban + yükselen kapanış + hacim genişlemesi.
    Yeniden birikim: yakın geçmişte yükseliş + sıkışma + fiyatın korunması.
    Satış emilimi: yüksek hacimli kırmızı mum, alt fitil ve sınırlı fiyat kaybı.
    Her kayıt kendi gününe aittir; 'sonra doğrulandı' bilgisi eklenmez.
    """
    if not bars:
        return []
    last = min(len(bars)-1, len(bars)-1 if asof_index is None else int(asof_index))
    out=[]
    if last < 24:
        return out
    for i in range(max(24,last-lookback+1),last+1):
        try:
            current=[_bar(b) for b in bars[i-20:i+1]]
            o,h,l,c,v=current[-1]
            old=current[:-1]
            avg_vol=mean(x[4] for x in old)
            if avg_vol <= 0: continue
            rvol=v/avg_vol
            prev5=current[-6:-1]
            prev10=current[-11:-1]
            prev20=current[:-1]
            low10=min(x[2] for x in prev10)
            high10=max(x[1] for x in prev10)
            previous_close=prev20[-1][3]
            baseline=mean(x[3] for x in prev10)
            width=(high10-low10)/baseline if baseline>0 else 999
            loc=(c-l)/(h-l) if h>l else .5
            wick=(min(o,c)-l)/(h-l) if h>l else 0
            # Tarihsel bağlam: yükselişten sonraki konsolidasyonla dipten oluşumu ayır.
            old5=prev20[:5]
            prior_peak=max(x[1] for x in prev20)
            post_rise=prior_peak > min(x[2] for x in prev20)*1.07
            support_held=l >= low10*.975
            rising=sum(prev5[j][3] > prev5[j-1][3] for j in range(1,len(prev5)))
            volume_recent=mean(x[4] for x in prev5)
            quiet=width <= .125
            signal=None
            score=0
            reasons=[]
            # Aksi yönde hareket güçlü ise sinyal verilmez.
            if c<o and rvol>=1.6 and wick>=.27 and loc>=.35 and support_held and (o-c)/o<=.045:
                signal='SATIŞ EMİLİMİ ADAYI'
                score=65+min(15,round((rvol-1.6)*10))+round(wick*10)
                reasons=['Hacimli düşüş mumunda alt fitil','Son 10 günün dip bölgesi korundu']
            elif quiet and support_held and c>o and c>=previous_close and (rvol>=1.15 or v>=volume_recent*1.30) and (rising>=2 or c>=max(x[3] for x in prev5)):
                signal='YENİDEN BİRİKİM ADAYI' if post_rise else 'İLK KALKIŞ HAZIRLIĞI'
                score=58+round(min(18,(rvol-1)*13))+ (8 if c>high10 else 0) + (5 if rising>=3 else 0)
                reasons=['10 mumluk dar bant','Tabanın korunması ve hacimli toparlanma']
            elif support_held and c>o and c>high10 and rvol>=1.35 and loc>=.65:
                signal='ERKEN KIRILIM TEYİDİ'
                score=72+round(min(18,(rvol-1.35)*10))
                reasons=['Önceki 10 mum zirvesi üzerinde kapanış','Hacim katılımı']
            if signal is None:
                continue
            if out and i-out[-1]['index'] <= cooldown and signal==out[-1]['status']:
                continue
            out.append({'index':i,'date':bars[i][0], 'status':signal,
                        'score':min(95,max(0,score)), 'rvol':round(rvol,2),
                        'band_pct':round(width*100,2), 'close':round(c,4),
                        'support':round(low10,4), 'reasons':reasons,
                        'poc_note':'POC / FRVP hesaplanmadı; POC teyidi yok',
                        'basis':'Yalnızca sinyal gününe kadar kapanmış OHLCV'})
        except (IndexError, TypeError, ValueError, ZeroDivisionError):
            continue
    # Daha erken üç kademeyi aynı sonuç akışına ekle; aynı mumda gelen
    # mevcut teyidi silme. Sinyalin üretildiği günden sonraki veri okunmaz.
    stage_names = {'Erken hacimli uyanış':'ERKEN HACİMLİ UYANIŞ',
                   'Dipten toparlanma':'DİPTEN TOPARLANMA',
                   'Kalkış hazırlığı':'KALKIŞ HAZIRLIĞI'}
    seen={(s['index'], s['status']) for s in out}
    for candidate in prebreakout_candidates(bars[:last+1]):
        index=candidate['index']
        if index < max(61,last-lookback+1) or index>last: continue
        stage=stage_names[candidate['type']]
        if (index,stage) in seen: continue
        out.append({'index':index,'date':candidate['date'],'status':stage,
                    'score':min(85,max(50,round(58+max(0,candidate['relative_volume']-1)*13))),
                    'rvol':candidate['relative_volume'],'band_pct':0.0,
                    'close':candidate['close'],'support':None,
                    'reasons':[candidate['stage_note']],
                    'basis':'Yalnızca sinyal gününe kadar kapanmış OHLCV'})
    out.sort(key=lambda s:(s['index'],s['status']))
    for signal in out:
        poc=approximate_poc(bars,signal['index'])
        signal['poc']=poc['value'] if poc else None
        signal['poc_state']=poc['state'] if poc else 'HESAPLANAMADI'
        signal['poc_note']=poc['note'] if poc else 'Yaklaşık POC için yeterli/geçerli OHLCV verisi yok'
    return out


def event_lead_summary(signals, event_index, before=30):
    """İleriye bakmadan kaydedilmiş adayların sonradan belirlenmiş olaya uzaklığı."""
    candidates=[s for s in signals if event_index-before <= s['index'] < event_index]
    if not candidates: return {'first_date':None,'lead_bars':None,'signals':[]}
    return {'first_date':candidates[0]['date'], 'lead_bars':event_index-candidates[0]['index'], 'signals':candidates}
