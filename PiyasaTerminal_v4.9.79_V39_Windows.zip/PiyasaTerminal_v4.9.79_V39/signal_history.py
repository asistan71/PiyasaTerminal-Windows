"""Observed signals only; target touches are not actual investment returns."""
import sqlite3
from contextlib import closing
from datetime import date, timedelta

def recent(day):
    # Weekend allowance; not a trading calendar or a guarantee of freshness.
    age=(date.today()-date.fromisoformat(day)).days
    return 0<=age<=4

def connect(path):
    con=sqlite3.connect(path,timeout=10)
    con.execute('CREATE TABLE IF NOT EXISTS signals(symbol TEXT, day TEXT, phase TEXT, score INTEGER, price REAL, target REAL, outcome TEXT, outcome_day TEXT, PRIMARY KEY(symbol,day))')
    return con

def update(path,symbol,r):
    if not recent(r['date']): return
    with closing(connect(path)) as con, con:
        if r['alarm']:
            target=r['plan']['target']
            con.execute('INSERT OR IGNORE INTO signals VALUES (?,?,?,?,?,?,?,?)',(symbol,r['date'],r['phase']['phase'],r['score'],r['price'],target,'Bekliyor' if target and target>r['price'] else 'Hedef yok',None))
        for day,target in con.execute("SELECT day,target FROM signals WHERE symbol=? AND outcome='Bekliyor'",(symbol,)).fetchall():
            following=[b for b in r['series'] if b[0]>day][:20]
            hit=next((b[0] for b in following if b[2]>=target),None)
            if hit or len(following)>=20:
                con.execute('UPDATE signals SET outcome=?, outcome_day=? WHERE symbol=? AND day=?',('Hedef görüldü' if hit else '20 seans doldu',hit or following[-1][0],symbol,day))

def rows(path):
    with closing(connect(path)) as con, con:
        return con.execute('SELECT * FROM signals ORDER BY day DESC,symbol').fetchall()
