"""v0.16: Kontrol raporu. Sinyal üretmez, strateji kurallarını değiştirmez."""
import csv
from datetime import date
from math import isfinite


def review(symbol, result, manual=None):
    """Yalnızca mevcut veriyi ve indeks tutarlılığını kontrol eder."""
    rows=[]
    def add(check, status, detail):
        rows.append({'Hisse':symbol, 'Kontrol':check, 'Durum':status, 'Açıklama':detail})
    bars=result.get('series') or []
    usd=result.get('usd_series') or []
    if not bars:
        add('Fiyat geçmişi','HATA','Günlük fiyat verisi bulunamadı')
        return rows
    dates=[b[0] for b in bars]; n=len(bars)
    add('Fiyat geçmişi','UYGUN' if dates==sorted(set(dates)) else 'HATA',
        f'{n} günlük mum | {dates[0]} – {dates[-1]}')
    malformed=sum(not (len(b)==6 and all(isfinite(float(v)) for v in b[1:]) and b[3]<=min(b[1],b[4])<=max(b[1],b[4])<=b[2] and b[5]>=0) for b in bars)
    add('OHLC / hacim','UYGUN' if not malformed else 'HATA', f'Geçersiz günlük mum sayısı: {malformed}')
    add('USD eşleşmesi','UYGUN' if len(usd)==n and all(usd[i][0]==bars[i][0] for i in range(min(n,len(usd)))) else 'HATA',
        f'TL: {n} gün | USD: {len(usd)} gün | Önceki kur kullanılan: {result.get("carried", "—")}')
    add('Başlangıç tarihi','İNCELE' if result.get('provisional') else 'UYGUN',
        ('İlk işlem tarihi teyit edilmeli; ikinci mumdan başlatılmış' if result.get('provisional') else '2020-03-18 çıpası veya sonrasındaki veri'))
    ph=result.get('phase') or {}; peak=ph.get('peak')
    valid_peak=isinstance(peak,int) and 0<=peak<n
    add('FRVP başlangıcı','İNCELE' if valid_peak else 'HATA',
        f'{bars[peak][0] if valid_peak else "Geçersiz indeks"} | Otomatik başlangıç, manuel doğrulama gerekli')
    seg=ph.get('segments') or []
    badseg=0
    for g in seg:
        a,b,p=g.get('start'),g.get('end'),g.get('peak')
        if not all(isinstance(x,int) for x in (a,b,p)) or not (0<=a<=b<n and 0<=p<=b): badseg+=1
    add('Evre aralıkları','UYGUN' if seg and badseg==0 else 'HATA',
        f'{len(seg)} evre aralığı | Tutarsız: {badseg}')
    st=result.get('structure') or {}
    seq=[(k,st.get(k)) for k in ('dip','fake','real','retest','signal')]
    known=[(k,x) for k,x in seq if x is not None]
    valid_indices=all(isinstance(x,int) and 0<=x<n for _,x in known)
    chronological=valid_indices and all(x<y for (_,x),(_,y) in zip(known,known[1:]))
    add('Yapı kronolojisi','UYGUN' if chronological else 'HATA',
        ' | '.join(f'{title}: {bars[x][0] if isinstance(x,int) and 0<=x<n else "yok"}' for title,(_,x) in zip(("Dip","Sahte tepe","Gerçek tepe","Yeniden test","Sinyal"),seq)))
    if valid_peak:
        end_bars=bars[peak:]
        if end_bars:
            try:
                from evre import profile
                calculated=profile(end_bars)
                reported=tuple(result.get(k) for k in ('val','poc','vah'))
                consistent=all(isinstance(a,(float,int)) and abs(a-b)<1e-7*max(1,abs(b)) for a,b in zip(reported,calculated))
                add('FRVP VAL / POC / VAH','UYGUN' if consistent else 'HATA',
                    'Sabit FRVP aralığı için hesaplanan ve raporlanan seviyeler karşılaştırıldı')
            except Exception as e:
                add('FRVP VAL / POC / VAH','İNCELE',str(e)[:150])
    if manual:
        index={d:i for i,d in enumerate(dates)}
        for key,label in (('start','FRVP başı'),('fake','Sahte tepe'),('real','Gerçek tepe')):
            if key not in manual: continue
            mi=index.get(manual[key]); ai=peak if key=='start' else st.get(key)
            delta=(ai-mi) if mi is not None and isinstance(ai,int) and 0<=ai<n else None
            add('Manuel: '+label, 'UYGUN' if delta is not None and abs(delta)<=3 else 'İNCELE',
                f'Manuel {manual[key]} | Otomatik {dates[ai] if isinstance(ai,int) and 0<=ai<n else "yok"} | İşlem günü farkı: {delta if delta is not None else "hesaplanamadı"}')
    add('Gelecek veri denetimi','İNCELE',
        'Bu rapor geçmiş sinyallerin anlık veriyle yeniden üretildiğini kanıtlamaz; tarihler ilerletilerek geçmiş test yapılması gerekir')
    return rows


def export(path, rows):
    columns=('Hisse','Kontrol','Durum','Açıklama')
    with open(path,'w',encoding='utf-8-sig',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=columns,delimiter=';')
        writer.writeheader(); writer.writerows(rows)
