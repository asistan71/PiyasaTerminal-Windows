"""Optional market context. Daily completed candles only; no order-flow claims."""
from bisect import bisect_right
from datetime import date
import json
from pathlib import Path


def _completed(bars):
    today=date.today().isoformat()
    return sorted(b for b in bars if b[0]<today and b[4]>0)


def index_context(bars):
    bars=_completed(bars)
    if len(bars)<51:
        return {'trend':'Veri yok','change_pct':None,'date':bars[-1][0] if bars else None}
    close=[b[4] for b in bars]
    ma20=sum(close[-20:])/20
    ma50=sum(close[-50:])/50
    trend='Yukarı' if close[-1]>ma20>ma50 else 'Aşağı' if close[-1]<ma20<ma50 else 'Yatay'
    return {'trend':trend,'change_pct':round((close[-1]/close[-2]-1)*100,2),'date':bars[-1][0]}


def _change_20(bars, end_day):
    bars=[b for b in _completed(bars) if b[0]<=end_day]
    if len(bars)<21: return None
    # No forward look; compare matching calendar end date.
    return bars[-1][4]/bars[-21][4]-1


def relative_strength(stock,index):
    s=_completed(stock); i=_completed(index)
    if len(s)<21 or len(i)<21: return None
    common=sorted(set(b[0] for b in s)&set(b[0] for b in i))
    if len(common)<21: return None
    sm={b[0]:b for b in s}; im={b[0]:b for b in i}
    days=common[-21:]
    # 20 matched trading periods; no interpolation across missing sessions.
    stock_ret=sm[days[-1]][4]/sm[days[0]][4]-1
    index_ret=im[days[-1]][4]/im[days[0]][4]-1
    return round((stock_ret-index_ret)*100,2)


def cmf20(bars):
    """Chaikin Money Flow: price-volume proxy, NOT actual investor cash flows."""
    bars=_completed(bars)
    if len(bars)<20: return None
    num=den=0.
    for _,o,h,l,c,v in bars[-20:]:
        multiplier=((2*c-h-l)/(h-l)) if h>l else 0.
        num+=multiplier*v; den+=v
    return round(num/den,3) if den>0 else None


def load_sectors(path):
    try:
        raw=json.loads(Path(path).read_text(encoding='utf-8'))
        if not isinstance(raw,dict): return {}
        return {str(k).upper():str(v).strip() for k,v in raw.items() if isinstance(v,str) and v.strip()}
    except (OSError,ValueError): return {}


def enrich(result, index_bars, sector=None):
    out=dict(result)
    out['sector']=sector or 'Bilinmiyor'
    out['relative_20']=relative_strength(result['series'],index_bars) if index_bars else None
    out['cmf20']=cmf20(result['series'])
    out['market_trend']=index_context(index_bars)['trend'] if index_bars else 'Veri yok'
    # Not altering base score/alerts/backtest; optional contextual priority metric.
    rs=out['relative_20']; cmf=out['cmf20']; trend=out['market_trend']
    out['market_priority']=round(max(0,min(100, result['score']*.75 + (10 if rs is not None and rs>0 else 0) + (10 if cmf is not None and cmf>0 else 0) + (5 if trend=='Yukarı' else 0)))) if rs is not None and cmf is not None and trend!='Veri yok' else None
    return out


def _bist_rows():
    """Read the KAP Pay Piyasası snapshot retrieved on 2026-11-22."""
    import csv
    from pathlib import Path

    path = Path(__file__).with_name("BIST_Hisse_Listesi.csv")
    with path.open(encoding="utf-8-sig", newline="") as catalog:
        return list(csv.DictReader(catalog, delimiter=";"))


def load_bist_catalog():
    return {row["Sembol"]: row["Pazar"] for row in _bist_rows()}


_catalog_rows = _bist_rows()
BIST_CATALOG = {row["Sembol"]: row["Pazar"] for row in _catalog_rows}
BIST_NAMES = {row["Sembol"]: row["Şirket"] for row in _catalog_rows}
BIST_MARKETS = ("Yıldız", "Ana", "Alt", "Yakın İzleme", "Piyasa Öncesi")


def bist_symbols(market_name="Tümü"):
    return [symbol for symbol, market in BIST_CATALOG.items()
            if market_name == "Tümü" or market == market_name]
