# -*- coding: utf-8 -*-
"""Başlatıcı yardımcısı: paketler kurulu ve requirements.txt değişmediyse 0, kurulum gerekiyorsa 1 döndürür.

  python kurulum_kontrol.py            -> kontrol
  python kurulum_kontrol.py --kaydet   -> kurulum başarılıysa mevcut requirements özetini kaydeder
"""
import hashlib
import importlib
import sys
from pathlib import Path

MODULES = ("flet", "flet_desktop", "flet_charts", "flet_audio", "requests")
REQUIREMENTS = Path(__file__).with_name("requirements.txt")
STAMP = Path(sys.prefix) / ".gereksinim_sha256"


def digest():
    return hashlib.sha256(REQUIREMENTS.read_bytes()).hexdigest()


def installed():
    for name in MODULES:
        try:
            importlib.import_module(name)
        except Exception:
            return False
    return True


if __name__ == "__main__":
    if "--kaydet" in sys.argv:
        STAMP.write_text(digest(), encoding="utf-8")
        raise SystemExit(0)
    current = STAMP.read_text(encoding="utf-8").strip() if STAMP.exists() else ""
    raise SystemExit(0 if installed() and current == digest() else 1)
