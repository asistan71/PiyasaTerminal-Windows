"""Hacim hazırlık alarmının, takip eden fiyat hareketiyle GECIKMELI test edilmesi.

Aday tarihindeki skor SADECE o tarihe kadar kapanmış hacimleri kullanır.
İlk uygun sonraki mumun OPEN fiyatı varsayımsal giriş sayılır.
Bu modül portföy getirisi veya yatırım tavsiyesi üretmez; alarm geçerliliğini inceler.
"""
from __future__ import annotations
import csv
import math
from statistics import mean
import volume_time


def _positive(x):
    try:
        v=float(x)
        return v if math.isfinite(v) and v>0 else None
    except (ValueError, TypeError):
        return None


def signal_indices(bars, threshold=70, persistence=2, window=3, cooldown=20):
    """Kalıcı 70+ durumunun ilk görüldüğü tarih; tekrar sayımı engeller.

    Gün t için 3 günlük pencerenin en az 2 gününde eşik aşılınca alarm verilir.
    Geçmiş 60 bar zorunludur. Tamamlanmamış son bar veri kaynağında çıkarılmalıdır.
    """
    if not 0<=threshold<=100 or not (1<=persistence<=window) or cooldown<0:
        raise ValueError('Geçersiz uyarı parametresi')
    scores=[None]*len(bars)
    indices=[]
    last=-cooldown-1
    active=False
    for i in range(60,len(bars)):
        scores[i]=volume_time.measure(bars,i)['score']
        recent=scores[max(60,i-window+1):i+1]
        eligible=sum(s is not None and s>=threshold for s in recent)>=persistence
        if eligible and not active and i-last>cooldown:
            indices.append(i); last=i
        active=eligible
    return indices


def judge(bars, alert_index, horizon=20, gain_pct=10., loss_pct=7.):
    """Sonraki açılıştan sonra ilk hedef/stop teması. Aynı bar: temkinli başarısız.

    Henüz 20 bar dolmamış, hedef veya stop görmemiş örnekler 'Beklemede'.
    Eksik açılış, High/Low verileri hesaplanmış gibi gösterilmez.
    """
    if not 1<=horizon<=252 or gain_pct<=0 or loss_pct<=0:
        raise ValueError('Geçersiz değerlendirme parametresi')
    entry_idx=alert_index+1
    if entry_idx>=len(bars):
        return {'status':'Beklemede','reason':'Ertesi seans henüz yok','entry':None,'exit_date':None,
                'mfe_pct':None,'mae_pct':None,'elapsed':None}
    entry=_positive(bars[entry_idx][1])
    if entry is None:
        return {'status':'Veri hatası','reason':'Giriş açılışı eksik','entry':None,'exit_date':None,
                'mfe_pct':None,'mae_pct':None,'elapsed':None}
    up=entry*(1+gain_pct/100)
    down=entry*(1-loss_pct/100)
    last_i=min(len(bars),entry_idx+horizon)
    max_high=entry; min_low=entry
    outcome=None; enddate=None; elapsed=None; reason=''
    for j in range(entry_idx,last_i):
        hi=_positive(bars[j][2]); lo=_positive(bars[j][3]);
        if hi is None or lo is None or hi<lo:
            return {'status':'Veri hatası','reason':f'{bars[j][0]} OHLC hatası','entry':entry,
                    'exit_date':None,'mfe_pct':None,'mae_pct':None,'elapsed':None}
        max_high=max(max_high,hi); min_low=min(min_low,lo)
        hit_up=hi>=up; hit_down=lo<=down
        if hit_up or hit_down:
            # Gündelik OHLC ile intraday teması sıralanamaz; güvenli etiket kullan.
            outcome='Başarısız' if hit_down else 'Başarılı'
            reason='Aynı gün hedef ve stop: temkinli stop' if hit_up and hit_down else ('Stop önce' if hit_down else 'Hedef önce')
            enddate=bars[j][0]; elapsed=j-entry_idx+1; break
    if outcome is None:
        if last_i-entry_idx<horizon:
            outcome='Beklemede'; reason=f'{last_i-entry_idx}/{horizon} gün izlendi'
        else:
            outcome='Başarısız'; reason=f'{horizon} günde hedefe ulaşmadı'
        enddate=bars[last_i-1][0] if last_i>entry_idx else None
        elapsed=last_i-entry_idx
    return {'status':outcome,'reason':reason,'entry':round(entry,4),'exit_date':enddate,
            'mfe_pct':round((max_high/entry-1)*100,2),
            'mae_pct':round((min_low/entry-1)*100,2),'elapsed':elapsed}


def validate(bars, threshold=70, horizon=20, gain_pct=10., loss_pct=7.,
             persistence=2, window=3, cooldown=20):
    indices=signal_indices(bars,threshold,persistence,window,cooldown)
    rows=[]
    for i in indices:
        s=volume_time.measure(bars,i)
        result=judge(bars,i,horizon,gain_pct,loss_pct)
        rows.append({'date':bars[i][0],'index':i,'score':s['score'],
                     'count30':s['count'],'accel':s['accel'],
                     'entry_date':bars[i+1][0] if i+1<len(bars) else None,
                     **result})
    settled=[r for r in rows if r['status'] in ('Başarılı','Başarısız')]
    good=sum(r['status']=='Başarılı' for r in settled)
    bad=len(settled)-good
    pending=sum(r['status']=='Beklemede' for r in rows)
    errors=sum(r['status']=='Veri hatası' for r in rows)
    return {'rows':rows,'signals':len(rows),'success':good,'failed':bad,'pending':pending,
            'errors':errors,'success_rate':round(100*good/len(settled),1) if settled else None,
            'assumptions':f'Alarm: son {window} günün {persistence} tanesinde {threshold}+; '
                          f'giriş: ertesi açılış; {horizon} işlem gününde +%{gain_pct:g} hedef / '
                          f'-%{loss_pct:g} stop; aynı bar iki seviyeye değerse başarısız.'}


def export_csv(path,symbol,report):
    headers=('Hisse','Uyarı tarihi','Puan','30g yüksek hacim','Hacim ivmesi','Giriş tarihi',
             'Giriş fiyatı','Sonuç','Sonuç nedeni','Son tarih','Takip günü','En iyi hareket %','En kötü hareket %')
    with open(path,'w',newline='',encoding='utf-8-sig') as f:
        w=csv.writer(f,delimiter=';'); w.writerow(headers)
        for r in report['rows']:
            w.writerow([symbol,r['date'],r['score'],r['count30'],r['accel'],r['entry_date'],
                        r['entry'],r['status'],r['reason'],r['exit_date'],r['elapsed'],
                        r['mfe_pct'],r['mae_pct']])
