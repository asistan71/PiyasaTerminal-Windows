@echo off
rem Ayni uygulamayi tarayicida acar: http://localhost:8550 (yalnizca bu bilgisayar).
call "%~dp0BASLAT_WINDOWS.bat" --web
exit /b %errorlevel%
