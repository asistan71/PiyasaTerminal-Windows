"""Geçmiş kalkışların öncesinde, sadece hacme bakarak üretilen puanların geriye dönük denetimi.

Kalkış olayı OHLCV ile SONRADAN seçilir. Hazırlık puanları yalnızca olaydan ÖNCE
kapanmış hacim barlarını kullanır. Bu ayrım, geçmiş sonuçla tahmin girdisini
karıştırmamak içindir. Hiçbir sonuç yatırım tavsiyesi veya garantili tahmin değildir.
"""
from __future__ import annotations
from datetime import date
from statistics import mean
import csv
import volume_time
from early_liftoff import early_liftoff_signals, event_lead_summary
from prebreakout import prebreakout_candidates

# Hacim pencereleri, işlem günü cinsindendir.
VOLUME_PRESETS = ((60, 30, 10), (70, 40, 10))
VOLUME_WINDOWS = VOLUME_PRESETS[0]  # geriye dönük uyumlu varsayılan
CHECKPOINTS = (*VOLUME_WINDOWS, 1)


def normalize_windows(windows=None):
    windows = tuple(windows or VOLUME_WINDOWS)
    if windows not in VOLUME_PRESETS:
        raise ValueError('Desteklenen hacim pencereleri: 60/30/10 veya 70/40/10.')
    return windows



def _mean(items):
    return mean(items) if items else 0.0


def _num(value):
    try:
        n = float(value)
        return n if n >= 0 else 0.0
    except (TypeError, ValueError):
        return 0.0


def launch_candidates(bars, min_return=4.0, min_relative_volume=2.5, breakout_days=20, cooldown=15):
    """Olay gününün kapanışında tanımlanabilen *örnek* kalkışlar (geriye dönük)."""
    out = []
    for i in range(max(61, breakout_days), len(bars)):
        o, h, c, vol = (float(bars[i][x]) for x in (1, 2, 4, 5))
        prev_close = float(bars[i-1][4])
        prev_vol = [_num(b[5]) for b in bars[i-20:i]]
        typical = _mean(prev_vol)
        if min(o, prev_close, typical) <= 0:
            continue
        daily = 100.0*(c/prev_close - 1)
        rvol = vol/typical
        high20 = max(float(b[2]) for b in bars[i-breakout_days:i])
        if (daily >= min_return and c > o and c > high20
                and rvol >= min_relative_volume):
            if out and i-out[-1]['index'] <= cooldown:
                continue
            out.append({'index':i, 'date':bars[i][0], 'change_pct':round(daily,2),
                        'relative_volume':round(rvol,2), 'close':round(c,4), 'type':'Otomatik kalkış'})
    return out




def launch_listing_audit(bars, cooldown=15):
    """Her uygun kalkış mumunun listelenme sonucunu ve gerçek engelleyeni açıklar.

    Bekleme, son *kabul edilen* otomatik kalkışa göre hesaplanır; elenen mum
    bekleme süresini baştan başlatmaz. Olay gününden sonraki mumlar kullanılmaz.
    """
    decisions = {}
    last_accepted = None
    for i in range(61, len(bars)):
        o, c, volume = (float(bars[i][x]) for x in (1, 4, 5))
        prev_close = float(bars[i-1][4])
        avg20 = _mean([_num(b[5]) for b in bars[i-20:i]])
        if min(o, prev_close, avg20) <= 0:
            decisions[i] = {'status':'GEÇERSİZ VERİ', 'eligible':False}
            continue
        daily = 100 * (c / prev_close - 1)
        rvol = volume / avg20
        prev_high = max(float(b[2]) for b in bars[i-20:i])
        eligible = daily >= 4 and c > o and c > prev_high and rvol >= 2.5
        if not eligible:
            decisions[i] = {'status':'KOŞULLAR SAĞLANMADI', 'eligible':False}
        elif last_accepted is not None and i-last_accepted <= cooldown:
            decisions[i] = {'status':'BEKLEME FİLTRESİYLE ELENDİ', 'eligible':True,
                            'blocking_date':bars[last_accepted][0],
                            'distance':i-last_accepted, 'cooldown':cooldown}
        else:
            decisions[i] = {'status':'OTOMATİK LİSTEYE KABUL', 'eligible':True}
            last_accepted = i
    return decisions


def early_volume_candidates(bars, min_return=3.0, min_relative_volume=1.7,
                            breakout_days=10, cooldown=10):
    """Gün kapanışında bilinen fiyat/hacimle erken kırılım adayı.

    POC/FRVP bilgisi günlük OHLCV dizisinde yoktur; burada POC teyidi YOKTUR.
    Mevcut otomatik kalkış olayının yerine geçmez.
    """
    out=[]
    for i in range(max(61, breakout_days), len(bars)):
        o,h,c,v=(float(bars[i][x]) for x in (1,2,4,5))
        prev_close=float(bars[i-1][4]); typical=_mean([_num(b[5]) for b in bars[i-20:i]])
        if min(o,prev_close,typical)<=0: continue
        daily=100.0*(c/prev_close-1); rvol=v/typical
        recent_high=max(float(b[2]) for b in bars[i-breakout_days:i])
        if daily>=min_return and c>o and c>recent_high and rvol>=min_relative_volume:
            if out and i-out[-1]['index']<=cooldown: continue
            out.append({'index':i,'date':bars[i][0], 'change_pct':round(daily,2),
                        'relative_volume':round(rvol,2),'close':round(c,4),
                        'type':'Erken hacimli kırılım adayı'})
    return out



def absorption_signals(bars, asof_index=None, lookback=45, poc=None):
    """Sadece o ana kadar kapanmış OHLCV ile satış emilimi adayları.

    Kırmızı mumun yüksek hacmi tek başına teyit değildir. Mumda satışın
    ilerleyememesi, sonraki 1-3 kapanmış mumda tabanın korunması ve toparlanma
    ayrı etiketlenir. POC opsiyoneldir ve verilmediyse teyit uydurulmaz.
    """
    if not bars:
        return []
    asof = min(len(bars)-1, len(bars)-1 if asof_index is None else asof_index)
    if asof < 21:
        return []
    out = []
    start = max(20, asof-lookback+1)
    for i in range(start, asof+1):
        try:
            o,h,l,c,v = (float(bars[i][j]) for j in (1,2,3,4,5))
            prev_close = float(bars[i-1][4])
            recent = [float(x[5]) for x in bars[i-20:i]]
            ref = _mean(recent)
            if not (0 < l <= min(o,c) <= max(o,c) <= h and v > 0 and ref > 0 and prev_close > 0):
                continue
            # 'Emilim' ancak kırmızı mum + satışın etkisinin sınırlanması ile ADAY.
            spread = h-l
            if spread <= 0 or c >= o:
                continue
            rvol = v/ref
            close_position = (c-l)/spread
            lower_wick = (min(o,c)-l)/spread
            price_change = (c/prev_close-1)*100
            # Önceden bilinen 10 mumun alt bandına yakınlık, destek teması.
            support = min(float(x[3]) for x in bars[i-10:i])
            near_support = l <= support*1.035
            effort_result = rvol >= 1.7 and (close_position >= .40 or lower_wick >= .30)
            if not (effort_result and near_support):
                continue
            following = bars[i+1:min(asof+1,i+4)]
            defended = False
            reclaimed = False
            if following:
                lows = [float(x[3]) for x in following]
                closes = [float(x[4]) for x in following]
                defended = min(lows) >= l*.985
                reclaimed = max(closes) > max(o,(h+l)/2)
            confirmed = bool(defended and reclaimed)
            poc_relation = 'POC verisi aktarılmadı; POC teyidi YOK'
            if poc is not None:
                try:
                    point=float(poc)
                    if point > 0:
                        poc_relation = ('POC üzerinde kapanış' if c >= point else 'POC altında kapanış')
                except (TypeError,ValueError):
                    pass
            out.append({'index':i,'date':bars[i][0],
                        'status':'TOPARLANMA TEYİDİ' if confirmed else ('TABAN KORUNUYOR' if defended else 'SATIŞ EMİLİMİ ADAYI'),
                        'confirmed':confirmed,'rvol':round(rvol,2),
                        'close_position':round(close_position,2),
                        'lower_wick':round(lower_wick,2),
                        'daily_pct':round(price_change,2),
                        'support':round(support,4),
                        'poc_note':poc_relation,
                        'confirmation_date':next((x[0] for x in following if float(x[4])>max(o,(h+l)/2)),None) if confirmed else None,
                        'reason':'Düşüş mumunda yüksek hacim ve sınırlı satış ilerlemesi; kapanmış sonraki mumlarla değerlendirilmiştir.'})
        except (TypeError,ValueError,IndexError,ZeroDivisionError):
            continue
    return out


def recovery_diagnostic(bars, asof_index, peak_threshold=90, calm_threshold=55,
                        recover_threshold=60, lookback=45):
    """Sadece asof_index dahil geçmiş hacimden hazırlık -> sakinleşme -> toparlanma.

    Bu bir yön/kalkış onayı değildir. Zirve ve dip tarihleri birbirini izler.
    """
    if not (60 <= asof_index < len(bars)):
        return {'candidate':False,'reason':'Geçmiş hacim verisi yetersiz.'}
    scores = [(i, volume_time.measure(bars, i)) for i in range(max(60, asof_index-lookback), asof_index+1)]
    today = scores[-1][1]
    if today['score'] is None:
        return {'candidate':False,'reason':'Hacim hazırlık puanı hesaplanamadı.'}
    peak_trough = []
    for pos,(i,data) in enumerate(scores[:-2]):
        if data['score'] is None or data['score'] < peak_threshold:
            continue
        for j,low in scores[pos+1:-1]:
            if low['score'] is not None and low['score'] <= calm_threshold and j < asof_index:
                peak_trough.append((data['score']-low['score'], i, j, data['score'], low['score']))
    peak_trough.sort(reverse=True)
    best = peak_trough[0] if peak_trough else None
    peak_value = best[3] if best else None
    low_value = best[4] if best else None
    gain = today['score']-low_value if low_value is not None else None
    # Yeniden artan barların aynı zamanda yakın geçmiş hacminde bir canlanması olsun.
    volume_ok = today.get('count10',0) >= 2 or (today.get('accel') or 0) >= 1.2
    candidate = bool(best and today['score'] >= recover_threshold and gain >= 20 and volume_ok)
    reasons=[]
    if not best: reasons.append('Son 45 işlem gününde sırayla 90+ zirve ve 55 veya altı sakinleşme bulunamadı')
    if today['score'] < recover_threshold: reasons.append(f'Güncel hacim puanı {today["score"]}, gerekli {recover_threshold}')
    if best and gain < 20: reasons.append(f'Dipten toparlanma {gain} puan, gerekli 20')
    if not volume_ok: reasons.append('Son 10 günde en az 2 hacim patlaması veya 1,20x hacim ivmesi yok')
    return {'candidate':candidate,'asof_date':bars[asof_index][0],
            'score':today['score'],'peak_score':peak_value,'trough_score':low_value,
            'peak_date':bars[best[1]][0] if best else None,
            'trough_date':bars[best[2]][0] if best else None,
            'rebound':gain,'count10':today.get('count10'), 'acceleration':today.get('accel'),
            'reason':'Yeniden güçlenme adayı; fiyat yönü henüz teyit edilmedi.' if candidate else '; '.join(reasons)}


def launch_diagnostic(bars, event_index):
    """Kalkış günü için tek tek eşik kontrolü; POC bilinmiyor.

    Kullanılan oranlar, mevcut launch_candidates ve early_volume_candidates ile aynıdır.
    """
    if not (61 <= event_index < len(bars)):
        return {'confirmed':False,'early':False,'reason':'En az 61 önceki işlem günü gerekli.','checks':{}}
    i=event_index
    o,h,c,volume = (float(bars[i][x]) for x in (1,2,4,5))
    prev=float(bars[i-1][4]); avg20=_mean([_num(b[5]) for b in bars[i-20:i]])
    if min(o, prev, avg20) <= 0:
        return {'confirmed':False,'early':False,'reason':'Geçersiz fiyat veya hacim ortalaması.','checks':{}}
    daily=100*(c/prev-1); rvol=volume/avg20
    high20=max(float(b[2]) for b in bars[i-20:i]); high10=max(float(b[2]) for b in bars[i-10:i])
    checks={
        'Günlük yükseliş ≥ %4':(daily>=4, f'{daily:.2f}%'),
        'Yeşil mum':(c>o, f'açılış {o:.4f} / kapanış {c:.4f}'),
        'Önceki 20 gün zirve üstü kapanış':(c>high20, f'kapanış {c:.4f} / önceki zirve {high20:.4f}'),
        '20 günlük hacim ≥ 2,5x':(rvol>=2.5, f'{rvol:.2f}x (ortalama {avg20:,.0f})'),
        'Erken: günlük yükseliş ≥ %3':(daily>=3, f'{daily:.2f}%'),
        'Erken: önceki 10 gün zirve üstü kapanış':(c>high10, f'kapanış {c:.4f} / önceki zirve {high10:.4f}'),
        'Erken: 20 günlük hacim ≥ 1,7x':(rvol>=1.7, f'{rvol:.2f}x'),
    }
    confirmed=all(checks[k][0] for k in list(checks)[:4])
    early=checks['Yeşil mum'][0] and all(checks[k][0] for k in list(checks)[4:])
    return {'confirmed':confirmed,'early':early,'checks':checks,
            'date':bars[i][0], 'daily_pct':round(daily,2),'relative_volume':round(rvol,2),
            'reason':('Otomatik kalkışın tüm ham koşulları sağlandı.' if confirmed else
                      'Otomatik kalkış koşulları eksik.'),
            'poc_note':'POC/FRVP bu OHLCV dizisinde yok; burada POC teyidi yapılmadı.',
            'cooldown_note':'Otomatik olay listesi yakın olayları ayrıca bekleme süresi nedeniyle eleyebilir.'}


def before_window(bars, event_index, days):
    """[event-days, event) aralığı. Olay gününün hacmi ASLA dahil değil."""
    if event_index < days or days < 1:
        return None
    chunk = bars[event_index-days:event_index]
    vols = [_num(x[5]) for x in chunk]
    spikes = []
    for i in range(event_index-days,event_index):
        if i < 20: continue
        ref = _mean([_num(b[5]) for b in bars[i-20:i]])
        if ref and _num(bars[i][5]) >= 2*ref:
            spikes.append(i)
    gaps = [b-a for a,b in zip(spikes, spikes[1:])]
    return {'days':days,'avg_volume':round(_mean(vols),2),
            'max_volume':round(max(vols),2), 'spike_count':len(spikes),
            'mean_spike_gap':round(_mean(gaps),2) if gaps else None,
            'first_date':chunk[0][0], 'last_date':chunk[-1][0]}


def study_event(bars, event_index, threshold=70, lookback=70, windows=None):
    """Geçmiş kalkış öncesi puan takvimi; as-of analizi, olay barı hariç."""
    windows = normalize_windows(windows)
    checkpoints_days = (*windows, 1)
    if event_index >= len(bars) or event_index < max(windows)+60:
        raise ValueError(f'{"/".join(map(str, windows))} analizi için olaydan önce en az {max(windows)+60} işlem günü gerekli.')
    checkpoints = {}
    for distance in checkpoints_days:
        idx=event_index-distance
        if idx >= 60:
            value=volume_time.measure(bars,idx)
            checkpoints[distance]={'date':bars[idx][0], 'score':value['score'],
                                   'spikes30':value['count'], 'acceleration':value['accel']}
        else:
            checkpoints[distance]=None
    start = max(60, event_index-lookback)
    series = [(i,volume_time.measure(bars,i)['score']) for i in range(start,event_index)]
    alerts = [i for i,s in series if s is not None and s >= threshold]
    # Tek barlık hacim patlamasını kalıcı hazırlanma diye saymamak için ayrı ölçüm.
    stable=[]
    for pos in range(2,len(series)):
        last=series[pos-2:pos+1]
        if sum((sc is not None and sc>=threshold) for _,sc in last)>=2:
            stable.append(series[pos][0])
    first = alerts[0] if alerts else None
    stable_first=stable[0] if stable else None
    return {'date':bars[event_index][0], 'index':event_index,
            'windows':{d:before_window(bars,event_index,d) for d in windows},
            'window_days': windows,
            'checkpoints':checkpoints,
            'first_alert_date':bars[first][0] if first is not None else None,
            'lead_days':event_index-first if first is not None else None,
            'stable_alert_date':bars[stable_first][0] if stable_first is not None else None,
            'stable_lead_days':event_index-stable_first if stable_first is not None else None,
            'alert_days':len(alerts), 'threshold':threshold,
            'prior_date':bars[event_index-1][0],
            'prior_score':series[-1][1] if series else None,
            'recovery':recovery_diagnostic(bars,event_index-1)}


def investigate(bars, reference_date=None, max_events=15, threshold=70, windows=None):
    """reference_date varsa o günü yalnızca manuel analiz tarihi olarak kullanır."""
    windows = normalize_windows(windows)
    if reference_date:
        try: date.fromisoformat(reference_date)
        except (ValueError,TypeError): raise ValueError('Referans tarihi YYYY-AA-GG biçiminde girin.')
        idx=next((i for i,b in enumerate(bars) if b[0]==reference_date),None)
        if idx is None: raise ValueError('Seçilen tarih veri geçmişinde bulunamadı.')
        events=[{'index':idx,'date':reference_date,'type':'Manuel analiz tarihi', 'change_pct':None,'relative_volume':None}]
    else:
        confirmed=launch_candidates(bars)
        confirmed_idx={e['index'] for e in confirmed}
        early=[e for e in early_volume_candidates(bars) if e['index'] not in confirmed_idx]
        audit=launch_listing_audit(bars)
        suppressed=[{'index':i,'date':bars[i][0], 'type':'Bekleme nedeniyle elenen kalkış',
                     'change_pct':None,'relative_volume':None}
                    for i,d in audit.items() if d['status']=='BEKLEME FİLTRESİYLE ELENDİ']
        suppressed_idx={e['index'] for e in suppressed}
        early=[e for e in early if e['index'] not in suppressed_idx]
        staged=[e for e in prebreakout_candidates(bars)
                if e['index'] not in confirmed_idx and e['index'] not in suppressed_idx]
        events=sorted(confirmed+suppressed+early+staged,key=lambda e:e['index'])[-max_events:]
    audit=launch_listing_audit(bars)
    rows=[]
    for ev in events:
        try:
            row=dict(ev); row.update(study_event(bars,ev['index'],threshold,windows=windows))
            row['launch_diagnostic']=launch_diagnostic(bars,ev['index'])
            row['absorption_signals']=absorption_signals(bars,ev['index']-1,lookback=35)
            row['early_liftoff']=event_lead_summary(early_liftoff_signals(bars,ev['index']-1,lookback=45),ev['index'],before=30)
            listing=audit.get(ev['index'], {'status':'YETERSİZ VERİ','eligible':False})
            row['listing_audit']=listing
            row['launch_diagnostic']['listing_audit']=listing
            rows.append(row)
        except ValueError:
            continue
    return rows


def export_csv(path, symbol, rows, windows=None):
    windows = normalize_windows(windows or (rows[0]['window_days'] if rows else None))
    checkpoints = (*windows, 1)
    fields = ['Hisse','Olay tarihi','Olay türü','Olay günlük değişim %','Olay RVOL']
    for days in windows:
        fields += [f'{days}g ort hacim',f'{days}g patlama']
    fields += [f'D-{d} puan' for d in checkpoints]
    fields += ['İlk 70+ uyarı','Kaç işlem günü önce','Kalıcı uyarı','Kalıcı uyarı kaç gün önce',
               'Yeniden güçlenme adayı (D-1)','Yeniden güçlenme açıklama', 'Olay kalkış ham teyidi',
               'Olay erken kalkış ham teyidi','Otomatik liste durumu','Engelleyen kalkış tarihi','Kalkış koşulları (sonuç ve ölçüm)']
    with open(path,'w',encoding='utf-8-sig',newline='') as f:
        writer=csv.writer(f,delimiter=';');writer.writerow(fields)
        for r in rows:
            if tuple(r.get('window_days',windows)) != windows:
                raise ValueError('CSV için aynı hacim penceresinin raporlarını kullanın.')
            w=r['windows'];c=r['checkpoints']
            writer.writerow([symbol,r['date'],r['type'],r.get('change_pct'),r.get('relative_volume'),
                *[v for days in windows for v in ((w[days]['avg_volume'],w[days]['spike_count']) if w[days] else ('',''))],
                *[(c[days]['score'] if c[days] else '') for days in checkpoints],
                r['first_alert_date'] or '',r['lead_days'] if r['lead_days'] is not None else '',
                r['stable_alert_date'] or '',r['stable_lead_days'] if r['stable_lead_days'] is not None else '',
                'EVET' if r['recovery']['candidate'] else 'HAYIR',r['recovery']['reason'],
                'EVET' if r.get('launch_diagnostic',{}).get('confirmed',False) else 'HAYIR',
                'EVET' if r.get('launch_diagnostic',{}).get('early',False) else 'HAYIR',
                r.get('listing_audit',{}).get('status',''),r.get('listing_audit',{}).get('blocking_date',''),
                ' | '.join(f'{k}: {"EVET" if ok else "HAYIR"} ({detail})' for k,(ok,detail) in r.get('launch_diagnostic',{}).get('checks',{}).items())])


def compare_event(bars, event_index, threshold=70):
    """Aynı olay tarihiyle iki yöntemi karşılaştırır, ileriye bakmaz."""
    return {preset:study_event(bars,event_index,threshold=threshold,windows=preset)
            for preset in VOLUME_PRESETS}
