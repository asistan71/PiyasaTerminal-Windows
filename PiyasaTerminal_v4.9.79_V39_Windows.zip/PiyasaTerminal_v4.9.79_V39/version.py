"""Uygulama sürümü. Her yeni ZIP bu numarayı bir artırır."""
APP_VERSION = "4.9.79"
__version__ = APP_VERSION
__build__ = "V39_Windows"
__app_name__ = "PiyasaTerminal"


def get_version_info() -> dict:
    return {
        "app_name": __app_name__,
        "version": __version__,
        "build": __build__,
        "full_title": f"{__app_name__} v{__version__} ({__build__})",
    }
