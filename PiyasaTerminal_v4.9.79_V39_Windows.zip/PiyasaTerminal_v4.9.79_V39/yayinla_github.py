"""Yayıncı için: GitHub CLI ile Windows ZIP yayınla. Depo açıkça seçilmelidir."""
import argparse
import re
import subprocess
from pathlib import Path
import updater


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('zip', type=Path)
    parser.add_argument('--depo', required=True, help='kullanici/depo')
    parser.add_argument('--notlar', default='Piyasa Terminali Windows güncellemesi')
    args = parser.parse_args()
    if not re.fullmatch(r'[\w.-]+/[\w.-]+', args.depo):
        parser.error('Depo kullanici/depo biçiminde olmalı.')
    _, version = updater.inspect_zip(args.zip)
    if args.zip.name != f'PiyasaTerminal_v{version}_V39_Windows.zip':
        parser.error('ZIP adı Windows sürüm biçimiyle uyuşmuyor.')
    subprocess.run(['gh', 'release', 'create', f'v{version}', str(args.zip.resolve()), '--repo', args.depo,
                    '--title', f'Piyasa Terminali v{version}', '--notes', args.notlar, '--latest'], check=True)
    print('Güncelleme kanalı: github:' + args.depo)


if __name__ == '__main__':
    main()
