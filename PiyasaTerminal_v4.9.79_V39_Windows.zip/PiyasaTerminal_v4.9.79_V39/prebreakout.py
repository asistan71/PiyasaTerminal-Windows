"""Kapanmış günlük mumlardan erken hacimli yükseliş katmanları."""
from statistics import mean

def _mean(items):
    return mean(items) if items else 0.0

def _num(value):
    try:
        number=float(value)
        return number if number>=0 else 0.0
    except (TypeError,ValueError):
        return 0.0

def _close(bars, idx):
    return float(bars[idx][4])


def _low(bars, idx):
    return float(bars[idx][3])


def _high(bars, idx):
    return float(bars[idx][2])


def _open(bars, idx):
    return float(bars[idx][1])


def _volume(bars, idx):
    return _num(bars[idx][5])


def _count_up_closes(bars, start, end):
    count = 0
    for i in range(max(1, start), end + 1):
        if _close(bars, i) > _close(bars, i - 1):
            count += 1
    return count


def _higher_lows(bars, start, end):
    lows = [_low(bars, i) for i in range(start, end + 1)]
    return all(b >= a * 0.995 for a, b in zip(lows, lows[1:]))


def prebreakout_candidates(bars, cooldowns=None):
    """Kırılımdan önceki hacimli uyanış / toparlanma / hazırlık adayları.

    Yalnızca o güne kadar kapanmış OHLCV verisi kullanılır. POC/FRVP teyidi yoktur.
    Amaç erken güçlenmeyi görmek, kesin kalkış demek değildir.
    """
    cooldowns = cooldowns or {
        'Erken hacimli uyanış': 5,
        'Dipten toparlanma': 6,
        'Kalkış hazırlığı': 7,
    }
    out = []
    last = {}
    for i in range(61, len(bars)):
        c = _close(bars, i)
        o = _open(bars, i)
        prev = _close(bars, i - 1)
        avg20 = _mean([_volume(bars, j) for j in range(i - 20, i)])
        avg10 = _mean([_volume(bars, j) for j in range(i - 10, i)])
        avg3 = _mean([_volume(bars, j) for j in range(max(0, i - 2), i + 1)])
        if min(c, prev, avg10, avg20) <= 0:
            continue
        low20 = min(_low(bars, j) for j in range(i - 20, i + 1))
        high10 = max(_high(bars, j) for j in range(i - 10, i))
        low5 = min(_low(bars, j) for j in range(i - 4, i + 1))
        close5_ago = _close(bars, i - 5)
        daily = 100.0 * (c / prev - 1)
        gain5 = 100.0 * (c / close5_ago - 1) if close5_ago > 0 else 0.0
        rvol20 = _volume(bars, i) / avg20
        cluster = avg3 / avg10 if avg10 else 0.0
        up3 = _count_up_closes(bars, i - 2, i)
        up5 = _count_up_closes(bars, i - 4, i)
        higher_lows = _higher_lows(bars, i - 3, i)
        near_bottom = c <= low20 * 1.18
        protecting_bottom = low5 >= low20 * 0.98
        best_close_5 = c >= max(_close(bars, j) for j in range(i - 4, i))
        near_high10 = c >= high10 * 0.97
        # 1) Dipte hacim canlanıyor ama klasik kırılım yok.
        if (near_bottom and protecting_bottom and (c > o or daily > 0.8)
                and up3 >= 2 and cluster >= 1.35 and rvol20 >= 1.10):
            kind = 'Erken hacimli uyanış'
            if i - last.get(kind, -9999) > cooldowns[kind]:
                out.append({'index': i, 'date': bars[i][0], 'change_pct': round(daily, 2),
                            'relative_volume': round(rvol20, 2), 'close': round(c, 4),
                            'type': kind,
                            'stage_note': f'Dip bölgesinde hacim kümelenmesi {cluster:.2f}x | 20g RVOL {rvol20:.2f}x'})
                last[kind] = i
        # 2) Dipten toparlanma: daha yüksek dipler ve güçlenen kapanışlar.
        if (near_bottom and protecting_bottom and higher_lows and up5 >= 3
                and gain5 >= 3.5 and cluster >= 1.10):
            kind = 'Dipten toparlanma'
            if i - last.get(kind, -9999) > cooldowns[kind]:
                out.append({'index': i, 'date': bars[i][0], 'change_pct': round(daily, 2),
                            'relative_volume': round(rvol20, 2), 'close': round(c, 4),
                            'type': kind,
                            'stage_note': f'5g toparlanma {gain5:.2f}% | yükselen dipler | hacim kümesi {cluster:.2f}x'})
                last[kind] = i
        # 3) Kalkış hazırlığı: yakın zirveye yaklaşım ve hacimli güç toplama.
        if (protecting_bottom and best_close_5 and near_high10 and up5 >= 3
                and gain5 >= 4.5 and cluster >= 1.05 and rvol20 >= 1.15):
            kind = 'Kalkış hazırlığı'
            if i - last.get(kind, -9999) > cooldowns[kind]:
                out.append({'index': i, 'date': bars[i][0], 'change_pct': round(daily, 2),
                            'relative_volume': round(rvol20, 2), 'close': round(c, 4),
                            'type': kind,
                            'stage_note': f'Yakın zirveye yaklaşım | 5g toparlanma {gain5:.2f}% | 3g hacim {cluster:.2f}x'})
                last[kind] = i
    return out


