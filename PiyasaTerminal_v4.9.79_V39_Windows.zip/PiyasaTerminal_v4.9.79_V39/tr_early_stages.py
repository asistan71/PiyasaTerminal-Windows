"""Binance TR 5m kapanmış OHLCV mumlarından deneysel erken evre etiketi.

Var olan TEYITLI/ERKEN/IZLE işlem sinyali veya puanı değiştirmez.
Yalnızca son kapanmış mum değerlendirilir. Binance TR spotta SHORT üretilmez.
"""
from __future__ import annotations
from math import isfinite
from statistics import mean

STAGES = ('Erken Hacimli Uyanış', 'Dipten Toparlanma', 'Kalkış Hazırlığı')


def classify_tr_early_stage(data, period="5m kapanmış mum"):
    """None veya açıklamalı {stage, note, rvol, cluster} döndürür.

    Veriler binance_get_market_data tarafından son açık mum çıkarılarak sağlanır.
    """
    try:
        o = [float(x) for x in data['open']]
        h = [float(x) for x in data['high']]
        l = [float(x) for x in data['low']]
        c = [float(x) for x in data['close']]
        v = [float(x) for x in data['volume']]
        if min(map(len, (o, h, l, c, v))) < 61:
            return None
        o, h, l, c, v = (a[-61:] for a in (o, h, l, c, v))
        if any(not all(isfinite(x) for x in arr) for arr in (o, h, l, c, v)):
            return None
        if any(lo <= 0 or vv < 0 or not lo <= min(op, cl) <= max(op, cl) <= hi
               for op,hi,lo,cl,vv in zip(o,h,l,c,v)):
            return None
        avg20 = mean(v[-21:-1]); avg10 = mean(v[-11:-1]); avg3 = mean(v[-3:])
        if avg20 <= 0 or avg10 <= 0:
            return None
        rv = v[-1] / avg20
        cluster = avg3 / avg10
        low20 = min(l[-21:])
        high10 = max(h[-11:-1])
        protect = min(l[-5:]) >= low20 * 0.98
        up3 = sum(c[i] > c[i-1] for i in (-3,-2,-1))
        up5 = sum(c[i] > c[i-1] for i in (-5,-4,-3,-2,-1))
        rising_lows = all(b >= a*0.995 for a,b in zip(l[-4:-1],l[-3:]))
        near_bottom = c[-1] <= low20*1.18
        gain5 = 100*(c[-1]/c[-6]-1)
        best5 = c[-1] >= max(c[-5:-1])
        near_high = c[-1] >= high10*.97
        stage = None
        if (protect and best5 and near_high and up5 >= 3 and gain5 >= 4.5
                and cluster >= 1.05 and rv >= 1.15):
            stage = STAGES[2]
        elif (near_bottom and protect and rising_lows and up5 >= 3
              and gain5 >= 3.5 and cluster >= 1.10):
            stage = STAGES[1]
        elif (near_bottom and protect and (c[-1] > o[-1] or c[-1] > c[-2]*1.008)
              and up3 >= 2 and cluster >= 1.35 and rv >= 1.10):
            stage = STAGES[0]
        if stage is None:
            return None
        return {'stage':stage, 'note':f'{period} • son 3 hacim/önceki 10: {cluster:.2f}x • RVOL20: {rv:.2f}x • 5 mum: {gain5:+.2f}%',
                'rvol':round(rv,2), 'cluster':round(cluster,2)}
    except (ValueError, KeyError, TypeError, ZeroDivisionError):
        return None
