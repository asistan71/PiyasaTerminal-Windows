"""Nedensel yapı adayları. Tepe eşikleri gerçek örneklerle kalibre edilmelidir."""
from statistics import mean

def detect(bars, peak, profile, window=3):
    n=len(bars); fake=real=dip=retest=signal=trigger=None
    # Yalnızca sağ tarafı tamamlanmış pivotlar; ilk küçük salınımı seçme.
    highs=[]; lows=[]
    for i in range(peak+window,n-window):
        if bars[i][2]>max(b[2] for b in bars[i-window:i]) and bars[i][2]>=max(b[2] for b in bars[i+1:i+window+1]): highs.append(i)
        if bars[i][3]<min(b[3] for b in bars[i-window:i]) and bars[i][3]<=min(b[3] for b in bars[i+1:i+window+1]): lows.append(i)
    candidates=[]
    for d in lows:
        if bars[d][3]>bars[peak][2]*.85: continue
        # Dipten önceki anlamlı tepe, dip sonrası tepenin karşılaştırma noktasıdır.
        prior=max((bars[j][2] for j in highs if j<d and j>peak),default=0)
        for f in highs:
            if f<=d or f+window>=n: continue
            level=bars[f][2]
            if level<bars[d][3]*1.12 or (prior and level<=prior): continue
            # Zirve sonrası yataylaşma: en az 5 mum, dip kırılmamış olmalı.
            end=min(n,f+6)
            if end-f<6: continue
            base=bars[f+1:end]
            if max(b[4] for b in base)>level or min(b[3] for b in base)<max(bars[d][3],level*.75): continue
            candidates.append((d,f)); break
    if candidates:
        # İlk geçerli yapı, ikinci tepe profil başlangıcını değiştirmez.
        dip,fake=candidates[0]
        level=bars[fake][2]
        breakout=next((i for i in range(fake+6,n) if bars[i][4]>level),None)
        if breakout is not None:
            # Gerçek tepe = kırılım sonrası teyit edilmiş zirve; kırılım mumu değil.
            real=next((i for i in highs if i>=breakout and bars[i][2]>level),None)
            if real is not None:
                retest=next((i for i in lows if i>real and bars[i][3]<bars[real][2]*.95),None)
    if retest is not None:
        for i in range(max(retest+window,30),n):
            c=bars[i][4]; v=bars[i][5]; hist=[b[5] for b in bars[i-30:i]]; avg=mean(hist)
            if not (c>bars[i][1] and avg>0 and v>max(hist) and v/avg>=2.5): continue
            val,poc,vah=profile(bars[peak:i]); low=min(b[3] for b in bars[real:i])
            levels=[(k,x) for k,x in [('VAL',val),('POC',poc),('VAH',vah)] if low<x<=c]
            if levels: signal=i; trigger=levels[-1][0]; break
    state='Kalkış adayı' if signal is not None else 'Hacim bekleniyor' if retest is not None else 'Geri çekilme bekleniyor' if real is not None else 'Gerçek tepe bekleniyor' if fake is not None else 'Yapı aranıyor'
    return dict(fake=fake,real=real,dip=dip,retest=retest,signal=signal,trigger=trigger,state=state)
