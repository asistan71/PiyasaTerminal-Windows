import unittest
from datetime import date,timedelta
from pro_analysis import radar,backtest

def sample(n=100):
    return [(str(date(2025,1,1)+timedelta(days=i)),100,101,99,100,1000) for i in range(n)]

class ProTests(unittest.TestCase):
    def test_radar(self):
        b=sample(); b[-1]=(b[-1][0],100,108,99,107,5000)
        r=radar(b); self.assertEqual(r['Puan kapsamı'],90); self.assertEqual(r['Durum'],'Teyitli kırılım'); self.assertLessEqual(r['Puan'],100)
        self.assertEqual(radar(b,sample())['Puan kapsamı'],100)
    def test_invalid(self):
        with self.assertRaises(ValueError): radar(sample(70))
    def test_causal_and_conservative(self):
        b=sample(); b[70]=(b[70][0],100,108,99,107,5000); b[71]=(b[71][0],100,120,80,100,1000)
        trades,_=backtest(b); self.assertEqual(trades[0]['Sonuç'],'Stop'); self.assertLess(trades[0]['Net %'],-7)
        self.assertEqual(trades[0]['Giriş tarihi'],b[71][0])
