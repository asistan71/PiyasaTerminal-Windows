import hashlib
import json
import os
import sys
import tempfile
import threading
import unittest
import zipfile
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import updater


def build_zip(path, version, prefix="PiyasaTerminal_v%s_V39/", extra=None, skip=(), requirements="flet==1.1.3\n"):
    prefix = prefix % version if "%s" in prefix else prefix
    files = {name: f"# {name} {version}\n" for name in updater.REQUIRED_FILES}
    files["version.py"] = f'APP_VERSION = "{version}"\n'
    files["requirements.txt"] = requirements
    files.update(extra or {})
    with zipfile.ZipFile(path, "w") as archive:
        for name, text in files.items():
            if name not in skip:
                archive.writestr(prefix + name, text)
    return path


class UpdaterTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.app = self.root / "app"
        self.app.mkdir()
        with zipfile.ZipFile(build_zip(self.root / "old.zip", "1.0.0")) as archive:
            archive.extractall(self.root / "old")
        for source in (self.root / "old" / "PiyasaTerminal_v1.0.0_V39").iterdir():
            (self.app / source.name).write_text(source.read_text())
        (self.app / ".venv").mkdir()
        (self.app / ".venv" / "keep.txt").write_text("sanal ortam")

    def tearDown(self):
        self.tmp.cleanup()

    def test_versions(self):
        self.assertTrue(updater.is_newer("4.9.29", "4.9.28"))
        self.assertTrue(updater.is_newer("4.10.0", "4.9.28"))
        self.assertFalse(updater.is_newer("4.9.28", "4.9.28"))
        self.assertEqual(updater.version_from_filename("PiyasaTerminal_v4_9_27_V39_Windows.zip"), "4.9.27")
        self.assertEqual(updater.version_from_filename("PiyasaTerminal_v4.9.28_V39.zip"), "4.9.28")

    def test_apply_keeps_venv_adds_files_and_rolls_back(self):
        new = build_zip(self.root / "new.zip", "1.1.0", extra={"yeni_modul.py": "x = 1\n", ".venv/ignored.py": "no",
                                                               "__pycache__/a.pyc": "no", "veri.sqlite3": "no"},
                        requirements="flet==2.0\n")
        result = updater.apply_zip(new, app_dir=self.app, backup_dir=self.root / "yedekler")
        self.assertEqual((result["old"], result["new"]), ("1.0.0", "1.1.0"))
        self.assertTrue(result["requirements_changed"])
        self.assertEqual(updater.installed_version(self.app), "1.1.0")
        self.assertTrue((self.app / "yeni_modul.py").exists())
        self.assertEqual((self.app / ".venv" / "keep.txt").read_text(), "sanal ortam")
        self.assertFalse((self.app / ".venv" / "ignored.py").exists())
        self.assertFalse((self.app / "veri.sqlite3").exists())
        self.assertFalse(list(self.app.rglob("*.yeni")))
        back = updater.rollback_latest(self.app, self.root / "yedekler")
        self.assertEqual(back["new"], "1.0.0")
        self.assertEqual(updater.installed_version(self.app), "1.0.0")
        self.assertFalse((self.app / "yeni_modul.py").exists())
        with self.assertRaises(updater.UpdateError):
            updater.rollback_latest(self.app, self.root / "yedekler")

    def test_rejects_incomplete_unsafe_and_foreign_zips(self):
        stub = build_zip(self.root / "stub.zip", "9.9.9", skip=("chart_workshop.py", "evre_core.py"))
        with self.assertRaisesRegex(updater.UpdateError, "eksik"):
            updater.apply_zip(stub, app_dir=self.app, backup_dir=self.root / "y")
        self.assertEqual(updater.installed_version(self.app), "1.0.0")
        slip = self.root / "slip.zip"
        with zipfile.ZipFile(slip, "w") as archive:
            archive.writestr("PiyasaTerminal/piyasa_mobile.py", "x")
            archive.writestr("PiyasaTerminal/../../evil.py", "x")
        with self.assertRaises(updater.UpdateError):
            updater.inspect_zip(slip)
        other = self.root / "other.zip"
        with zipfile.ZipFile(other, "w") as archive:
            archive.writestr("readme.txt", "x")
        with self.assertRaises(updater.UpdateError):
            updater.inspect_zip(other)

    def test_find_local_updates(self):
        folder = self.root / "indirilenler"
        folder.mkdir()
        build_zip(folder / "PiyasaTerminal_v1.2.0_V39.zip", "1.2.0")
        build_zip(folder / "PiyasaTerminal_v1.0.0_V39.zip", "1.0.0")
        build_zip(folder / "PiyasaTerminal_v3.0.0_V39_temiz.zip", "3.0.0", skip=("evre_core.py",))
        found = updater.find_local_updates([folder, self.root / "yok"], "1.0.0")
        self.assertEqual([item["version"] for item in found], ["1.2.0"])

    def test_manifest_download_and_checksum_over_http(self):
        site = self.root / "site"
        site.mkdir()
        zip_path = build_zip(site / "PiyasaTerminal_v1.3.0_V39.zip", "1.3.0")
        digest = hashlib.sha256(zip_path.read_bytes()).hexdigest()
        (site / "manifest.json").write_text(json.dumps({"version": "1.3.0", "url": zip_path.name, "sha256": digest,
                                                        "notes": "deneme"}))
        server = ThreadingHTTPServer(("127.0.0.1", 0), partial(SimpleHTTPRequestHandler, directory=str(site)))
        threading.Thread(target=server.serve_forever, daemon=True).start()
        try:
            base = f"http://127.0.0.1:{server.server_address[1]}"
            info = updater.check(base + "/manifest.json", "1.0.0")
            self.assertTrue(info["available"])
            self.assertEqual(info["url"], f"{base}/{zip_path.name}")
            steps = []
            saved = updater.download(info["url"], self.root / "indir" / "paket.zip", steps.append, info["sha256"])
            self.assertEqual(steps[-1], 1.0)
            self.assertEqual(updater.inspect_zip(saved)[1], "1.3.0")
            with self.assertRaisesRegex(updater.UpdateError, "sha256"):
                updater.download(info["url"], self.root / "indir" / "kotu.zip", None, "0" * 64)
            self.assertFalse((self.root / "indir" / "kotu.zip").exists())
            self.assertFalse(updater.check(base + "/manifest.json", "1.3.0")["available"])
        finally:
            server.shutdown()

    def test_rejects_non_http_sources(self):
        with self.assertRaises(updater.UpdateError):
            updater.fetch_manifest("file:///etc/passwd")
        with self.assertRaises(updater.UpdateError):
            updater.fetch_manifest("github:bozuk")


if __name__ == "__main__":
    unittest.main()
