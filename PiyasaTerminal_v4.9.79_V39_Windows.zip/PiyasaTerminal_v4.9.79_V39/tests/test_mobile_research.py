import csv
import io
import tempfile
import threading
import unittest
from pathlib import Path
from unittest.mock import patch

import data_provider
import evre_backtest
import evre_core
import mobile_research as research
import terminal_core
from test_core import fake_yahoo, fake_klines


class MobileResearchTests(unittest.TestCase):
    def test_bist_reports_and_engine_parity(self):
        with tempfile.TemporaryDirectory() as folder, patch.object(data_provider, "_get", fake_yahoo):
            db = str(Path(folder) / "cache.db")
            bars, _ = evre_core.fetch_backtest_history("THYAO", db)
            evre_core.fetch("USDTRY", db)
            rows, used, source = research.run("EVRE geçmiş testi", "THYAO", db, True)
            self.assertEqual(rows, evre_backtest.evaluate(bars)[2])
            self.assertEqual(used, bars)
            self.assertIn("önbelleği", source)
            for mode, reference, options in (
                ("Fırsat alarmı", "", {"minimum": 0}),
                ("Evre geçmişi", "", {}),
                ("Hacim alarmı başarı testi", "", {}),
                ("Kalkış araştırması", bars[-1][0], {}),
                ("Veri ve yapı denetimi", "", {}),
                ("Manuel FRVP", f"{bars[-25][0]} / {bars[-1][0]}", {}),
                ("Manuel referans karşılaştırma", f"fake={bars[-1][0]}", {}),
                ("Algoritma karşılaştırma", f"fake={bars[-1][0]}", {}),
                ("Para akışı", "", {}),
            ):
                with self.subTest(mode=mode):
                    rows, used, _ = research.run(mode, "THYAO", db, True, reference, options)
                    self.assertTrue(used)
                    research.csv_bytes(rows)
            rows, _, _ = research.run("Çoklu EVRE testi", "THYAO, ASELS", db, True)
            self.assertEqual([row["state"] for row in rows], ["OK", "HATA"])
            rows, _, _ = research.scan_alerts(
                ["THYAO", "ASELS"], db, True, 0, threading.Event(), lambda _: None)
            self.assertEqual([row["symbol"] for row in rows], ["THYAO"])

    def test_binance_and_csv(self):
        raw = fake_klines(n=120)
        with patch.object(terminal_core, "binance_get", return_value=raw):
            rows, bars, status = research.run("Binance TR geçmiş testi", "BTC_TRY", "")
        self.assertEqual(len(bars), len(raw) - 1)
        self.assertIn("UTC", status)
        self.assertTrue(all(row["date"] == bars[row["index"]][0] for row in rows))
        payload = research.csv_bytes([{"Hisse": "THYAO", "Sonuç": "Kalkış; teyit"}, {"Hisse": "ASELS", "Puan": 75}])
        self.assertTrue(payload.startswith(b"\xef\xbb\xbf"))
        actual = list(csv.DictReader(io.StringIO(payload.decode("utf-8-sig")), delimiter=";"))
        self.assertEqual(actual[0]["Sonuç"], "Kalkış; teyit")
        self.assertEqual(actual[1]["Puan"], "75")
