import asyncio
import threading
from tempfile import TemporaryDirectory
from unittest import TestCase
from unittest.mock import AsyncMock, Mock, patch

import piyasa_mobile as main
from test_core import fake_yahoo, fake_klines


class FletIntegration(TestCase):
    def setUp(self):
        folder = self.enterContext(TemporaryDirectory())
        self.enterContext(patch.dict(main.os.environ, {"FLET_APP_STORAGE_DATA": folder}))
        self.app = main.PiyasaMobile(Mock(web=False))

    def drain(self):
        while not self.app.messages.empty():
            self.app.receive(*self.app.messages.get_nowait())

    def run_inline(self, fn):
        def run(key, worker):
            worker(threading.Event(), lambda kind, data=None: self.app.messages.put((key, kind, data)))
            self.app.messages.put((key, "done", False))

        with patch.object(self.app, "run_job", side_effect=run):
            fn(None)
        self.drain()

    def test_views_and_evre_engine(self):
        app = self.app
        for view in (*app.tabs, "Analiz", "Ayarlar"):
            app.show(view)
        app.show("EVRE")
        app.stock_code.value = "THYAO"
        with patch.object(main.data_provider, "_get", fake_yahoo):
            self.run_inline(app.start_stock)
        row = app.results["evre"]["THYAO"]
        self.assertEqual(row["Puan"], row["detail"]["score"])
        self.assertTrue(row["detail"]["usd_series"])
        app.open_chart(row)
        app.receive("grafik", "chart", (app.chart_request, row["detail"]["series"]))
        app.render()
        self.assertTrue(app.graph_bars)

    def test_binance_tr_scan_and_backtest_chart(self):
        app = self.app
        app.crypto_mode = "Binance TR"
        with patch.object(main.tc, "tr_symbols", return_value=["BTC_TRY"]), \
             patch.object(main.tc, "binance_get", return_value=fake_klines(n=120)):
            self.run_inline(app.start_crypto)
            self.assertEqual(app.results["tr"]["BTC_TRY"]["source"], "tr")
            app.research_mode.value = "Binance TR geçmiş testi"
            app.research_code.value = "BTC_TRY"
            app.params.value = "24 3 3"
            self.run_inline(app.start_research)
        day = app.report_bars[-1][0]
        app.report_chart({"date": day})
        self.assertEqual(app.graph_focus, day)
        self.assertEqual(app.graph_tf, "5m")

    def test_failed_live_tour_clears_stale_rows(self):
        app = self.app
        app.receive("tr", "row", {"Sembol": "BTC_TRY", "Puan": 83, "Sinyal": "TEYITLI LONG"})
        app.receive("tr", "finished", {"errors": 1})
        app.receive("tr", "fresh", set())
        app.receive("tr", "cycle", {"next": 120, "received": 0, "errors": 1})
        self.assertFalse(app.results["tr"])
        self.assertIn("Veri alınamadı", app.state["tr"].value)

    def test_csv_passes_real_bytes_to_picker(self):
        app = self.app
        app.picker = Mock(save_file=AsyncMock(return_value="report.csv"))
        app.page.run_task.side_effect = lambda callback: asyncio.run(callback())
        app.export([{"Sembol": "THYAO", "Tür": "Kalkış"}])
        payload = app.picker.save_file.call_args.kwargs["src_bytes"]
        self.assertIn("THYAO;Kalkış", payload.decode("utf-8-sig"))

    def test_preserves_v49_tabs_and_extended_chart(self):
        app = self.app
        self.assertEqual(
            tuple(d.label for d in app.nav.destinations),
            ("Sinyaller", "BIST", "Binance", "Favoriler", "EVRE", "EVRE Alarm",
             "Dip Alarm", "Dip Hafıza", "İşlemler", "Grafik"),
        )
        self.assertEqual(len(main.market.bist_symbols()), 631)
        app.report_symbol = "THYAO"
        app.report_bars = [("2025-01-01", 10, 12, 9, 11, 100)]
        app.report_chart({"date": "2025-01-01", "VAL": 10, "POC": 11, "VAH": 12})
        app.chart_indicator_menu([]).controls[0].controls[0].controls[1].on_click(None)
        self.assertEqual(app.ema_periods, {20})
        app.toggle_indicator("VWAP")
        app.toggle_draw(None)
        event = Mock(type=main.charts.ChartEventType.TAP_UP, spot_index=0)
        app.chart_mark(event, app.report_bars, ("bist", "THYAO", "1D"))
        self.assertEqual(app.user_marks[("bist", "THYAO", "1D")], {"2025-01-01"})
        self.assertIsNotNone(app.profile_view(app.report_bars))

    def test_ema_menu_and_drawing_tools(self):
        app = self.app
        bars = [("2025-01-01", 10, 12, 9, 10, 100), ("2025-01-02", 10, 20, 9, 20, 110)]
        with patch.object(app, "redraw"):
            for item in app.chart_indicator_menu([]).controls[0].controls[0].controls:
                item.on_click(None)
            self.assertEqual(app.ema_periods, {10, 20, 50, 100, 200})
            for period, (_, values, _) in zip(sorted(app.ema_periods), app.ema_lines(bars)):
                self.assertAlmostEqual(values[-1], 10 + 20 / (period + 1))
            app.chart_indicator_menu([]).controls[0].controls[0].controls[0].on_click(None)
            self.assertNotIn(10, app.ema_periods)
            row = {"Sembol": "THYAO", "source": "bist"}
            with patch.object(app, "load_chart"):
                app.open_chart(row)
            chart = app.workshop(row, bars, 0, bars, [], main.ft.Row())
            rail = chart[-1].controls[0]
            for group in rail.controls:
                for item in group.items:
                    item.on_click(None)
                    self.assertEqual(app.workshop_tool, item.content)

    def test_period_buttons_switch_market_chart(self):
        app = self.app
        for source, symbol in (("bist", "THYAO"), ("tr", "BTC_TRY"), ("futures", "BTCUSDT")):
            with patch.object(app, "load_chart") as load:
                app.open_chart({"Sembol": symbol, "source": source})
                for caption in ("5m", "15m", "1h", "4h", "1d", "1w"):
                    bar = app.graph_view()[-1]
                    buttons = bar.controls[0].controls[:6]
                    target = next(b for b in buttons if b.content.value == caption)
                    load.reset_mock()
                    target.on_click(None)
                    load.assert_called_once()
                    self.assertEqual(app.graph_tf.lower(), caption)
                    refreshed = app.graph_view()[-1].controls[0].controls[:6]
                    self.assertEqual([b.content.value for b in refreshed if b.style.bgcolor == main.SELECTED_ROW], [caption])

    def test_drag_redraws_view_without_translating_canvas(self):
        from chart_workshop import Workshop
        bars = [(str(i), 100, 110, 95, 101, 1000) for i in range(600)]
        at = lambda x, y: Mock(local_position=main.ft.Offset(x, y))
        for finish in ("end_drag", "cancel_drag"):
            chart = Workshop(bars, [], [], [], [], "İmleç", start=200, span=100)
            with patch.object(type(chart.canvas), "update"), patch.object(chart, "redraw", wraps=chart.redraw) as render:
                chart.begin_drag(at(100, 100))
                for i in range(1, 31):
                    chart.drag(at(100+i, 100+i))
                self.assertGreater(render.call_count, 0)
                self.assertIsNone(chart.canvas.offset)
                chart.drag(at(420, 140))
                self.assertGreater(render.call_count, 0)
                chart.drag(at(390, 120))
                getattr(chart, finish)(None)
                self.assertIsNone(chart.canvas.offset)
                self.assertEqual(chart.start, 200-round(290/chart.step))
                self.assertEqual(chart.low, chart.price_range[0])

    def test_pan_zoom_batch_render_and_swing_cache(self):
        import chart_workshop as cw
        bars = [(str(i), 100, 110, 95, 101, 1000) for i in range(6000)]
        with patch.object(cw, "swing_highs", wraps=cw.swing_highs) as swings:
            chart = cw.Workshop(bars, [], [], [([101] * len(bars), "#FF9900")],
                                [], "İmleç", start=2400, span=200, accumulation_line=True)
            with patch.object(type(chart.canvas), "update"):
                chart.begin_drag(Mock(local_position=main.ft.Offset(200, 100)))
                chart.drag(Mock(local_position=main.ft.Offset(230, 100)))
                chart.end_drag(None)
                self.assertLess(chart.start, 2400)
                chart.scroll(Mock(local_position=main.ft.Offset(230, 100), scroll_delta=main.ft.Offset(0, -10)))
                self.assertLess(chart.span, 200)
                self.assertLess(len(chart.canvas.shapes), 60)
                self.assertTrue(any(isinstance(shape, cw.cv.Points) for shape in chart.canvas.shapes))
            swings.assert_called_once()

    def test_four_scan_pages_stop_and_restart_with_pending_request(self):
        app = self.app
        app.stock_code.value = app.research_code.value = "THYAO"

        def button_named(control, caption):
            if isinstance(control, main.ft.FilledButton) and control.content == caption:
                return control
            for child in getattr(control, "controls", []):
                found = button_named(child, caption)
                if found is not None:
                    return found
            content = getattr(control, "content", None)
            if isinstance(content, main.ft.Control):
                return button_named(content, caption)

        for section, key, caption in (("Dip Alarm", "dip", "Tara"), ("Dip Hafıza", "memory", "Tara"),
                                      ("EVRE", "evre", "Çalıştır"), ("EVRE Alarm", "analiz", "Çalıştır")):
            with self.subTest(section=section):
                app.show(section)
                released = threading.Event()
                entered = threading.Event()
                original = app.run_job

                def blocked(stop, emit):
                    entered.set()
                    released.wait(4)
                    emit("status", "Eski sonuç")

                with patch.object(app, "run_job", side_effect=lambda k, w: original(k, blocked)):
                    try:
                        button_named(app.body, caption).on_click(None)
                        self.assertTrue(entered.wait(2))
                        first = app.jobs[key]
                        old_button = button_named(app.body, "Durdur")
                        old_button.on_click(None)
                        self.assertTrue(first.is_set())
                        self.assertNotIn(key, app.jobs)
                        self.assertEqual(app.state[key].value, "Durduruldu")
                        button_named(app.body, caption).on_click(None)
                        second = app.jobs[key]
                        old_button.on_click(None)
                        app.receive(key, "status", "Eski sonuç", first)
                        app.receive(key, "done", True, first)
                        self.assertIs(app.jobs[key], second)
                        self.assertFalse(second.is_set())
                        self.assertNotEqual(app.state[key].value, "Eski sonuç")
                        button_named(app.body, "Durdur").on_click(None)
                    finally:
                        released.set()

    def test_long_history_hover_updates_only_crosshair(self):
        from chart_workshop import Workshop
        bars = [(str(i), 100, 105, 98, 102, 1000) for i in range(6000)]
        chart = Workshop(bars, [], [], [], [], "İmleç", marks={"1000": "Dip olayı"})
        base_shapes = chart.canvas.shapes
        self.assertLess(len(base_shapes), 1200)
        with patch.object(type(chart.canvas), "update", autospec=True) as update:
            chart.hover(Mock(local_position=main.ft.Offset(chart._x(1000), 30)))
            self.assertEqual(chart.cursor[0], "1000")
            self.assertIs(chart.canvas.shapes, base_shapes)
            self.assertLess(len(chart.overlay.shapes), 15)
            self.assertTrue(any("Dip olayı" in getattr(s, "value", "") for s in chart.overlay.shapes))
            update.assert_called_once_with(chart.overlay)

    def test_memory_chart_fits_all_events_and_focuses_selected_date(self):
        from datetime import date, timedelta
        app = self.app
        bars = [((date(2020, 1, 1) + timedelta(days=i)).isoformat(), 10, 12, 9, 11, 100)
                for i in range(900)]
        events = [dict(date=bars[i][0], score=80, spike=3) for i in (10, 400, 850)]
        row = dict(Sembol="THYAO", source="memory", detail=events, GrafikTarihi=events[-1]["date"])
        with patch.object(app, "load_chart"):
            app.open_chart(row)
        app.receive("grafik", "chart", (app.chart_request, bars))
        with patch.object(app, "workshop", wraps=app.workshop) as workshop:
            app.graph_view()
        _, _, _, window, marks, *_ = workshop.call_args.args
        self.assertEqual(set(marks), {e["date"] for e in events})
        self.assertTrue(set(marks).issubset(b[0] for b in window))
        menu = app.memory_event_menu(marks, bars)
        menu.items[2].on_click(None)
        self.assertEqual(app.graph_focus, events[1]["date"])
        menu.items[0].on_click(None)
        self.assertIsNone(app.graph_focus)
        self.assertGreater(app.chart_span, 800)

    def test_chart_fills_measured_body_and_resizes_canvas(self):
        from chart_workshop import Workshop
        app = self.app
        with patch.object(app, "load_chart"):
            app.open_chart({"Sembol": "THYAO", "source": "bist"})
        self.assertTrue(app.page.title.startswith("Grafik · "))
        app.graph_bars = [("2025-01-02", 10, 12, 9, 11, 250)]
        for focus in (False, True):
            for workshop in (True, False):
                app.chart_focus, app.workshop_enabled = focus, workshop
                app.render()
                with patch.object(type(app.chart_viewport), "update"):
                    for height in (650, 1000):
                        app.body_resized(Mock(height=height))
                        self.assertEqual(app.chart_viewport.height, height - 4)
                self.assertTrue(app.chart_viewport.controls[-1].expand)
                self.assertTrue(app.chart_viewport.controls[-1].content.expand)
        chart = Workshop(app.graph_bars, [], [], [], [], "İmleç")
        with patch.object(type(chart.canvas), "update"):
            chart.resize(Mock(width=1000, height=700))
            plot = chart.plot_height
            chart.resize(Mock(width=1000, height=920))
            self.assertEqual(chart.plot_height - plot, 220)
        app.show("BIST")
        self.assertIsNone(app.chart_viewport)
        self.assertFalse(app.page.title.startswith("Grafik · "))

    def test_chart_market_and_plan_layout(self):
        app = self.app
        with patch.object(app, "load_chart"):
            app.open_chart({"Sembol": "THYAO", "source": "bist", "Giris": 10, "Stop": 9})
        app.graph_bars = [("2025-01-02", 10, 12, 9, 11, 250)]
        for focus in (False, True):
            for workshop in (False, True):
                app.chart_focus, app.workshop_enabled = focus, workshop
                chart = next(c.content.controls for c in app.graph_view() if isinstance(c, main.ft.Container)
                             and isinstance(c.content, main.ft.Column))
                menu = next(c for c in chart if isinstance(c, main.ft.Stack)).controls[-1].content
                self.assertEqual(menu.controls[0].content.value, "Göstergeler ▾")
                buttons = chart[0].controls[0].controls[:6]
                self.assertEqual([b.content.value for b in buttons], ["5m", "15m", "1h", "4h", "1d", "1w"])
                self.assertEqual(chart[0].controls[-1].value, "BIST · TL · ₺")
                footer = next(c for c in chart if isinstance(c, main.ft.Row)
                              and any(getattr(item, "label", None) == "İşlem planı" for item in c.controls))
                self.assertIn("Hacim 250", footer.controls[0].value)
                self.assertEqual(footer.controls[2].value, "Giriş 10 ₺")

    def test_chart_trade_plan_checkbox(self):
        app = self.app
        with patch.object(app, "load_chart"):
            app.open_chart({"Sembol": "THYAO", "source": "bist", "Giris": 10, "Stop": 9})
        app.graph_bars = [("2025-01-02", 10, 12, 9, 11, 250)]
        for enabled in (True, False, True):
            with patch.object(main, "Workshop", wraps=main.Workshop) as workshop:
                panel = app.graph_view()[-1]
            footer = panel.content.controls[-1]
            toggle = footer.controls[1]
            self.assertEqual(toggle.value, enabled)
            self.assertEqual(bool(workshop.call_args.args[1]), enabled)
            self.assertEqual(bool(footer.controls[2:]), enabled)
            self.assertIn("Hacim", footer.controls[0].value)
            toggle.value = not enabled
            toggle.on_change(Mock(control=toggle))

    def test_workshop_and_previous_period_levels(self):
        from chart_workshop import Workshop, pivots
        import flet as ft

        bars = [("2025-01-30", 10, 12, 9, 11, 100),
                ("2025-01-31", 11, 13, 10, 12, 200),
                ("2025-02-03", 80, 95, 76, 90, 300)]
        levels = pivots(bars, "1 Ay")
        self.assertEqual(len(levels), 4)
        self.assertEqual(levels[0][:2], (2, 3))
        self.assertAlmostEqual(levels[0][2], (13 + 9 + 12) / 3)
        drawings = []
        workshop = Workshop(bars, [], levels, [], drawings, "Trend çizgisi")
        with patch.object(type(workshop.canvas), "update"):
            workshop.tap(Mock(local_position=ft.Offset(5, 30)))
            workshop.tap(Mock(local_position=ft.Offset(225, 50)))
        self.assertEqual(len(drawings), 1)
        self.assertNotEqual(drawings[0][0][0], drawings[0][1][0])

    def test_camarilla_spans_entire_period_and_clips_to_view(self):
        from datetime import datetime, timedelta
        from flet.canvas import Line
        from chart_workshop import CAMARILLA, Workshop, pivots
        for period, months in CAMARILLA.items():
            with self.subTest(period=period):
                start = datetime(2040, 1, 2) if not months else datetime(2040, 1, 1)
                if not months:
                    start -= timedelta(days=start.weekday())
                    end = start + timedelta(weeks=1)
                else:
                    end = start.replace(year=start.year + months // 12, month=1 + months % 12)
                dates = [start - timedelta(days=1)]
                dates.extend(start + (end - start) * i / 65 for i in range(65))
                dates.append(end)
                bars = [(d.isoformat(), 10, 12, 8, 10, 100) for d in dates]
                levels = pivots(bars, period)
                self.assertEqual([v[:2] for v in levels], [(1, 66)] * 4 + [(66, 67)] * 4)
                chart = Workshop(bars, [], levels, [], [], "İmleç", start=1, span=20)
                with patch.object(type(chart.canvas), "update"):
                    chart.set_view(40, 12)
                self.assertTrue(any(isinstance(s, Line) and s.paint.color == "#FFFFFF"
                                    and s.x1 == 0 and abs(s.x2 - chart.plot_width) < 1e-6
                                    for s in chart.canvas.shapes))

    def test_one_shot_and_right_click_deletes_only_target(self):
        from chart_workshop import Workshop
        bars = [(f"2025-01-{i:02}", 10, 12, 9, 11, 50) for i in range(1, 11)]
        drawings = []
        save = Mock()
        chart = Workshop(bars, [], [], [], drawings, "Trend çizgisi", on_change=save)
        at = lambda x, y: Mock(local_position=main.ft.Offset(x, y))
        with patch.object(type(chart.canvas), "update"), patch.object(type(chart.control), "open", new_callable=AsyncMock) as opened:
            chart.tap(at(60, 30))
            self.assertEqual(chart.tool, "Trend çizgisi")
            chart.tap(at(240, 30))
            chart.tap(at(200, 90))
            self.assertEqual((chart.tool, len(drawings)), ("İmleç", 1))
            chart.tool = "Yatay çizgi"
            chart.tap(at(240, 120))
            other = drawings[-1]
            asyncio.run(chart.open_drawing_menu(at(160, 200)))
            opened.assert_not_awaited()
            asyncio.run(chart.open_drawing_menu(at(160, 30)))
            opened.assert_awaited_once()
            self.assertEqual(chart.control.items[0].content, "Sil")
            chart.control.on_select(Mock(item_index=0))
            self.assertEqual(drawings, [other])
            self.assertEqual(save.call_count, 3)

    def test_right_click_copy_profile_places_once_and_can_cancel(self):
        from chart_workshop import Workshop
        bars = [(str(i), 10, 12, 9, 11, 100) for i in range(12)]
        profile = {"tool": "frvp", "start": "2", "end": "6", "fixed_poc": True,
                   "style": {"width": 3}}
        drawings = [profile]
        saved = Mock()
        chart = Workshop(bars, [], [], [], drawings, "İmleç", on_change=saved)
        def at(index):
            return Mock(local_position=main.ft.Offset(chart._x(index), chart._y(10)))
        with patch.object(type(chart.canvas), "update"), patch.object(type(chart.control), "update"), patch.object(type(chart.control), "open", new_callable=AsyncMock):
            for cancel in (True, False):
                asyncio.run(chart.open_drawing_menu(at(3)))
                index = next(i for i, entry in enumerate(chart.control.items) if entry.content == "Kopyala")
                chart.edit_selected(Mock(item_index=index))
                if cancel:
                    asyncio.run(chart.open_drawing_menu(at(5)))
                    saved.assert_not_called()
                else:
                    chart.tap(at(5))
                    chart.tap(at(7))
        saved.assert_called_once()
        self.assertEqual(len(drawings), 2)
        self.assertEqual((profile["start"], profile["end"]), ("2", "6"))
        self.assertEqual(drawings[1], dict(profile, start="4", end="8"))
        self.assertIsNot(drawings[1]["style"], profile["style"])

    def test_edit_saved_line_style_by_right_click(self):
        import json
        from chart_workshop import Workshop
        bars = [("2025-01-01", 10, 12, 9, 11, 100)]
        drawings = [[[bars[0][0], 10], None], [[bars[0][0], 11], None]]
        save = Mock()
        chart = Workshop(bars, [], [], [], drawings, "İmleç", on_change=save)
        with patch.object(type(chart.canvas), "update"), patch.object(type(chart.control), "open", new_callable=AsyncMock):
            for setting in (("color", "#60A5FA"), ("width", 4)):
                asyncio.run(chart.open_drawing_menu(Mock(local_position=main.ft.Offset(20, chart._y(10)))))
                index = next(i for i, entry in enumerate(chart.control.items) if entry.data == setting)
                chart.control.on_select(Mock(item_index=index))
        self.assertEqual(save.call_count, 2)
        restored = Workshop(bars, [], [], [], json.loads(json.dumps(drawings)), "İmleç")
        stroke = restored.drawing_shapes[0][1][0].paint
        self.assertEqual((stroke.color, stroke.stroke_width), ("#60A5FA", 4))
        self.assertIsInstance(drawings[1], list)

    def test_pen_notes_and_clipped_trend(self):
        from chart_workshop import Workshop
        from flet.canvas import Line, Text
        bars = [(f"2025-01-{i:02}", 10, 12, 9, 11, 50) for i in range(1, 11)]
        drawings = [((bars[0][0], 10), (bars[-1][0], 11))]
        save = Mock()
        chart = Workshop(bars, [("Hedef", 1000, "#FFFFFF")], [], [], drawings, "Kalem",
                         start=3, span=4, fit_levels=False, on_change=save)
        self.assertLess(chart.high, 13)
        self.assertTrue(any(isinstance(shape, Line) and shape.paint.color == "#D4A3FF"
                            for shape in chart.canvas.shapes))
        with patch.object(type(chart.canvas), "update"):
            chart.pen(Mock(local_position=main.ft.Offset(5, 20)))
            chart.pen(Mock(local_position=main.ft.Offset(5, 70)))
            chart.finish_pen(None)
        save.assert_called_once()
        self.assertEqual(len(drawings[-1]["points"]), 2)
        app = self.app
        app.workshop_drawings["test"] = drawings
        point = drawings[-1]["points"][0]
        app.chart_note("test", point)
        dialog = app.page.show_dialog.call_args.args[0]
        dialog.content.value = "Destek bölgesi"
        dialog.actions[-1].on_click(None)
        loaded = main.tc.load_json(app.workshop_file, {})["test"]
        chart = Workshop(bars, [], [], [], loaded, "Metin")
        self.assertTrue(any(isinstance(shape, Text) and shape.value == "Destek bölgesi"
                            for shape in chart.canvas.shapes))
        app.undo_drawing("test")
        self.assertEqual(len(main.tc.load_json(app.workshop_file, {})["test"]), 2)

    def test_v39_research_modes(self):
        app = self.app
        with patch.object(main.data_provider, "_get", fake_yahoo):
            bars, _ = main.ev.fetch_backtest_history("THYAO", app.db)
            for mode in ("Satış emilimi", "Erken hacimli kırılım", "Kalkış liste denetimi",
                         "60/30/10 ve 70/40/10 karşılaştırma"):
                with self.subTest(mode=mode):
                    rows, chart, _ = main.research.run(mode, "THYAO", app.db, True, bars[-1][0])
                    self.assertEqual(chart, bars)
                    if "karşılaştırma" in mode:
                        self.assertEqual(len(rows), 8)

    def test_analysis_scope_and_chart_routing(self):
        app = self.app
        app.show("Analiz")
        app.research_mode.value = "Satış emilimi"
        app.research_code.value = ""
        self.run_inline(app.start_research)
        self.assertIn("BIST kodu", app.notice.value)
        app.research_code.value = "THYAO"
        def report(mode, symbol, *args):
            price = 10 if symbol == "THYAO" else 20
            return [{"date": "2025-01-02"}], [("2025-01-02", price, price+1, price-1, price, 100)], "Test"
        with patch.object(main.research, "run", side_effect=report) as runner, \
             patch.object(main.ev, "universe", return_value=["THYAO", "ASELS"]):
            self.run_inline(app.start_research)
            self.assertEqual(runner.call_count, 1)
            app.set_research_scope("Tüm hisseler")
            self.run_inline(app.start_research)
        self.assertEqual([row["symbol"] for row in app.report], ["THYAO", "ASELS"])
        app.report_chart(app.report[1])
        self.assertEqual(app.chart_row["Sembol"], "ASELS")
        self.assertEqual(app.graph_bars[0][4], 20)

    def test_fixed_volume_range_survives_zoom_and_reload(self):
        from chart_workshop import Workshop
        from flet.canvas import Text
        import json
        bars = [(str(i), 10, 12, 9, 11, i * 100) for i in range(8)]
        saved = Mock()
        chart = Workshop(bars, [], [], [], [], "Sabit hacim (FRVP)", on_change=saved)
        with patch.object(type(chart.canvas), "update"):
            for i in (6, 2):
                chart.tap(Mock(local_position=main.ft.Offset((i + .5) * chart.step, 50)))
            chart.set_view(3, 2)
        saved.assert_called_once()
        self.assertEqual(chart.profile_cache[(2, 6)][0], main.ev.profile_bins(bars[2:7]))
        restored = Workshop(bars, [], [], [], json.loads(json.dumps(chart.drawings)), "İmleç")
        self.assertTrue(any(isinstance(shape, Text) and shape.value == "Gelişen POC"
                            for shape in restored.canvas.shapes))

    def test_edit_profile_endpoints_and_toggle_fixed_poc(self):
        from chart_workshop import Workshop
        import json
        bars = [(str(i), 10, 12, 9, 11, 100) for i in range(12)]
        target = {"tool": "frvp", "start": "8", "end": "2"}
        saved = Mock()
        chart = Workshop(bars, [], [], [], [target], "İmleç", on_change=saved)
        at = lambda x, y: Mock(local_position=main.ft.Offset(x, y))
        with patch.object(type(chart.canvas), "update"), patch.object(type(chart.control), "update"), patch.object(type(chart.control), "open", new_callable=AsyncMock):
            chart.tap(at(chart._x(3), chart._y(10)))
            self.assertIs(chart.selected_profile, target)
            for field, day in (("end", 1), ("start", 9)):
                _, x, y, _ = next(h for h in chart.profile_handles() if h[0] == field)
                chart.begin_drag(at(x, y))
                chart.drag(at(chart._x(day), y))
                chart.end_drag(None)
                self.assertEqual(target[field], str(day))
            self.assertIn((1, 9), chart.profile_cache)
            for enabled in (True, False):
                asyncio.run(chart.open_drawing_menu(at(chart._x(3), chart._y(10))))
                chart.edit_selected(Mock(item_index=len(chart.control.items)-1))
                restored = Workshop(bars, [], [], [], json.loads(json.dumps([target])), "İmleç")
                self.assertEqual(any(getattr(p, "value", "").startswith("Sabit POC ") for p in restored.canvas.shapes), enabled)
            self.assertEqual(saved.call_count, 4)

    def test_developing_ta_has_two_white_stepped_boundaries(self):
        from chart_workshop import Workshop
        bars = [(str(i), p, p+1, p-1, p, v) for i, (p, v) in enumerate([(10, 5), (20, 50), (12, 80)])]
        drawing = {"tool": "frvp", "start": "0", "end": "2", "style": {"color": "#FF7070"}}
        chart = Workshop(bars, [], [], [], [drawing], "İmleç")
        from chart_workshop import PROFILE_INSIDE, PROFILE_OUTSIDE
        self.assertFalse(any(s.data == "ta" for s in chart.canvas.shapes))
        colors = {s.paint.color for s in chart.canvas.shapes if s.data == "frvp_volume"}
        self.assertTrue(colors)
        self.assertEqual(colors, {main.ft.Colors.with_opacity(.75, c) for c in (PROFILE_INSIDE, PROFILE_OUTSIDE)})
        self.assertFalse(any(getattr(getattr(s, "paint", None), "color", None) == "#2A2E39" for s in chart.canvas.shapes))
        self.assertTrue(any(getattr(s, "value", None) == "0" for s in chart.canvas.shapes))
        for role in ("ta_lower", "ta_upper"):
            parts = [s for s in chart.canvas.shapes if s.data == role]
            self.assertTrue(any(s.x1 < s.x2 for s in parts))
            self.assertTrue(any(s.x1 == s.x2 and s.y1 != s.y2 for s in parts))
            self.assertTrue(all(s.paint.color == "#FFFFFF" for s in parts))

    def test_developing_profile_changes_with_accumulated_volume(self):
        trace = []
        bars = [(str(i), p, p, p, p, v) for i, (p, v) in enumerate([(10, 0), (10, 3), (20, 10), (10, 9)])]
        profile = main.ev.profile_bins(bars, n=2, developing=trace)
        self.assertEqual(trace, [None, (10, 12.5, 15), (15, 17.5, 20), (10, 12.5, 20)])
        self.assertEqual(trace[-1], profile[:3])

    def test_evre_table_sort_scope_and_graph(self):
        app = self.app
        app.show("EVRE")
        for sym, score in (("THYAO", 84), ("ASELS", 76)):
            app.receive("evre", "row", {"Sembol": sym, "Puan": score, "Evre": "TL"})
        app.toggle_evre_scope(None)
        self.assertEqual(app.evre_scope, "Tüm hisseler")
        table = app.stocks()[-1].controls[0]
        self.assertEqual(table.rows[0].cells[1].content.value, "THYAO")
        table.columns[4].on_sort(Mock(ascending=True))
        row = app.stocks()[-1].controls[0].rows[0]
        self.assertEqual(row.cells[1].content.value, "ASELS")
        with patch.object(app, "open_chart") as opened:
            row.cells[0].content.controls[1].on_click(None)
        self.assertEqual(opened.call_args.args[0]["Sembol"], "ASELS")

    def test_direct_daily_chart_and_symbol_search(self):
        app = self.app
        with patch.object(app, "load_chart") as load:
            app.show("Grafik")
            self.assertEqual((app.chart_row["Sembol"], app.graph_tf), ("THYAO", "1D"))
            app.show("Grafik")
            load.assert_called_once()
            actions = app.chart_header.controls
            self.assertFalse(app.chart_header.visible)
            self.assertFalse(app.header.visible)
            self.assertEqual(actions, [])
            graph = app.graph_view()
            chart_bar = next(c for c in graph if isinstance(c, main.ft.Row) and any(isinstance(x, main.ft.TextField) for x in c.controls))
            field = next(c for c in chart_bar.controls if isinstance(c, main.ft.TextField))
            self.assertEqual(field.label, "BIST hisse kodu")
            self.assertFalse(any(getattr(control, "label", None) == "İmleç ayarı" for control in actions))
            field.value = "asels"
            field.on_submit(None)
            self.assertEqual((app.chart_row["Sembol"], app.graph_tf), ("ASELS", "1D"))
            self.assertEqual(load.call_count, 2)

    def test_bist_toolbar_and_period_row(self):
        app = self.app
        app.show("BIST")
        for single in (False, True):
            app.single_market["bist"] = single
            actions, filters = app.stocks()[0].content.controls[:2]
            self.assertEqual(actions.controls[-1].content, "CSV kaydet")
            self.assertIs(filters.controls[0], app.stock_code if single else app.stock_group)
            self.assertEqual([c.label for c in filters.controls[1:]], ["1W", "1D", "1H"])
            self.assertFalse(filters.wrap)

    def test_market_switch_and_live_buttons(self):
        app = self.app
        app.show("Binance")
        app.offset = 2
        app.switch_crypto_market(None)
        self.assertEqual((app.crypto_mode, app.offset), ("Binance TR", 0))
        tr = app.live_scan_button("tr")
        tr.on_click(None)
        self.assertEqual(app.live_scan_button("tr").content, "Canlı tarama · Açık")
        app.switch_crypto_market(None)
        self.assertEqual(app.crypto_mode, "Binance Vadeli")
        self.assertFalse(app.live_scan["futures"])
        for key in ("bist", "evre", "futures", "tr"):
            self.assertEqual(app.live_scan_button(key).bgcolor, main.RED)
        app.jobs["tr"] = threading.Event()
        self.assertTrue(app.live_scan_button("tr").disabled)

    def test_market_pages_use_analysis_table(self):
        app = self.app
        for key, symbol in (("bist", "THYAO"), ("tr", "BTC_TRY"), ("futures", "ETHUSDT")):
            app.receive(key, "row", {"Sembol": symbol, "Fiyat": 12, "Puan": 82, "Sinyal": "ERKEN LONG"})
            if key != "bist":
                app.crypto_mode = "Binance TR" if key == "tr" else "Binance Vadeli"
            app.show("BIST" if key == "bist" else "Binance")
            table = app.body.controls[-1].controls[0]
            self.assertIsInstance(table, main.ft.DataTable)
            with patch.object(app, "open_chart") as opened:
                table.rows[0].cells[0].content.controls[1].on_click(None)
                self.assertEqual(opened.call_args.args[0]["source"], key)
        app.show("Sinyaller")
        self.assertEqual(len(app.body.controls[-1].controls[0].rows), 3)
        actions = app.body.controls[0].content.controls[-1].controls
        self.assertEqual([btn.content for btn in actions], ["Analiz", "Ayarlar"])

    def test_bist_filter_and_horizontal_timeframes(self):
        app = self.app
        app.show("BIST")
        row = next(c for c in app.body.controls[0].content.controls if getattr(c, "controls", [])[1:] == app.tfs)
        self.assertFalse(row.wrap)
        self.assertEqual([c.label for c in row.controls[1:]], ["1W", "1D", "1H"])
        app.bist_filter_button().on_click(None)
        self.assertFalse(app.bist_filters_enabled)
        self.assertEqual(app.bist_filter_button().content, "Filtreleri uygula")
        self.assertEqual(app.live_scan_button("bist").content, "Periyodik tarama · Kapalı")

    def test_report_table_pages_and_details(self):
        app = self.app
        app.report = [{"symbol": f"H{i}", "score": 0} for i in range(main.PAGE_SIZE)]
        app.report.append({"symbol": "SON", "detail": "Uzun açıklama " * 20})
        app.show("Analiz")
        table = app.body.controls[-2].controls[0]
        self.assertEqual(len(table.rows), main.PAGE_SIZE)
        self.assertEqual([c.label.value for c in table.columns], ["İşlemler", "Sembol", "Puan", "Açıklama"])
        self.assertEqual(table.rows[0].cells[2].content.content.value, "0")
        app.move(1)
        row = app.body.controls[-2].controls[0].rows[0]
        self.assertEqual(row.cells[1].content.content.value, "SON")
        self.assertEqual(row.cells[2].content.content.value, "—")
        row.cells[0].content.controls[0].on_click(None)
        dialog = app.page.show_dialog.call_args.args[0]
        self.assertIn(app.report[-1]["detail"], dialog.content.controls[-1].content.controls[-1].value)

    def test_desktop_and_compact_navigation(self):
        app = self.app
        app.resize_layout(Mock(width=1200))
        self.assertTrue(app.sidebar.visible)
        self.assertFalse(app.compact_navigation.visible)
        groups = app.sidebar_content.controls
        self.assertEqual([g.title.value for g in groups], ["PİYASALAR", "ANALİZ", "PORTFÖY", "SİSTEM"])
        self.assertTrue(all(isinstance(g, main.ft.ExpansionTile) and not g.expanded for g in groups))
        groups[1].expanded = True
        entries = [entry for group in groups for entry in group.controls]
        self.assertEqual(len(entries), 13)
        for entry in entries:
            title = entry.content.controls[1].value
            entry.on_click(None)
            self.assertEqual(app.section, title)
            self.assertEqual(app.section_title.value, title)
        self.assertIs(groups[1], app.sidebar_content.controls[1])
        self.assertTrue(groups[1].expanded)
        app.resize_layout(Mock(width=600))
        self.assertFalse(app.sidebar.visible)
        self.assertTrue(app.compact_navigation.visible)
        app.nav.selected_index = app.tabs.index("BIST")
        app.navigate(Mock(control=app.nav))
        self.assertEqual(app.section, "BIST")

    def test_drag_past_last_bar_and_compress_loaded_history(self):
        from chart_workshop import Workshop
        bars = [(str(i), 10, 12, 8, 11, 60) for i in range(1500)]
        at = lambda x: Mock(local_position=main.ft.Offset(x, 100), scroll_delta=main.ft.Offset(0, 1))
        chart = Workshop(bars, [], [], [], [], "İmleç", start=1400, span=100)
        with patch.object(type(chart.canvas), "update"):
            chart.begin_drag(at(400))
            chart.drag(at(400 - 30 * chart.step))
            chart.end_drag(None)
            self.assertEqual(len(chart.bars), 70)
            self.assertEqual(chart.point(at(chart._x(69)))[0], bars[-1][0])
            self.assertIsNone(chart.point(at(chart._x(70))))
            chart.begin_drag(at(200))
            chart.drag(at(200 + 30 * chart.step))
            chart.end_drag(None)
            for _ in range(20):
                chart.scroll(at(300))
            self.assertEqual((chart.start, chart.span), (0, 1500))

    def test_wheel_anchor_and_horizontal_drag(self):
        from datetime import date, timedelta
        from types import SimpleNamespace
        import flet as ft
        from chart_workshop import Workshop

        bars = [((date(2025, 1, 1) + timedelta(days=i)).isoformat(), 10, 12, 8, 11, i)
                for i in range(200)]
        callback = Mock()
        chart = Workshop(bars, [], [], [], [], "İmleç", start=90, span=80, on_view=callback)
        x = chart.plot_width / 4
        point = SimpleNamespace(local_position=ft.Offset(x, 40), scroll_delta=ft.Offset(0, -1))
        with patch.object(type(chart.canvas), "update"):
            before = chart.point(point)[0]
            chart.scroll(point)
            self.assertEqual(chart.span, 64)
            self.assertEqual(chart.point(point)[0], before)
            chart.begin_drag(point)
            chart.drag(SimpleNamespace(local_position=ft.Offset(x + chart.step * 10, 40)))
            self.assertEqual(chart.start, 84)
            chart.end_drag(None)
            chart.set_view(-1000, 64)
            self.assertEqual(chart.start, -52)
            chart.set_view(1000, 64)
            self.assertEqual(chart.start, 188)
            callback.assert_called_with(188, 64)

    def test_fibonacci_pan_and_price_scale(self):
        from types import SimpleNamespace
        import json
        import flet as ft
        from chart_workshop import Workshop

        bars = [(f"2025-01-{i:02}", 10 + i, 12 + i, 9 + i, 11 + i, 5) for i in range(1, 29)]
        drawings, ranges = [], []
        chart = Workshop(bars, [], [], [], drawings, "Fibonacci", on_range=ranges.append)

        def at(x, y, delta=-1):
            return SimpleNamespace(local_position=ft.Offset(x, y), scroll_delta=ft.Offset(0, delta))

        with patch.object(type(chart.canvas), "update"):
            chart.tap(at(50, 40))
            chart.tap(at(300, 200))
            self.assertEqual(drawings[0]["tool"], "fib")
            restored = Workshop(bars, [], [], [], json.loads(json.dumps(drawings)), "İmleç")
            self.assertTrue(any(getattr(shape, "value", "").startswith("0.618") for shape in restored.canvas.shapes))
            span = chart.high - chart.low
            chart.scroll(at(chart.plot_width + 5, 50))
            self.assertLess(chart.price_range[1] - chart.price_range[0], span)
            chart.tap(at(chart.plot_width + 5, 50))
            self.assertIsNone(chart.price_range)
            chart.begin_drag(at(100, 100))
            chart.drag(at(100, 160))
            self.assertIsNotNone(chart.price_range)
            chart.end_drag(None)
            self.assertEqual(ranges[-1], chart.price_range)

    def test_accumulation_vline_and_arrows(self):
        from types import SimpleNamespace
        import flet as ft
        from chart_workshop import Workshop, accumulation

        def leg(count, a, b):
            return [a + (b - a) * i / (count - 1) for i in range(count)]

        path = leg(11, 60, 100)[:-1] + leg(21, 100, 52)[:-1] + leg(11, 52, 80)[:-1] + leg(11, 80, 70)[:-1] + leg(21, 70, 101)
        bars = [(f"d{i:03}", p, p + 1, p - 1, p, 10) for i, p in enumerate(path)]
        info = accumulation(bars, 0, len(bars))
        self.assertEqual((info["dip"], info["peak"]), (30, 10))
        self.assertEqual(info["level"], 101)
        self.assertEqual(bars[info["end"]][2] >= info["level"], True)
        self.assertTrue(all(bar[2] < info["level"] for bar in bars[info["peak"] + 1:info["end"]]))
        drawings = []
        chart = Workshop(bars, [], [], [], drawings, "Dikey çizgi", accumulation_line=True, visible_volume=True)
        self.assertTrue(any(getattr(shape, "value", "").startswith("Akümülasyon") for shape in chart.canvas.shapes))
        at = lambda x, y: SimpleNamespace(local_position=ft.Offset(x, y))
        with patch.object(type(chart.canvas), "update"):
            chart.tap(at(100, 100))
            chart.tool = "Yukarı ok"
            chart.tap(at(200, 150))
            chart.tool = "Aşağı ok"
            chart.tap(at(250, 150))
        self.assertEqual([d["tool"] for d in drawings], ["vline", "arrow", "arrow"])
        self.assertEqual([d.get("dir") for d in drawings[1:]], ["up", "down"])

    def test_sort_value_orders_numbers_before_text(self):
        values = ["12.5", "%3,2", "-4", "THYAO", "abc", "100"]
        self.assertEqual(sorted(values, key=main.sort_value), ["-4", "%3,2", "12.5", "100", "abc", "THYAO"])
        self.assertEqual([main.sort_value(v)[0] for v in ("-4", "12.5", "abc")], [0, 0, 1])
        self.assertLess(main.sort_value("9"), main.sort_value("10"))

    def test_update_tab_flow(self):
        import queue as queue_module
        app = self.app
        app.show("Güncelleme")
        info = {"available": True, "version": "9.9.9", "url": "http://example.invalid/p.zip", "sha256": "",
                "notes": "Yeni özellikler", "current": main.APP_VERSION, "quiet": False}
        app.receive("guncelleme", "found", info)
        app.show("Güncelleme")
        self.assertIn("v9.9.9", app.update_note)
        result = {"old": main.APP_VERSION, "new": "9.9.9", "files": 3, "added": 0,
                  "requirements_changed": False, "backup": "yedek.zip"}
        with patch.object(main.updater, "inspect_zip", return_value=("", "9.9.9")), \
                patch.object(main.updater, "apply_zip", return_value=result):
            app.update_busy = False
            app.apply_local("PiyasaTerminal_v9.9.9_V39.zip")
            seen = []
            while not any(kind == "applied" for _, kind, _ in seen):
                seen.append(app.messages.get(timeout=3))
        for message in seen:
            app.receive(*message)
        self.assertIn("→ v9.9.9", app.update_note)
        app.page.run_task.assert_called()
        with patch.object(main.updater, "inspect_zip", return_value=("", main.APP_VERSION)):
            app.update_busy = False
            app.apply_local("eski.zip")
            kind = ""
            while kind != "error":
                _, kind, message = app.messages.get(timeout=3)
        app.receive("guncelleme", "error", message)
        self.assertIn("Yeni sürüm değil", app.update_note)

