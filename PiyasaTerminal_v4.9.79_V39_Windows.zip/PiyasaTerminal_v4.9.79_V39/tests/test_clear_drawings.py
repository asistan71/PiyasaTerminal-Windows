"""Exercise the actual dialog callback without requiring Flet."""
import ast
from pathlib import Path
from types import SimpleNamespace as NS
from unittest import TestCase
from unittest.mock import Mock

class ClearDrawingsTest(TestCase):
    def test_confirm_cancel_and_scope(self):
        tree=ast.parse((Path(__file__).resolve().parents[1]/'piyasa_mobile.py').read_text())
        fn=next(n for n in ast.walk(tree) if isinstance(n,ast.FunctionDef) and n.name=='clear_drawings')
        save=Mock()
        env={'ft':NS(AlertDialog=NS,Text=lambda value:value,TextButton=NS), 'button':lambda name,cb,color:NS(on_click=cb), 'RED':'red', 'save_state':save}
        exec(compile(ast.Module(body=[fn],type_ignores=[]),'clear','exec'),env)
        app=NS(workshop_drawings={'BIST|A|1D':[1,2],'BIST|B|1D':[3]},workshop_file='test',page=Mock(),redraw=Mock(),notice=NS(),workshop_tool='Daire')
        env['clear_drawings'](app,'BIST|A|1D')
        dialog=app.page.show_dialog.call_args.args[0]
        dialog.actions[0].on_click(None)
        save.assert_not_called()
        self.assertEqual(app.workshop_drawings['BIST|A|1D'],[1,2])
        env['clear_drawings'](app,'BIST|A|1D')
        dialog=app.page.show_dialog.call_args.args[0]
        dialog.actions[1].on_click(None)
        self.assertEqual(app.workshop_drawings,{'BIST|A|1D':[],'BIST|B|1D':[3]})
        save.assert_called_once_with('test',app.workshop_drawings)
        self.assertEqual(app.workshop_tool,'İmleç')
