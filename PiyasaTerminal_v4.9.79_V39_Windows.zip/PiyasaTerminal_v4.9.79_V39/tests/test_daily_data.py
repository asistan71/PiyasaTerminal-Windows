import os
import sys
import unittest
from datetime import datetime, timedelta
from unittest.mock import patch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import data_provider


def candles(start, end, step):
    rows, day = [], start
    while day <= end:
        rows.append((day, 10.0, 11.0, 9.0, 10.5, 100.0))
        day += timedelta(days=step)
    return rows


class DailyDataTests(unittest.TestCase):
    def test_four_hour_candles_follow_session_boundaries(self):
        hours = [(datetime(2025, 1, day, hour), hour, hour + 2, hour - 1, hour + 1, 10)
                 for day in (2, 3) for hour in range(10, 18)]
        with patch.object(data_provider, "_chart", return_value=hours):
            bars = data_provider.chart_bars("THYAO", "4H")
        self.assertEqual(len(bars), 4)
        self.assertEqual(bars[0], ("2025-01-02 10:00", 10, 15, 9, 14, 40))
        self.assertEqual(bars[2][0], "2025-01-03 10:00")

    def test_is_coarse(self):
        self.assertFalse(data_provider.is_coarse(candles(datetime(2025, 1, 1), datetime(2025, 3, 1), 1)))
        self.assertTrue(data_provider.is_coarse(candles(datetime(2020, 1, 1), datetime(2025, 3, 1), 7)))
        self.assertTrue(data_provider.is_coarse([("2024-01-01",), ("2024-02-01",)] * 4 + [("2024-03-01",), ("2024-04-01",)]))

    def test_long_range_weekly_answer_is_replaced_by_daily_chunks(self):
        calls = []

        def fake_chart(symbol, interval, rng=None, start=None, end=None):
            calls.append((start, end))
            first = datetime.fromisoformat(start)
            last = datetime.fromisoformat(end) if end else datetime(2026, 11, 1)
            span = (last - first).days
            return candles(first, last, 7 if span > 5 * 365 else 1)

        with patch.object(data_provider, "_chart", fake_chart):
            rows = data_provider.daily_rows("THYAO", start="2018-01-01", end="2026-01-01")
        self.assertFalse(data_provider.is_coarse(rows))
        self.assertGreater(len(calls), 2)
        self.assertEqual(len({row[0] for row in rows}), len(rows))


if __name__ == "__main__":
    unittest.main()
