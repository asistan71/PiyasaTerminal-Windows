"""Exercise actual Workshop canvas generation without a Flutter runtime.

The drawing primitives are test doubles, not a visual Windows test.
"""
import importlib.util
import sys
from pathlib import Path
from types import ModuleType, SimpleNamespace
from unittest import TestCase
from unittest.mock import patch


class Shape:
    fields = ()

    def __init__(self, *args, **kwargs):
        self.__dict__.update(zip(self.fields, args))
        self.__dict__.update(kwargs)
        self.data = kwargs.get('data')


class Line(Shape):
    fields = ('x1', 'y1', 'x2', 'y2')


class Rect(Shape):
    fields = ('x', 'y', 'width', 'height')


class Text(Shape):
    fields = ('x', 'y', 'value')
    max_width = None


class HeadlessChartTests(TestCase):
    def make_chart(self):
        ft, cv = ModuleType('flet'), ModuleType('flet.canvas')
        ft.canvas = cv
        ft.Paint = ft.TextStyle = SimpleNamespace
        ft.Offset = lambda x, y: (x, y)
        ft.Colors = SimpleNamespace(with_opacity=lambda opacity, color: (opacity, color))
        ft.StrokeCap = SimpleNamespace(BUTT='butt')
        cv.Line, cv.Rect, cv.Text, cv.Points = Line, Rect, Text, Shape
        cv.PointMode = SimpleNamespace(LINES='lines')
        spec = importlib.util.spec_from_file_location('headless_workshop', Path(__file__).resolve().parents[1] / 'chart_workshop.py')
        module = importlib.util.module_from_spec(spec)
        with patch.dict(sys.modules, {'flet': ft, 'flet.canvas': cv}):
            spec.loader.exec_module(module)
        chart = module.Workshop.__new__(module.Workshop)
        bars = [(f'2025-01-0{i+1}', p, p+1, p-1, p, v) for i,(p,v) in enumerate([(10,5),(20,50),(12,80)])]
        drawing = dict(tool='frvp', start=bars[0][0], end=bars[-1][0], style={'color':'#FF7070'})
        chart.__dict__.update(history=bars, start=0, span=3, width=900, height=650,
            readout=None, price_range=None, fit_levels=False, levels=[], segments=[], overlays=[],
            visible_volume=False, accumulation_line=False, marks={}, focus=None, watermark='THYAO',
            bar_index={b[0]:i for i,b in enumerate(bars)}, profile_cache={}, drawings=[drawing],
            canvas=SimpleNamespace(update=lambda:None), redraw_overlay=lambda **kw:None)
        chart.redraw(update=False)
        return module, chart, bars

    def test_profile_and_axes_and_resize(self):
        module, chart, bars = self.make_chart()
        shapes = chart.canvas.shapes
        self.assertEqual({s.paint.color for s in shapes if s.data=='frvp_volume'},
                         {(.55,"#628FC1"),(.55,"#758094")})
        self.assertFalse(any(s.data in ('ta','ta_hit') for s in shapes))
        for role in ('ta_lower','ta_upper'):
            parts=[s for s in shapes if s.data==role]
            self.assertTrue(parts)
            self.assertTrue(all(s.paint.color=='#FFFFFF' for s in parts))
        self.assertTrue(any(s.data=='poc' for s in shapes))
        self.assertIsInstance(shapes[0], Text)
        self.assertEqual(shapes[0].value, 'THYAO')
        self.assertEqual(shapes[0].style.color, module.watermark_color())
        self.assertEqual(module.watermark_color(), '#29323A')
        self.assertEqual(module.watermark_color('#FFFFFF'), '#F4F4F4')
        self.assertFalse(any(getattr(getattr(s,'paint',None),'color',None)=='#2A2E39' for s in shapes))
        self.assertEqual(len([s for s in shapes if isinstance(s,Text) and s.x==chart.plot_width+4 and s.value!='Hacim']),6)
        self.assertTrue(all(any(isinstance(s,Text) and s.value==b[0] for s in shapes) for b in bars))
        self.assertTrue(any(s.data=='ta_hit' for _,parts in chart.drawing_shapes for s in parts))
        plot = chart.plot_height
        chart.resize(SimpleNamespace(width=1000,height=900))
        self.assertEqual(chart.plot_height-plot,250)
        self.assertEqual(chart.plot_width,938)

    def test_bidirectional_empty_space_and_aligned_volume(self):
        module, chart, bars = self.make_chart()
        chart.__dict__.update(cursor=None, cursor_style="Çapraz", tool="İmleç",
            on_view=None, on_range=None, drag_origin=None, drag_endpoint=None,
            selected_profile=None, pan_frame=None, price_range=None)
        def volumes():
            return [(s.paint.color, s.paint.stroke_width, s.points) for s in chart.canvas.shapes
                    if isinstance(getattr(getattr(s, 'paint', None), 'color', None), tuple)
                    and s.paint.color[0] == .60]
        def at(x, y=100):
            return SimpleNamespace(local_position=SimpleNamespace(x=x,y=y))
        def assert_aligned(expected_indices):
            actual = sorted(pair[0] for _, _, points in volumes() for pair in points[::2])
            expected = [chart._x(i) for i in expected_indices]
            self.assertEqual(actual, expected)
            for _, _, points in volumes():
                for top, bottom in zip(points[::2], points[1::2]):
                    self.assertEqual(top[0], bottom[0])
                    self.assertEqual(bottom[1], chart.volume_base)
        assert_aligned([0, 1, 2])
        chart.begin_drag(at(20))
        chart.drag(at(20 + chart.step * 2))
        self.assertEqual(chart.start, -2)
        self.assertEqual(chart.bars, bars[:1])
        self.assertIsNone(chart.point(at(chart._x(0))))
        self.assertEqual(chart.point(at(chart._x(2)))[0], bars[0][0])
        self.assertEqual(chart.indices[bars[0][0]], 2)
        assert_aligned([2])
        chart.end_drag(None)
        assert_aligned([2])
        chart.begin_drag(at(20 + chart.step * 2))
        chart.drag(at(20 - chart.step * 2))
        chart.end_drag(None)
        self.assertEqual(chart.start, 2)
        self.assertEqual(chart.bars, bars[-1:])
        self.assertIsNone(chart.point(at(chart._x(1))))
        assert_aligned([0])
        chart.set_view(0, 2)
        assert_aligned([0, 1])
        chart.resize(SimpleNamespace(width=1100, height=800))
        assert_aligned([0, 1])
        self.assertEqual(module.clamp_view_start(-1000, 200, 100), -80)
        self.assertEqual(module.clamp_view_start(1000, 200, 100), 180)

    def test_new_drawing_tools(self):
        module, chart, bars = self.make_chart()
        a, b = (bars[0][0], 10), (bars[1][0], 20)
        chart.__dict__.update(tool='İmleç', anchor=None, cursor=None, pending_copy=None,
                              cursor_style='Çapraz', on_change=None, on_finish=None)
        def tap(point):
            x,y = chart._coords(point)
            chart.tap(SimpleNamespace(local_position=SimpleNamespace(x=x,y=y)))
        for name, tool in module.EXTRA_TOOLS.items():
            chart.tool = name
            tap(a)
            self.assertIsNotNone(chart.anchor)
            tap(b)
            self.assertEqual(chart.tool, 'İmleç')
            drawing, shapes = chart.drawing_shapes[-1]
            self.assertEqual(drawing['tool'], tool)
            self.assertTrue(shapes)
            for shape in shapes:
                if isinstance(shape, Line):
                    self.assertTrue(all(-1e-8 <= x <= chart.plot_width+1e-8 for x in (shape.x1,shape.x2)))
                    self.assertTrue(all(-1e-8 <= y <= chart.plot_height+1e-8 for y in (shape.y1,shape.y2)))
            line = next(s for s in shapes if isinstance(s,Line))
            self.assertIs(chart.drawing_at((line.x1+line.x2)/2,(line.y1+line.y2)/2),drawing)
            if tool == 'measure':
                self.assertTrue(any(isinstance(s,Text) and '+100.00%' in s.value and '1 mum' in s.value for s in shapes))
            if tool == 'circle':
                self.assertGreater(len(shapes), 5)
        self.assertEqual(chart._clipped_segment((10,20),(20,20),ray=True),(10,20,chart.plot_width,20))
        self.assertEqual(chart._clipped_segment((20,20),(10,20),ray=True),(20,20,0,20))
        self.assertIsNone(chart._clipped_segment((20,20),(20,20),ray=True))

    def test_parallel_channel(self):
        module, chart, bars = self.make_chart()
        chart.__dict__.update(tool='Paralel Kanal', anchor=None, channel_end=None, cursor=None, pending_copy=None,
                              cursor_style='Çapraz', on_change=None, on_finish=None)
        for point in [(bars[0][0], 10), (bars[2][0], 12), (bars[1][0], 14)]:
            x, y = chart._coords(point)
            chart.tap(SimpleNamespace(local_position=SimpleNamespace(x=x,y=y)))
        drawing, shapes = chart.drawing_shapes[-1]
        self.assertEqual(drawing['tool'], 'channel')
        self.assertEqual(chart.tool, 'İmleç')
        self.assertEqual(len(shapes), 3)
        slopes = [(s.y2-s.y1)/(s.x2-s.x1) for s in shapes]
        for slope in slopes:
            self.assertAlmostEqual(slope, slopes[0])
        chart.place_copy(dict(drawing), drawing['a'], (bars[0][0], 11))
        self.assertAlmostEqual(chart.drawings[-1]['c'][1], drawing['c'][1]+1)

    def test_advanced_channels(self):
        import json
        module, chart, bars = self.make_chart()
        chart.__dict__.update(anchor=None, channel_end=None, cursor=None, pending_copy=None,
                              cursor_style='Çapraz', on_change=None, on_finish=None)
        for name, tool in module.CHANNEL_TOOLS.items():
            if tool in module.POSITION_TOOLS.values(): continue
            with self.subTest(tool=tool):
                chart.tool = name
                for point in [(bars[0][0], 10), (bars[1][0], 18), (bars[2][0], 12)]:
                    x,y = chart._coords(point)
                    chart.tap(SimpleNamespace(local_position=SimpleNamespace(x=x,y=y)))
                drawing, shapes = chart.drawing_shapes[-1]
                self.assertEqual(drawing['tool'], tool)
                self.assertEqual(chart.tool, 'İmleç')
                self.assertGreaterEqual(len(shapes), 2)
                for line in shapes:
                    self.assertTrue(0 <= line.x1 <= chart.plot_width+1e-7)
                    self.assertTrue(0 <= line.y2 <= chart.plot_height+1e-7)
                chart.drawings = json.loads(json.dumps(chart.drawings))
                chart.redraw(update=False)
                self.assertTrue(chart.drawing_shapes[-1][1])

    def test_polygon(self):
        import asyncio, json
        module, chart, bars = self.make_chart()
        chart.__dict__.update(tool='Çokgen', polygon_points=[], anchor=None, cursor=None,
                              pending_copy=None, cursor_style='Çapraz', on_change=None, on_finish=None)
        for point in [(bars[0][0],10),(bars[1][0],18),(bars[2][0],12),(bars[1][0],11)]:
            x,y=chart._coords(point)
            chart.tap(SimpleNamespace(local_position=SimpleNamespace(x=x,y=y)))
        asyncio.run(chart.open_drawing_menu(SimpleNamespace(local_position=None)))
        self.assertEqual(chart.tool,'İmleç')
        self.assertEqual(chart.drawings[-1]['tool'],'polygon')
        self.assertEqual(len(chart.drawing_shapes[-1][1]),4)
        chart.drawings=json.loads(json.dumps(chart.drawings))
        chart.redraw(update=False)
        self.assertEqual(len(chart.drawing_shapes[-1][1]),4)

    def test_patterns(self):
        import json, asyncio
        module, chart, bars = self.make_chart()
        chart.__dict__.update(anchor=None, cursor=None, pending_copy=None, pattern_points=[],
                              cursor_style='Çapraz', on_change=None, on_finish=None)
        for name, (kind, labels) in module.PATTERN_TOOLS.items():
            with self.subTest(tool=kind):
                chart.tool = name
                for i in range(len(labels)):
                    x,y=chart._coords((bars[i%3][0], 10+i))
                    chart.tap(SimpleNamespace(local_position=SimpleNamespace(x=x,y=y)))
                self.assertEqual(chart.tool, 'İmleç')
                drawing, shapes=chart.drawing_shapes[-1]
                self.assertEqual(drawing['tool'],kind)
                self.assertEqual([s.value for s in shapes if isinstance(s,Text)],list(labels))
                self.assertEqual(len(drawing['points']),len(labels))
                chart.drawings=json.loads(json.dumps(chart.drawings))
                chart.redraw(update=False)
                self.assertTrue(chart.drawing_shapes[-1][1])
        chart.tool='XABCD'
        chart.pattern_points=[(bars[0][0],10)]
        asyncio.run(chart.open_drawing_menu(SimpleNamespace(local_position=None)))
        self.assertEqual(chart.pattern_points,[])

    def test_positions(self):
        module,chart,bars=self.make_chart()
        for name,kind in module.POSITION_TOOLS.items():
            chart.__dict__.update(tool=name,anchor=None,channel_end=None,cursor=None,pending_copy=None,cursor_style="Çapraz",on_change=None,on_finish=None,selected_position=None,position_drag=None)
            entry=12; target,stop=(18,10) if kind=="long_position" else (10,18)
            for point in [(bars[0][0],entry),(bars[2][0],target),(bars[1][0],stop)]:
                x,y=chart._coords(point); chart.tap(SimpleNamespace(local_position=SimpleNamespace(x=x,y=y)))
            d,shapes=chart.drawing_shapes[-1]
            self.assertEqual(d['tool'],kind)
            self.assertEqual(len([s for s in shapes if isinstance(s,Rect)]),2)
            self.assertAlmostEqual(chart.position_metrics(kind,d['a'],d['b'],d['c'])[0],3 if kind=="long_position" else 1/3)
            chart.selected_position=d
            field,x,y=next(h for h in chart.position_handles() if h[0]=='b')
            chart.begin_drag(SimpleNamespace(local_position=SimpleNamespace(x=x,y=y)))
            chart.drag(SimpleNamespace(local_position=SimpleNamespace(x=x,y=chart._y(17 if kind=='long_position' else 11))))
            chart.end_drag(None)
            self.assertAlmostEqual(d['b'][1],17 if kind=='long_position' else 11)

    def test_extended_fill_and_shape_drag(self):
        module, chart, bars = self.make_chart()
        a,b,c = (bars[0][0],10),(bars[1][0],15),(bars[2][0],12)
        for tool in ('rectangle','circle','ellipse','triangle','polygon','rotated_rect','channel','flat_channel','disjoint_channel','fib_channel'):
            with self.subTest(tool=tool):
                d=dict(tool=tool,a=a,b=b,c=c,points=[a,b,c],style={'fill':.15})
                chart.drawings=[d]; chart.redraw(update=False)
                fills=[s for s in chart.canvas.shapes if s.data=='drawing_fill']
                self.assertTrue(fills)
                self.assertTrue(all(0<=s.x<=s.x+s.width<=chart.plot_width and 0<=s.y<=s.y+s.height<=chart.plot_height for s in fills))
        d=dict(tool='rectangle',a=a,b=b)
        chart.drawings=[d]; chart.redraw(update=False)
        chart.__dict__.update(tool='İmleç',selected_drawing=d,selected_profile=None,selected_position=None,drag_endpoint=None,on_change=None)
        at=lambda x,y: SimpleNamespace(local_position=SimpleNamespace(x=x,y=y))
        x,y=chart._coords(a)
        chart.begin_drag(at(x,y)); chart.drag(at(x+chart.step,y)); chart.end_drag(None)
        self.assertEqual(d['a'][0],bars[1][0]); self.assertEqual(d['b'],b)
        x,y=chart._coords(d['a']); chart.begin_drag(at(x,y)); chart.drag(at(x,y-20)); chart.cancel_drag(None)
        self.assertAlmostEqual(d['a'][1],a[1])
        d['locked']=True; self.assertEqual(list(chart.shape_handles()),[])

    def test_offscreen_bounded_shapes(self):
        module, chart, bars = self.make_chart()
        chart.drawings = [{'tool':'rectangle','a':[bars[0][0],10],'b':[bars[1][0],20]}, {'tool':'ray','a':[bars[0][0],10],'b':[bars[1][0],20]}]
        chart.start=2; chart.span=1
        chart.redraw(update=False)
        assert [d['tool'] for d,_ in chart.drawing_shapes] == ['ray']
