# -*- coding: utf-8 -*-
"""Çekirdek mantık testleri — gerçek ağ kullanılmaz (sahte Yahoo/Binance yanıtları)."""
import math, os, random, sys, tempfile, threading, unittest
from datetime import datetime, timedelta, timezone
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import data_provider as dp
import evre_core as ev
import terminal_core as tc

def fake_yahoo(path, params):
    seed = sum(map(ord, path)) % 1000
    rnd = random.Random(seed)
    itv = params["interval"]
    step = {"1d": 86400, "1wk": 7 * 86400, "1h": 3600}[itv]
    n = {"1d": 1700, "1wk": 110, "1h": 220}[itv]
    if "USDTRY" in path: base = 6.0
    else: base = 20.0
    now = datetime.now(timezone.utc).replace(hour=7, minute=0, second=0, microsecond=0)
    ts, o, h, l, c, v = [], [], [], [], [], []
    p = base
    for i in range(n):
        t = now - timedelta(seconds=step * (n - i))
        if itv == "1d" and t.weekday() >= 5: continue
        drift = 0.0009 if "USDTRY" in path else 0.0
        wave = 0.012 * math.sin(i / 40.0)
        p = max(0.5, p * (1 + drift + wave * 0.1 + rnd.uniform(-0.02, 0.02)))
        hi, lo = p * (1 + rnd.uniform(0, .015)), p * (1 - rnd.uniform(0, .015))
        ts.append(int(t.timestamp())); o.append(p * .998); h.append(hi); l.append(lo); c.append(p); v.append(rnd.randint(10_000, 90_000) if "USDTRY" not in path else 0)
    return {"chart": {"result": [{"meta": {"gmtoffset": 10800}, "timestamp": ts, "indicators": {"quote": [{"open": o, "high": h, "low": l, "close": c, "volume": v}]}}], "error": None}}

class ProviderTests(unittest.TestCase):
    def setUp(self): self._g = dp._get; dp._get = fake_yahoo
    def tearDown(self): dp._get = self._g
    def test_full_daily_request_rejects_weekly_response(self):
        def weekly(path, params):
            self.assertEqual(params["interval"], "1d")
            self.assertIn("period1", params)
            self.assertNotIn("range", params)
            result = fake_yahoo(path, params)
            result["chart"]["result"][0]["meta"]["dataGranularity"] = "1wk"
            return result
        dp._get = weekly
        with self.assertRaisesRegex(ValueError, "günlük mum"):
            dp.daily_df("THYAO")

    def test_symbol_map(self):
        self.assertEqual(dp.yahoo_symbol("THYAO"), "THYAO.IS"); self.assertEqual(dp.yahoo_symbol("USDTRY"), "USDTRY=X"); self.assertEqual(dp.yahoo_symbol("XU100"), "XU100.IS")
    def test_history_tf(self):
        for tf in ("1W", "1D", "1H"):
            d = dp.history_tf("THYAO", tf); self.assertGreaterEqual(len(d["close"]), 50); self.assertTrue(d["last_date"])
    def test_normalize_via_miniframe(self):
        bars = ev.normalize(dp.daily_df("THYAO")); self.assertGreater(len(bars), 1000)
        self.assertEqual(len(bars[0]), 6)
        fx = ev.normalize(dp.daily_df("USDTRY"), True); self.assertEqual(fx[0][1], fx[0][4])

class EvrePipeline(unittest.TestCase):
    def setUp(self): self._g = dp._get; dp._get = fake_yahoo; self.tmp = tempfile.mkdtemp(); self.db = os.path.join(self.tmp, "e.sqlite3")
    def tearDown(self): dp._get = self._g
    def test_scan_iter(self):
        stop = threading.Event(); got = {}
        for ev_ in ev.scan_iter(["THYAO", "GARAN"], self.db, False, stop, workers=2):
            if ev_[0] == "result": got[ev_[1]] = ev_[2]
            if ev_[0] == "error": self.fail(ev_)
        self.assertEqual(set(got), {"THYAO", "GARAN"})
        r = got["THYAO"]
        for k in ("score", "phase", "plan", "structure", "opportunity", "series", "tlsp", "val", "poc", "vah", "date"): self.assertIn(k, r)
        self.assertIn(r["phase"]["phase"], ("TL", "Dolar", "Pivot", "Belirsiz"))
        self.assertTrue(0 <= r["score"] <= 100)
    def test_offline_uses_cache(self):
        stop = threading.Event(); list(ev.scan_iter(["THYAO"], self.db, False, stop, workers=1))
        dp._get = lambda *a, **k: (_ for _ in ()).throw(AssertionError("ağ kullanılmamalı"))
        res = [e for e in ev.scan_iter(["THYAO"], self.db, False, stop, workers=1, offline=True) if e[0] == "result"]
        self.assertEqual(len(res), 1)

class BistMultiTF(unittest.TestCase):
    def setUp(self): self._g = dp._get; dp._get = fake_yahoo; tc.FILTERS_OFF["BIST"] = True; tc._bist_cache.clear()
    def tearDown(self): dp._get = self._g; tc.FILTERS_OFF["BIST"] = False
    def test_analyze(self):
        r = tc.analyze_bist_stock("THYAO", ["1W", "1D", "1H"])
        self.assertNotIn("Hata", r, r); self.assertIn(r["Sinyal"], ("TEYITLI LONG", "ERKEN LONG", "IZLE")); self.assertTrue(0 <= r["Puan"] <= 100)
    def test_scan_progress(self):
        rows = []; stop = threading.Event()
        tc.run_bist_scan(["1D"], "Yıldız", lambda k, p: rows.append(k), stop)
        self.assertIn("finished", rows)

def fake_klines(n=120, trend=1.0):
    out = []; p = 100.0; t0 = 1_700_000_000_000
    for i in range(n):
        p *= 1 + trend * 0.002 + random.Random(i).uniform(-.003, .003)
        out.append([t0 + i * 300000, p * .999, p * 1.004, p * .996, p, 1000 + (i % 7) * 100])
    return out

class BinanceLogic(unittest.TestCase):
    def setUp(self):
        self._g = tc.binance_get; tc._binance_kline_cache.clear(); tc.binance_get = lambda ep, params=None: fake_klines(130)
    def tearDown(self): tc.binance_get = self._g
    def test_score_and_plan(self):
        d = {tf: tc.binance_get_market_data("XYZUSDT", tf) for tf in ("5m", "15m", "1h")}
        m5, m15, h1 = (tc.binance_analyze_tf(d[k]) for k in ("5m", "15m", "1h"))
        ls = tc.score_direction(m5, m15, h1, "LONG", "KARISIK"); ss = tc.score_direction(m5, m15, h1, "SHORT", "KARISIK")
        sig, side, best = tc.determine_signal(ls, ss, m5, m15, h1, "KARISIK")
        self.assertIn(side, ("LONG", "SHORT", "YOK"))
        plan = tc.calculate_binance_plan("XYZUSDT", d["5m"], m5, "LONG")
        if plan: self.assertLess(plan["Stop"], plan["Giris"])
    def test_tr_symbol(self):
        r = tc.analyze_tr_symbol("ABC_TRY"); self.assertEqual(r["Yon"], "LONG"); self.assertIn("Puan", r)

class VirtualTrades(unittest.TestCase):
    def test_open_close_and_cash(self):
        trades = []
        t = tc.open_virtual_trade(trades, "BTC_TRY", "LONG", 100.0, 10, stop=90)
        self.assertEqual(tc.tr_spot_available_tl(trades, 100000), 100000 - 1000)
        tc.close_virtual_trade(t, 110.0); self.assertAlmostEqual(t["KZ"], 100.0); self.assertEqual(tc.tr_spot_available_tl(trades, 100000), 100100)
    def test_rules(self):
        with self.assertRaises(ValueError): tc.open_virtual_trade([], "BTC_TRY", "SHORT", 1, 1)
        with self.assertRaises(ValueError): tc.open_virtual_trade([], "THYAO", "LONG", 100, 5, stop=120)
        with self.assertRaises(ValueError): tc.open_virtual_trade([], "THYAO", "LONG", 100, 5000)
        t = tc.open_virtual_trade([], "BTCUSDT", "SHORT", 100, 1, stop=110, leverage=5); self.assertEqual(t["Para"], "USDT")

if __name__ == "__main__": unittest.main()
