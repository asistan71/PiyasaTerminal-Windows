import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
import updater
from test_updater import build_zip

class ReleaseChannelTests(unittest.TestCase):
    def test_manifest_policy(self):
        info = {'version':'4.9.79','url':'https://example.com/p.zip','sha256':'a'*64,'available':True}
        with patch.object(updater,'check',return_value=info):
            self.assertEqual(updater.check_chatgpt_channel('github:owner/repo','4.9.78'),info)
            with self.assertRaises(updater.UpdateError):
                updater.check_chatgpt_channel('http://example.com/m.json','4.9.78')
            info['sha256']=''
            with self.assertRaises(updater.UpdateError):
                updater.check_chatgpt_channel('github:owner/repo','4.9.78')
    def test_install_version_mismatch(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp)
            (root/'version.py').write_text('APP_VERSION = "4.9.78"')
            package=build_zip(root/'package.zip','4.9.80')
            info={'version':'4.9.79','url':'https://example.com/p.zip','sha256':'a'*64}
            with patch.object(updater,'download',return_value=package), patch.object(updater,'apply_zip') as apply:
                with self.assertRaises(updater.UpdateError):
                    updater.install_checked_release(info,'4.9.78',package,app_dir=root)
                apply.assert_not_called()
            info['version']='4.9.80'
            with patch.object(updater,'download',return_value=package):
                result=updater.install_checked_release(info,'4.9.78',package,app_dir=root)
                self.assertEqual(result['new'],'4.9.80')
