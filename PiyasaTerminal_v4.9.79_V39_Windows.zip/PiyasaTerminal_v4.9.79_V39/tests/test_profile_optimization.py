import random
from evre_core import profile_bins, profile_levels

def reference(bars,n=48):
    lo=min(b[3] for b in bars); hi=max(b[2] for b in bars); step=(hi-lo)/n
    a=[0.]*(n if step else 1); total=0.; dev=[]
    for _,o,h,l,c,v in bars:
        total+=v
        if not step: a[0]+=v
        else:
            i=max(0,min(n-1,int((l-lo)/step))); j=max(0,min(n-1,int((h-lo)/step)))
            if h==l: a[i]+=v
            else:
                for k in range(i,j+1): a[k]+=v*max(0,min(h,lo+(k+1)*step)-max(l,lo+k*step))/(h-l)
        dev.append(profile_levels(a,lo,step) if total>0 else None)
    return (*profile_levels(a,lo,step),lo,step,a),dev

def test_exact_profile_equivalence():
    rng=random.Random(77)
    for count in (1,100,2000):
        bars=[]
        for i in range(count):
            l=rng.uniform(1,100); h=l+rng.uniform(0,50); v=0 if i%3==0 else rng.uniform(1,10000)
            bars.append((str(i),l,h,l,h,v))
        dev=[]; result=profile_bins(bars,developing=dev)
        assert (result,dev)==reference(bars)
    for bars in [[('0',10,10,10,10,0),('1',10,10,10,10,100)], [('0',10,10,10,10,0)]]:
        dev=[]; assert (profile_bins(bars,developing=dev),dev)==reference(bars)
