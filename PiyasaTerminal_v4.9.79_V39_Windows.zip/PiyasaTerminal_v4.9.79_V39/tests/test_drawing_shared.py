from drawing_shared import project_drawings
from copy import deepcopy

def test_projection():
    key='bist|THYAO|1D'; target='bist|THYAO|1W'
    d={'tool':'rectangle','a':['2025-01-02',10],'b':['2025-01-08',15],'all_timeframes':True}
    records={key:[d],target:[]}; old=deepcopy(records)
    bars=[('2025-01-01',),('2025-01-07',),('2025-01-14',)]
    out=project_drawings(records,target,bars)
    assert out[0]['a']==['2025-01-01',10] and out[0]['b']==['2025-01-07',15]
    assert records==old
    assert not project_drawings(records,'bist|ASELS|1W',bars)
    assert not project_drawings(records,'bist|THYAO|USD',bars)
    assert not project_drawings(records,target,[('2025-01-07',),('2025-01-14',)])


def test_projection_edit_source_mapping():
    original = {'tool':'rectangle','a':['2025-01-02',10],'b':['2025-01-08',15],'all_timeframes':True}
    records = {'bist|THYAO|1D':[original]}
    sources = {}
    projected = project_drawings(records, 'bist|THYAO|1W', [('2025-01-01',),('2025-01-07',),('2025-01-14',)], sources=sources)[0]
    assert sources[id(projected)] is original
    sources[id(projected)]['style'] = {'color':'#FFFFFF'}
    assert original['a'] == ['2025-01-02',10]
    assert original['style']['color'] == '#FFFFFF'


def test_commit_projection_preserves_unchanged_dates():
    from drawing_shared import commit_projection
    original = {'a':['2025-01-02',10], 'b':['2025-01-08',15]}
    before = {'a':['2025-01-01',10], 'b':['2025-01-07',15]}
    after = {'a':['2025-01-01',12], 'b':['2025-01-14',17]}
    assert commit_projection(original,before,after)
    assert original == {'a':['2025-01-02',12], 'b':['2025-01-14',17]}
    original['locked']=True
    assert not commit_projection(original,before,after)


def test_special_projection_edits():
    from drawing_shared import commit_projection
    p={'tool':'frvp','start':'2025-01-02','end':'2025-01-08'}
    before={'tool':'frvp','start':'2025-01-01','end':'2025-01-07'}
    after=dict(before,end='2025-01-14')
    assert commit_projection(p,before,after)
    assert p['start']=='2025-01-02' and p['end']=='2025-01-14'
    p={'tool':'long_position','a':['2025-01-02',10],'b':['2025-01-08',15],'c':['2025-01-08',8]}
    before={'tool':'long_position','a':['2025-01-01',10],'b':['2025-01-07',15],'c':['2025-01-07',8]}
    after=dict(before,b=['2025-01-07',17])
    assert commit_projection(p,before,after)
    assert p['b']==['2025-01-08',17] and p['c']==['2025-01-08',8]
