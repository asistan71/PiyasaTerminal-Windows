"""EVRE causal-signal historical outcome audit (not investment advice)."""
from __future__ import annotations
import csv
from datetime import datetime
from pathlib import Path
from early_liftoff import early_liftoff_signals

CIRCLE_WINDOWS = (('İlk kalkış bölgesi', '2026-03-20', '2026-04-12'),
                  ('Yeniden birikim bölgesi', '2026-06-08', '2026-06-25'))


def _date(v):
    if hasattr(v, 'strftime'): return v.strftime('%Y-%m-%d')[:10]
    s = str(v).strip().split(' ')[0]
    for fmt in ('%Y-%m-%d', '%d.%m.%Y', '%Y/%m/%d'):
        try: return datetime.strptime(s[:10], fmt).strftime('%Y-%m-%d')
        except ValueError: pass
    raise ValueError('Bilinmeyen tarih: '+s)


def load_csv(path):
    """Accept CSV with Date, Open, High, Low, Close, Volume (English/Turkish)."""
    with open(path, encoding='utf-8-sig', newline='') as f:
        sample = f.read(4096); f.seek(0)
        try: delimiter=csv.Sniffer().sniff(sample, delimiters=',;\t').delimiter
        except csv.Error: delimiter=','
        reader=csv.DictReader(f,delimiter=delimiter)
        aliases={'date':('date','tarih','datetime','time'), 'open':('open','acilis','açılış'),
                 'high':('high','yuksek','yüksek'), 'low':('low','dusuk','düşük'),
                 'close':('close','kapanis','kapanış','adj close'), 'volume':('volume','hacim')}
        cols={}
        for key,opts in aliases.items():
            matching=[c for c in (reader.fieldnames or []) if c.strip().lower() in opts]
            if not matching: raise ValueError('CSV sütunu eksik: '+key)
            cols[key]=matching[0]
        rows=[]
        for r in reader:
            def num(key):
                s=str(r[cols[key]]).strip().replace(' ','')
                if delimiter==';' and ',' in s and '.' not in s: s=s.replace(',','.')
                return float(s.replace(',',''))
            rows.append((_date(r[cols['date']]),num('open'),num('high'),num('low'),num('close'),num('volume')))
    rows.sort(key=lambda x:x[0])
    if len(set(x[0] for x in rows))!=len(rows): raise ValueError('CSV tarihleri tekrarlı')
    return rows


def evaluate(bars, horizon=10, gain_pct=10.0, loss_pct=7.0, circle_windows=CIRCLE_WINDOWS):
    """Signal uses only past bars. Outcome, measured separately, may look forward.

    Same day high/low touching both thresholds is ambiguous, not assumed success.
    Dates in circle_windows are approximate visual annotations, not verified ground truth.
    """
    if horizon<1 or gain_pct<=0 or loss_pct<=0: raise ValueError('Pozitif eşikler gerekli')
    signals=early_liftoff_signals(bars, lookback=len(bars), cooldown=4)
    results=[]
    for s in signals:
        i=s['index']; base=float(bars[i][4]); decision='YETERSİZ GELECEK VERİ'
        when=None; bars_until=None
        if base<=0: continue
        for j in range(i+1,min(i+1+horizon,len(bars))):
            high=float(bars[j][2]); low=float(bars[j][3])
            up=high>=base*(1+gain_pct/100); down=low<=base*(1-loss_pct/100)
            if up and down: decision='BELİRSİZ (AYNI MUM)'
            elif up: decision='HEDEF'
            elif down: decision='STOP'
            else: continue
            when=_date(bars[j][0]); bars_until=j-i
            break
        else:
            if i+horizon < len(bars): decision='SÜRE DOLDU'
        day=_date(s['date'])
        group=next((label for label,start,end in circle_windows if start<=day<=end),'Çember dışı')
        results.append(dict(date=day,kind=s['status'],score=s['score'],rvol=s['rvol'],
                            close=base,poc=s.get('poc'),poc_state=s.get('poc_state'),outcome=decision,outcome_date=when,days=bars_until,
                            region=group,index=i))
    resolved=[r for r in results if r['outcome'] in ('HEDEF','STOP','SÜRE DOLDU')]
    wins=sum(r['outcome']=='HEDEF' for r in resolved)
    loses=sum(r['outcome']!='HEDEF' for r in resolved)
    summary=dict(total=len(results),resolved=len(resolved),wins=wins,failed=loses,
                 win_rate=round(100*wins/len(resolved),1) if resolved else None,
                 unknown=len(results)-len(resolved),horizon=horizon,
                 gain_pct=gain_pct,loss_pct=loss_pct)
    circles=[]
    for label,start,end in circle_windows:
        sample=[r for r in results if start<=r['date']<=end]
        circles.append(dict(name=label,start=start,end=end,signals=len(sample),
                            first_date=sample[0]['date'] if sample else None,
                            outcomes={kind:sum(r['outcome']==kind for r in sample)
                                      for kind in ('HEDEF','STOP','SÜRE DOLDU','BELİRSİZ (AYNI MUM)','YETERSİZ GELECEK VERİ')}))
    return summary,circles,results


def export_csv(path, results):
    fields=('date','region','kind','score','rvol','poc','poc_state','close','outcome','outcome_date','days')
    with open(path,'w',newline='',encoding='utf-8-sig') as f:
        w=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore');w.writeheader();w.writerows(results)
