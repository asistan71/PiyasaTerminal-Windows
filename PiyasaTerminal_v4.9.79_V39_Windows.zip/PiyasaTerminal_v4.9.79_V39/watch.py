"""Kalıcı kalkış takibi; yalnızca tamamlanmış mum sinyalleri."""
import sqlite3
from contextlib import closing

def classify(r):
    if r['alarm']: return 'Kalkış alarmı'
    if r['structure']['state']=='Hacim bekleniyor' and r['score']>=70: return 'Kalkışa hazırlık'
    return None

def connect(path):
    con=sqlite3.connect(path,timeout=2)
    con.execute('CREATE TABLE IF NOT EXISTS watch(symbol TEXT PRIMARY KEY, day TEXT, phase TEXT, score INTEGER, state TEXT, price REAL, ratio REAL)')
    con.execute('CREATE TABLE IF NOT EXISTS alarms(symbol TEXT, day TEXT, PRIMARY KEY(symbol,day))')
    return con

def update(path,symbol,r):
    state=classify(r)
    with closing(connect(path)) as con, con:
        if state:
            con.execute('INSERT OR REPLACE INTO watch VALUES (?,?,?,?,?,?,?)',(symbol,r['date'],r['phase']['phase'],r['score'],state,r['price'],r['ratio']))
        else:
            con.execute('UPDATE watch SET day=?,phase=?,score=?,state=?,price=?,ratio=? WHERE symbol=?',(r['date'],r['phase']['phase'],r['score'],'Koşul artık yok',r['price'],r['ratio'],symbol))
        if r['alarm']:
            return con.execute('INSERT OR IGNORE INTO alarms VALUES (?,?)',(symbol,r['date'])).rowcount==1
    return False

def rows(path):
    with closing(connect(path)) as con, con:
        return con.execute('SELECT * FROM watch ORDER BY score DESC,symbol').fetchall()

def remove(path,symbol):
    with closing(connect(path)) as con, con: con.execute('DELETE FROM watch WHERE symbol=?',(symbol,))
