# -*- coding: utf-8 -*-
"""Dip Hacim Radarı + Dip Patlama Hafızası — Android çekirdeği (Tkinter'siz).

detect_bottom_volume (dip_hacim_radari.py) ve scan_explosions/archive/read_archive
(dip_patlama_hafizasi.py) gövdeleri AST ile aynen alınmıştır. Yalnızca tamamlanmış günlük
mumlar kullanılır; sonuçlar işlem tavsiyesi değil, tanısal adaylardır.
"""
from __future__ import annotations
import sqlite3
from datetime import date
from pathlib import Path
from statistics import mean

SCHEMA_VERSION = 'v030-1'
WINDOWS = (3, 5, 10)

def detect_bottom_volume(bars, today=None):
    """Three states, no lookahead: quiet bottom, spike at bottom, later confirmation.

    Values are diagnostic candidates, not trade recommendations. Each result
    depends only on data up to last completed daily candle.
    """
    today = today or date.today()
    today_str = today.isoformat()
    b = sorted((tuple(x) for x in bars if str(x[0]) < today_str), key=lambda x: x[0])
    if len(b) < 125:
        return {'state':'Veri yetersiz','note':f'En az 125 tamamlanmış mum gerekir ({len(b)} mevcut)',
                'score':0,'date':b[-1][0] if b else '', 'bars':b}
    last = len(b)-1
    # Decline in the preceding 80 days; structural bottom in the last 90 days.
    close = b[-1][4]
    peak = max(x[2] for x in b[-91:-11])
    drawdown = (close / peak - 1)*100 if peak>0 else 0.
    low90 = min(x[3] for x in b[-90:])
    near_bottom = close <= low90*1.20
    # Spike can have occurred recently: use only bars that existed when it occurred.
    candidates=[]
    for i in range(max(110,last-12),last+1):
        p=b[i]; prior=b[i-20:i]
        older=b[i-90:i-20]
        quiet=b[i-12:i]
        if len(prior)<20 or len(older)<50 or len(quiet)<12:continue
        avg20=mean(max(0,x[5]) for x in prior)
        historical=mean(max(0,x[5]) for x in older)
        quiet_avg=mean(max(0,x[5]) for x in quiet)
        quiet_ratio=quiet_avg/historical if historical>0 else 999.
        quiet_days=sum(1 for x in quiet if x[5]<historical*.65)
        spike_ratio=p[5]/avg20 if avg20>0 else 0.
        bottom_at_event=min(x[3] for x in b[max(0,i-90):i+1])
        old_high=max(x[2] for x in b[max(0,i-90):max(1,i-10)])
        decline=(p[4]/old_high-1)*100 if old_high>0 else 0.
        event_near=p[3]<=bottom_at_event*1.12 and p[4]<=bottom_at_event*1.25
        quiet_ok=quiet_ratio <= .70 and quiet_days>=7
        spike_ok=spike_ratio>=2.5
        # Candle must be bullish to be 'reaction' (may not be a sustained breakout).
        bullish=p[4]>p[1] and p[4]>b[i-1][4]
        if not (decline<=-15 and event_near and quiet_ok and spike_ok and bullish):continue
        candidates.append((i,spike_ratio,quiet_ratio,quiet_days,decline))
    if candidates:
        i,volx,qratio,qdays,decline=candidates[-1]
        event=b[i]; elapsed=last-i
        since=b[i+1:]
        # Completion is observed AFTER event, not retroactively asserted on event day.
        confirm=any(x[4]>event[2]*1.02 for x in since) and min(x[3] for x in since+[event])>=event[3]*.98
        invalid=bool(since and min(x[3] for x in since)<event[3]*.98)
        state=('Tepki teyidi' if confirm else 'Dip kaybı / risk' if invalid else 'Hacimli dip tepkisi')
        score=min(100,round(30*min(volx/4,1)+25*min((1-qratio)/.6,1)+20*min(-decline/40,1)+15*min(qdays/12,1)+(10 if confirm else 0)))
        return dict(state=state,score=score,date=b[-1][0],event=event[0],days_ago=elapsed,
                    volx=round(volx,2),quiet_ratio=round(qratio,2),quiet_days=qdays,decline=round(decline,1),
                    note='Tepki sonrası yükseliş görüldü' if confirm else 'Dip altına sarktı; teyit yok' if invalid else 'Dipte hacimli tepki; devam teyidi bekleniyor',bars=b)
    # Quiet candidate: current data only, no anticipation of a future spike.
    prior=b[-90:-20]; recent=b[-12:]; hist=mean(x[5] for x in prior)
    qratio=mean(x[5] for x in recent)/hist if hist>0 else 999
    quiet_days=sum(x[5]<.65*hist for x in recent)
    if drawdown<=-15 and near_bottom and qratio<=.70 and quiet_days>=7:
        score=min(85,round(30*min(-drawdown/40,1)+30*min((1-qratio)/.65,1)+25*min(quiet_days/12,1)))
        state='Sessiz dip'
        note='Hacim sönüyor; henüz patlama veya kalkış teyidi yok'
    else:
        score=0;state='Koşul yok';note='Sessiz dip ve hacimli tepki şartları birlikte bulunmadı'
    return dict(state=state,score=score,date=b[-1][0],event='',days_ago='',volx=None,
                quiet_ratio=round(qratio,2),quiet_days=quiet_days,decline=round(drawdown,1),note=note,bars=b)

def scan_explosions(bars, today=None, min_drop=15, min_spike=3.0):
    """Return chronological events. No event-time condition reads subsequent candles.

    OHLCV tuples: (YYYY-MM-DD, open, high, low, close, volume).
    Uses completed days only. Historical daily 'adjust' data can be revised by
    corporate actions; refresh the archive by symbol rather than append blindly.
    """
    cutoff = (today or date.today()).isoformat()
    b = sorted(((str(r[0]), *map(float, r[1:6])) for r in bars if str(r[0]) < cutoff), key=lambda x:x[0])
    if len(b) < 110:
        return [], b
    v = [max(0.,r[5]) for r in b]
    pv = [0.]
    for x in v: pv.append(pv[-1]+x)
    def avg(a, z): return (pv[z]-pv[a])/(z-a) if z>a else 0.
    events=[]
    for i in range(100,len(b)):
        d,o,h,l,c,vol = b[i]
        hist60 = avg(i-72,i-12)
        quiet12 = avg(i-12,i)
        avg20 = avg(i-20,i)
        if hist60<=0 or avg20<=0 or h<=l or o<=0: continue
        qratio=quiet12/hist60
        qdays=sum(x < hist60*.65 for x in v[i-12:i])
        if qratio>.70 or qdays<7: continue
        past_high=max(x[2] for x in b[i-90:i-10])
        past_low=min(x[3] for x in b[i-90:i])
        if past_high<=0 or past_low<=0:continue
        drop=(c/past_high-1)*100
        # An initial rebound can close above the low yet still be in bottom zone.
        near=(l<=past_low*1.15 and c<=past_low*1.32)
        spike=vol/avg20
        # Close in top half, rising vs prior close: distinct from assumed 'buyers' count.
        close_position=(c-l)/(h-l)
        rebound=(c>b[i-1][4] and c>=o and close_position>=.55)
        if not (drop<=-min_drop and near and spike>=min_spike and rebound):continue
        score=round(min(100, 25*min(-drop/40,1)+25*min((1-qratio)/.7,1)+30*min(spike/6,1)+10*min(qdays/12,1)+10*close_position))
        event={'date':d,'o':o,'h':h,'l':l,'c':c,'volume':vol,'score':score,
               'spike':round(spike,2),'volume60':round(vol/hist60,2),
               'quiet_ratio':round(qratio,3),'quiet_days':qdays,'drop':round(drop,2),
               'bottom_gap':round((l/past_low-1)*100,2),'close_position':round(close_position,2)}
        # Do not combine recurrent event dates; every valid historical signal is archived.
        for n in WINDOWS:
            future=b[i+1:i+1+n]
            if len(future)==n:
                # Close-to-close percent at exactly n completed sessions.
                event[f'return_{n}']=round((future[-1][4]/c-1)*100,2)
                event[f'peak_{n}']=round((max(x[2] for x in future)/c-1)*100,2)
                event[f'drawdown_{n}']=round((min(x[3] for x in future)/c-1)*100,2)
                # Approximation only: limit-up percentage differs by board/time;
                # do not claim official limit-up counts from adjusted OHLCV.
                pairs=zip(b[i:i+n],b[i+1:i+1+n])
                event[f'near_limit_{n}']=sum(1 for prev,cur in pairs if prev[4]>0 and (cur[4]/prev[4]-1)>=.095)
            else:
                event[f'return_{n}']=None
                event[f'peak_{n}']=None
                event[f'drawdown_{n}']=None
                event[f'near_limit_{n}']=None
        if event['return_10'] is None:
            event['result']='İzleniyor'
        elif event['peak_10']>=30:
            event['result']='10G zirve ≥%30'
        else:
            event['result']='10G zirve <%30'
        events.append(event)
    return events,b

def archive(db, symbol, events, last_date):
    """Transactional replacement avoids duplicate/stale records after price adjustments."""
    Path(db).parent.mkdir(parents=True,exist_ok=True)
    with sqlite3.connect(db,timeout=20) as con:
        con.execute('CREATE TABLE IF NOT EXISTS dip_events(symbol TEXT NOT NULL, day TEXT NOT NULL, data TEXT NOT NULL, PRIMARY KEY(symbol,day))')
        con.execute('CREATE TABLE IF NOT EXISTS dip_archive_meta(symbol TEXT PRIMARY KEY, last_day TEXT, version TEXT)')
        import json
        con.execute('DELETE FROM dip_events WHERE symbol=?',(symbol,))
        con.executemany('INSERT INTO dip_events VALUES(?,?,?)',[(symbol,e['date'],json.dumps(e,ensure_ascii=False)) for e in events])
        con.execute('INSERT OR REPLACE INTO dip_archive_meta VALUES(?,?,?)',(symbol,last_date,SCHEMA_VERSION))

def read_archive(db, symbols=None):
    db=Path(db)
    if not db.exists():return []
    with sqlite3.connect(db,timeout=10) as con:
        try: rows=con.execute('SELECT symbol,data FROM dip_events ORDER BY day DESC').fetchall()
        except sqlite3.OperationalError: return []
    import json
    wanted=set(symbols) if symbols else None
    return [dict(symbol=s,**json.loads(data)) for s,data in rows if wanted is None or s in wanted]

