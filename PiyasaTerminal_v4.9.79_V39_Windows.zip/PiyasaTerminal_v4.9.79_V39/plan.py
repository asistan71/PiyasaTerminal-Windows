"""Deneysel TL hedefleri ve işlem simülasyonu. Yatırım tavsiyesi değildir."""
from math import ceil

def camarilla(bar):
    _,o,h,l,c,v=bar; r=h-l
    return {'R3':c+1.1*r/4,'R4':c+1.1*r/2,'R5':h/l*c,'S3':c-1.1*r/4,'S4':c-1.1*r/2}

def make_plan(bars,sp,ph,st):
    p=bars[-1][4]; m,s=sp[-1]; peak=ph['peak']; pm,ps=sp[peak]
    # Önceki zirvenin temas ettiği bandı bugünkü TL sarmalına taşı.
    k=round((bars[peak][2]-pm)/ps*2)/2 if ps>0 else None
    k=max(-4,min(4,k)) if k is not None else None
    target=m if ph['phase']=='TL' else (m+k*s if k is not None and k>0 and ph['phase'] in ('Dolar','Pivot') else None)
    if target is not None and target<=p: target=None
    next_bands=[m+j*.5*s for j in range(-8,9) if target is not None and m+j*.5*s>target+1e-9]
    runner=min(next_bands) if next_bands else None
    sig=st['signal']; stop=None
    if sig is not None and sig>0:
        # Kalkış öncesindeki teyitli son dip, yoksa önceki 5 mumun dibi.
        candidates=[i for i in range(max(2,sig-30),sig-2) if bars[i][3]<=min(b[3] for b in bars[i-2:i+3])]
        stop=bars[candidates[-1]][3] if candidates else min(b[3] for b in bars[max(0,sig-5):sig])
        if stop>=p: stop=None
    return dict(target=target,runner=runner,stop=stop,band=k,cam=camarilla(bars[-2]),potential=(target/p-1)*100 if target else None)

def simulate(bars,signals,with_stop=True,pullback=False,fee=.001):
    """Tek pozisyon; kapanış sinyali sonrası seans. Sabit hedef, anapara çıkışı, kalan üst bant.
    Günlük OHLC'de belirsiz sırada stop önce; tek fiyat yukarı boşlukta alış yok.
    """
    cash=100000.; qty=0.; initial=cash; entry=0.; target=runner=stop=None; recovered=False; pending=None; trades=[]; equity=[]; missed=0; capital=0.; start=None
    for i,b in enumerate(bars):
        d,o,h,l,c,v=b
        if qty==0 and pending is not None:
            si,pl=pending
            if i>si:
                level=bars[si][4]; price=(o if not pullback else min(o,level) if l<=level else None)
                if h==l and o>bars[i-1][4]: price=None
                if price is not None and pl['target']>price and (not with_stop or pl['stop'] is not None and price>pl['stop']):
                    qty=int(cash/(price*(1+fee))); entry=price; capital=qty*price*(1+fee); cash-=capital; target=pl['target']; runner=pl['runner']; stop=pl['stop'] if with_stop else None; recovered=False; start=d
                    pending=None
                elif not pullback or i-si>=5: missed+=1; pending=None
        if qty:
            exit_price=None; reason=None
            if stop is not None and l<=stop: exit_price=min(o,stop); reason='Stop'
            elif not recovered and h>=target:
                # Hedefte anaparayı mümkün olduğu kadar geri al; lot tam sayı.
                sell=min(qty,ceil(capital/(target*(1-fee)))); cash+=sell*target*(1-fee); qty-=sell; recovered=True
                if qty==0: trades.append((start,d,'Ana hedef',round(cash,2)))
                # Aynı mumda runner gerçekleşti varsayımı yapılmaz.
            elif recovered and runner is not None and h>=runner: exit_price=runner; reason='Üst bant'
            if exit_price is not None:
                cash+=qty*exit_price*(1-fee); qty=0; trades.append((start,d,reason,round(cash,2)))
        if not qty and pending is None and i in signals:
            pl=signals[i]
            if pl['target'] and (not with_stop or pl['stop']): pending=(i,pl)
        equity.append(cash+qty*c)
    peak=initial; dd=0
    for x in equity: peak=max(peak,x); dd=max(dd,1-x/peak)
    return dict(return_pct=(equity[-1]/initial-1)*100 if equity else 0,drawdown=dd*100,closed=len(trades),open=bool(qty),missed=missed,trades=trades)

def backtest(bars,usd,tlsp,usp,profile,days=None):
    from phase import phases
    from structure import detect
    signals={}; start=max(32,len(bars)-(days or len(bars)))
    diag=dict(bars=len(bars)-start, first=bars[start][0] if start<len(bars) else "-", last=bars[-1][0], volume=0, structure=0, no_target=0, no_stop=0, dates=[])
    for i in range(start,len(bars)):
        # Hacim kapısı: pahalı yapı hesabı yalnızca olası kalkış günlerinde.
        b=bars[i]; hist=[x[5] for x in bars[i-30:i]]; avg=sum(hist)/30
        if not (b[4]>b[1] and avg>0 and b[5]>max(hist) and b[5]>=2.5*avg): continue
        diag['volume']+=1
        ph=phases(usd[:i+1],usp[:i+1]); st=detect(bars[:i+1],ph['peak'],profile)
        if ph['phase']!='Belirsiz' and st['signal']==i:
            diag['structure']+=1
            pl=make_plan(bars[:i+1],tlsp[:i+1],ph,st)
            diag['no_target']+=pl['target'] is None
            diag['no_stop']+=pl['stop'] is None
            diag['dates'].append((b[0],ph['phase'],pl['target'],pl['stop']))
            signals[i]=dict(pl,phase=ph['phase'])
    # Test başlangıcından önce sermaye hareketi yok.
    out=[]
    for group in ('Tümü','TL','Dolar','Pivot'):
        selected={i:p for i,p in signals.items() if group=='Tümü' or p['phase']==group}
        for pb in (False,True):
            for sl in (True,False):
                name=f'{"Geri çekilme" if pb else "Ertesi açılış"} / {"Stoplu" if sl else "Stopsuz"}'
                out.append((name,dict(simulate(bars,selected,sl,pb),diagnostics=diag,phase=group,signals=len(selected))))
    return out
