"""Mobil raporlar, v39 araştırma motorlarının ortak giriş noktası."""
from datetime import date, datetime, timezone
import csv
import io
import re

from report_tr import report_value

import pro_analysis
import audit
import calibration
import evre_backtest
import evre_core as ev
import early_liftoff
import evre_multi_backtest
import launch_study
import opportunity_alerts
import signal_history
import terminal_core as tc
import tr_early_backtest
import variants
import volume_validation
import volume_time
import walkforward
import watch

PAIR_MODES = {"Binance TR geçmiş testi", "Derinlik / Takas"}

MODES = (
    "Fırsat alarmı", "Akıllı kalkış radarı PRO", "PRO strateji testi", "Kalkış takibi", "Sinyal geçmişi",
    "Hacim alarmı başarı testi", "EVRE geçmiş testi", "Çoklu EVRE testi",
    "Kalkış araştırması", "Evre geçmişi", "Veri ve yapı denetimi",
    "Manuel referans karşılaştırma", "Algoritma karşılaştırma",
    "Binance TR geçmiş testi", "Manuel FRVP", "Para akışı", "Derinlik / Takas",
    "Erken kalkış işaretleri", "Zamansal hacim", "Satış emilimi",
    "Erken hacimli kırılım", "Kalkış liste denetimi", "60/30/10 ve 70/40/10 karşılaştırma",
)
WATCH_FIELDS = ("Sembol", "Tarih", "Evre", "Puan", "Durum", "Fiyat", "Hacim oranı")
SIGNAL_FIELDS = ("Sembol", "Tarih", "Evre", "Puan", "Fiyat", "Hedef", "Sonuç", "Sonuç tarihi")


def crypto_bars(data):
    stamps = (datetime.fromtimestamp(t / 1000, timezone.utc).strftime("%Y-%m-%d %H:%M")
              for t in data["time_ms"])
    return list(zip(stamps, *(data[k] for k in ("open", "high", "low", "close", "volume"))))


def csv_bytes(rows):
    fields = list(dict.fromkeys(key for row in rows for key in row))
    out = io.StringIO(newline="")
    writer = csv.DictWriter(out, fields, delimiter=";")
    writer.writeheader()
    writer.writerows(rows)
    return out.getvalue().encode("utf-8-sig")


def run(mode, raw, db, offline=False, reference="", options=None):
    options = options or {}
    bars = []
    raw = raw.strip().upper()
    if mode in ("Kalkış takibi", "Sinyal geçmişi"):
        reader, fields = (watch.rows, WATCH_FIELDS) if mode == "Kalkış takibi" else (signal_history.rows, SIGNAL_FIELDS)
        rows = [dict(zip(fields, row)) for row in reader(db) if not raw or row[0] == raw]
        return rows, bars, "Kayıtlı tarama sonuçları"

    if mode == "Binance TR geçmiş testi":
        if offline:
            raise ValueError("Binance TR testi için canlı bağlantı gerekli.")
        if not re.fullmatch(r"[A-Z0-9]{1,20}_TRY", raw):
            raise ValueError("BTC_TRY gibi bir Binance TR paritesi girin.")
        data = tc.binance_get_market_data(raw, "5m", 1000)
        bars = crypto_bars(data)
        report = tr_early_backtest.analyze_history(data, **options)
        rows = [dict(event, date=bars[event["index"]][0]) for event in report["events"]]
        counts = " · ".join(f"{report_value('status', key)} {n}" for key, n in report["counts"].items())
        return rows, bars, f"Binance TR 5 dk • UTC • {counts or 'Sinyal yok'}"

    if mode == "Derinlik / Takas":
        if tc.is_bist_symbol(raw):
            raise ValueError("BIST derinlik ve takas için aracı kurum veri sağlayıcısı gerekli.")
        if offline or not re.fullmatch(r"[A-Z0-9]{2,20}(?:_TRY)?", raw):
            raise ValueError("Canlı veri ile BTCUSDT veya BTC_TRY gibi bir parite girin.")
        book = tc.binance_get("/fapi/v1/depth", {"symbol": raw, "limit": 50})
        rows = [{"Taraf": side, "Fiyat": float(price), "Adet": float(qty)}
                for key, side in (("bids", "Alış"), ("asks", "Satış"))
                for price, qty, *_ in book[key][:25]]
        source = "Binance TR spot" if raw.endswith("_TRY") else "Binance USDT vadeli"
        return rows, bars, f"{source} • 25 kademe • Takas verisi yok"

    loader = lambda symbol: ev.fetch_backtest_history(symbol, db, offline)
    if mode == "Çoklu EVRE testi":
        symbols = evre_multi_backtest.parse_symbols(raw)
        summary, reports = evre_multi_backtest.compare(
            symbols, loader, lambda series: evre_backtest.evaluate(series, **options))
        return [{k: v for k, v in item.items() if k not in ("rows", "bars")}
                for item in reports], bars, f"{summary['successful_symbols']} başarılı • {summary['failed_symbols']} hata"

    bars, source = loader(raw)
    if mode == "Akıllı kalkış radarı PRO":
        try:
            benchmark, benchmark_source = loader("XU100")
            if "ÖNBELLEK" in benchmark_source and not offline: benchmark = None
        except Exception:
            benchmark = None
        return [dict(Sembol=raw, **pro_analysis.radar(bars, benchmark))], bars, source + " · Deneysel günlük radar"
    if mode == "PRO strateji testi":
        trades, summary = pro_analysis.backtest(bars)
        return trades, bars, source + " · " + str(summary)
    if mode == "Satış emilimi":
        return launch_study.absorption_signals(bars, lookback=len(bars)), bars, source
    if mode == "Erken hacimli kırılım":
        return launch_study.early_volume_candidates(bars), bars, source
    if mode == "Kalkış liste denetimi":
        decisions = launch_study.launch_listing_audit(bars)
        rows = [dict(value, date=bars[index][0]) for index, value in decisions.items()]
        if reference.strip():
            target = date.fromisoformat(reference.strip()).isoformat()
            rows = [row for row in rows if row["date"] == target]
        else:
            rows = [row for row in rows if row["eligible"]]
        return list(reversed(rows)), bars, source
    if mode == "60/30/10 ve 70/40/10 karşılaştırma":
        if not reference.strip():
            raise ValueError("Karşılaştırılacak kalkış tarihini YYYY-AA-GG biçiminde girin.")
        target = date.fromisoformat(reference.strip()).isoformat()
        index = next((i for i, bar in enumerate(bars) if bar[0] == target), None)
        if index is None:
            raise ValueError("Bu tarihte tamamlanmış işlem mumu yok.")
        comparison = launch_study.compare_event(bars, index)
        rows = []
        for preset, result in comparison.items():
            for days, values in result["checkpoints"].items():
                if values is not None:
                    rows.append(dict(Pencere=preset, KalanSeans=days, SinyalTarihi=target,
                                     İlkUyarı=result["first_alert_date"], İlkKalıcıUyarı=result["stable_alert_date"], **values))
        return rows, bars, source
    if mode == "Erken kalkış işaretleri":
        return early_liftoff.early_liftoff_signals(bars), bars, source
    if mode == "Zamansal hacim":
        return [dict(values, date=day) for day, values in volume_time.timeline(bars)], bars, source
    if mode == "EVRE geçmiş testi":
        summary, _, rows = evre_backtest.evaluate(bars, **options)
        return rows, bars, f"{source} • {summary['wins']}/{summary['resolved']} hedef"
    if mode == "Hacim alarmı başarı testi":
        report = volume_validation.validate(bars, **options)
        return report["rows"], bars, f"{source} • {report['success']}/{report['success'] + report['failed']} başarılı"
    if mode == "Kalkış araştırması":
        rows = launch_study.investigate(bars, reference_date=reference.strip() or None, **options)
        return rows, bars, source

    if mode == "Para akışı":
        rows = []
        for previous, current in zip(bars[-21:], bars[-20:]):
            day, _, high, low, close, volume = current
            traded = (high + low + close) / 3 * volume
            incoming = traded if close > previous[4] else 0.0
            outgoing = traded if close < previous[4] else 0.0
            rows.append({"Tarih": day, "Giriş": incoming, "Çıkış": outgoing, "Net": incoming - outgoing})
        return rows[::-1], bars, f"{source} • Tahmini 20 seans net {sum(r['Net'] for r in rows):,.0f} TL"

    if mode == "Manuel FRVP":
        start, separator, end = reference.strip().partition("/")
        if not separator:
            raise ValueError("Başlangıç ve bitiş tarihini / ile ayırın.")
        start, end = (date.fromisoformat(value.strip()).isoformat() for value in (start, end))
        dates = {bar[0] for bar in bars}
        if start not in dates or end not in dates or start > end:
            raise ValueError("Sıralı iki kapanmış işlem günü seçin.")
        selected = [bar for bar in bars if start <= bar[0] <= end]
        val, poc, vah = ev.profile(selected)
        return [{"date": start, "Bitiş": end, "VAL": val, "POC": poc, "VAH": vah,
                 "Mum": len(selected)}], selected, source

    from_cache = offline or source.startswith("ÖNBELLEK")
    fx = ev.fetch("USDTRY", db, offline=from_cache)
    result = ev.analyze(bars, fx)
    if mode == "Fırsat alarmı":
        row = opportunity_alerts.classify_candidate(
            bars, result, minimum=options.get("minimum", 70), offline=from_cache)
        return [alert_row(raw, row)] if row else [], bars, source
    if mode == "Evre geçmişi":
        return walkforward.examine(result, ev.analyze), result["series"], source

    manual = {}
    for pair in reference.split(","):
        if not pair.strip():
            continue
        key, sep, day = pair.strip().partition("=")
        if not sep or key not in ("start", "end", "fake", "real"):
            raise ValueError("Referans örneği: fake=2025-04-14, real=2025-05-02")
        manual[key] = date.fromisoformat(day.strip()).isoformat()
        if manual[key] not in {bar[0] for bar in result["series"]}:
            raise ValueError(f"{manual[key]} için tamamlanmış mum bulunamadı.")
    if mode == "Veri ve yapı denetimi":
        rows = audit.review(raw, result, manual)
    elif mode == "Manuel referans karşılaştırma":
        if not manual:
            raise ValueError("En az bir FRVP veya tepe referansı girin.")
        rows = calibration.compare(raw, result, manual)
    elif mode == "Algoritma karşılaştırma":
        if not {"fake", "real"} & manual.keys():
            raise ValueError("Sahte veya gerçek tepe referansı girin.")
        rows = variants.evaluate({raw: result}, {raw: manual}, ev.profile)
    else:
        raise ValueError("Bilinmeyen araştırma türü.")
    return rows, result["series"], source


def alert_row(symbol, row):
    result = {k: v for k, v in row.items() if k not in ("bars", "windows")}
    result["symbol"] = symbol
    for preset in ("60/30/10", "70/40/10"):
        result[preset] = opportunity_alerts.window_text(row["windows"], preset)
    return result


def scan_alerts(symbols, db, offline, minimum, stop, status):
    rows = []
    errors = 0
    done = 0
    for event in ev.scan_iter(symbols, db, False, stop, workers=3, offline=offline):
        if event[0] == "progress":
            status(event[1])
        elif event[0] in ("result", "error"):
            done += 1
            if event[0] == "result":
                _, symbol, result = event
                bars = result["series"]
                row = opportunity_alerts.classify_candidate(bars, result, minimum, offline=offline)
                if row:
                    rows.append(alert_row(symbol, row))
            else:
                errors += 1
            status(f"{done}/{len(symbols)} • {len(rows)} aday • {errors} hata")
    rows.sort(key=lambda row: (-row["score"], row["symbol"]))
    state = "Durduruldu" if stop.is_set() else "Tamamlandı"
    return rows, [], f"{state} • {done}/{len(symbols)} • {errors} hata"

def run_all(mode, symbols, db, offline, reference, options, stop, status):
    rows = []
    histories = {}
    errors = 0
    done = 0
    for symbol in symbols:
        if stop.is_set():
            break
        status(f"{done}/{len(symbols)} · {symbol} · {len(rows)} kayıt")
        try:
            records, bars, _ = run(mode, symbol, db, offline, reference, options)
        except Exception as exc:
            errors += 1
            rows.append({"symbol": symbol, "state": "HATA", "error": str(exc)})
        else:
            if records and bars:
                histories[symbol] = bars
            rows.extend({"symbol": symbol, **record} for record in records)
            errors += sum(record.get("state") == "HATA" for record in records)
        done += 1
    if mode == "Akıllı kalkış radarı PRO":
        rows.sort(key=lambda r: r.get("Puan", -1), reverse=True)
    return rows, histories, f"{done}/{len(symbols)} hisse · {errors} hata"
