from copy import deepcopy
from drawing_shared import project_drawings, commit_projection
"""V39 analiz motorlarını Flet mobil terminaline bağlar."""
import asyncio
from concurrent.futures import ThreadPoolExecutor, wait, FIRST_COMPLETED
from datetime import datetime
import json
import math
import os
from pathlib import Path
from urllib.parse import urlencode

from chart_workshop import CAMARILLA, Workshop, clamp_view_start, pivots
import queue
import re
import threading
import time

import flet as ft
import flet_charts as charts
from flet_audio import Audio

from version import APP_VERSION
import updater
import data_provider
import dip_core
import evre_core as ev
import market
from report_tr import TIERS, heading, importance, report_value, translated_row
import mobile_research as research
from opportunity import top_candidates
from early_liftoff import early_liftoff_signals
import signal_history
import terminal_core as tc
import watch

BG = "#131722"
PANEL = "#1E222D"
PANEL2 = "#2A2E39"
FG = "#D1D4DC"
MUTED = "#A9B2C4"
ACCENT = "#2962FF"
GREEN = "#089981"
RED = "#F23645"
YELLOW = "#FF9800"
ORANGE = "#FF6B35"
BORDER = "#2A2E39"

SOURCES = {"evre": "EVRE · TL", "bist": "BIST · TL", "tr": "Binance TR · TL",
           "futures": "Binance Vadeli · USDT", "dip": "Dip Radarı · TL", "memory": "Dip Hafıza · TL"}
SETTINGS = {
    "CAPITAL_TL": "Sanal TL sermaye", "BIST_RISK_PERCENT": "BIST risk %",
    "BINANCE_CAPITAL_USDT": "Sanal USDT sermaye", "BINANCE_RISK_PERCENT": "Binance risk %",
    "BINANCE_MAX_LEVERAGE": "Azami kaldıraç",
}
RESEARCH_DEFAULTS = {
    "Fırsat alarmı": "70", "Hacim alarmı başarı testi": "20 10 7",
    "EVRE geçmiş testi": "10 10 7", "Çoklu EVRE testi": "10 10 7",
    "Binance TR geçmiş testi": "24 3 3",
}
EMA_COLORS = {10: "#4DD0E1", 20: ACCENT, 50: "#FFB74D", 100: "#CE93D8", 200: "#FF8080"}
DRAW_TOOLS = {
    "İmleç": ft.Icons.NEAR_ME, "Yatay çizgi": ft.Icons.HORIZONTAL_RULE,
    "Dikey çizgi": ft.Icons.HEIGHT, "Trend çizgisi": ft.Icons.SHOW_CHART,
    "Işın": ft.Icons.ARROW_OUTWARD, "Ölçüm / Ölçek": ft.Icons.STRAIGHTEN,
    "Daire": ft.Icons.CIRCLE_OUTLINED, "Dikdörtgen": ft.Icons.CROP_SQUARE, "Paralel Kanal": ft.Icons.SEGMENT,
    "Fibonacci": ft.Icons.SEGMENT, "Yukarı ok": ft.Icons.ARROW_UPWARD,
    "Aşağı ok": ft.Icons.ARROW_DOWNWARD, "Kalem": ft.Icons.EDIT,
    "Metin": ft.Icons.TITLE, "Sabit hacim (FRVP)": ft.Icons.BAR_CHART,
}
DRAW_GROUPS = {
    "İmleç": ("İmleç",),
    "Trend": ("Yatay çizgi", "Dikey çizgi", "Trend çizgisi", "Işın", "Yatay ışın", "Sonsuz çizgi", "Trend açısı"),
    "Kanal": ("Paralel Kanal", "Regresyon kanalı", "Ayrık kanal", "Yatay sınır kanalı", "Pitchfork", "Schiff Pitchfork", "Modifiye Schiff", "İç Pitchfork"),
    "Şekiller": ("Daire", "Dikdörtgen", "Elips", "Üçgen", "Yay", "Eğri", "Döndürülmüş dikdörtgen", "Çokgen"),
    "Fibonacci": ("Fibonacci", "Fibonacci zaman bölgeleri", "Fibonacci fanı", "Fibonacci uzatma", "Fibonacci kanalı", "Fibonacci daireleri"),
    "Gann": ("Gann kutusu", "Gann fanı"),
    "Formasyon": ("XABCD", "ABCD", "Gartley", "Bat", "Butterfly", "Cypher", "OBO", "TOBO"),
    "Elliott": ("Elliott itki", "Elliott düzeltme", "Elliott üçgen", "Elliott çift kombinasyon", "Elliott üçlü kombinasyon"),
    "Ölçüm": ("Ölçüm / Ölçek", "Fiyat aralığı", "Tarih aralığı"),
    "Pozisyon": ("Long pozisyon", "Short pozisyon"),
    "Hacim": ("Sabit hacim (FRVP)",),
    "Açıklama": ("Yukarı ok", "Aşağı ok", "Kalem", "Metin"),
}
PAGE_SIZE = 40
SIDEBAR_BREAKPOINT = 900
NAV_GROUPS = (
    ("PİYASALAR", (("Sinyaller", ft.Icons.NOTIFICATIONS_OUTLINED),
                  ("BIST", ft.Icons.SHOW_CHART), ("Binance", ft.Icons.CURRENCY_BITCOIN))),
    ("ANALİZ", (("EVRE", ft.Icons.ANALYTICS_OUTLINED), ("EVRE Alarm", ft.Icons.NOTIFICATIONS_ACTIVE_OUTLINED),
               ("Dip Alarm", ft.Icons.RADAR), ("Dip Hafıza", ft.Icons.HISTORY),
               ("Analiz", ft.Icons.QUERY_STATS), ("Grafik", ft.Icons.CANDLESTICK_CHART))),
    ("PORTFÖY", (("Favoriler", ft.Icons.STAR_OUTLINE),
                ("İşlemler", ft.Icons.ACCOUNT_BALANCE_WALLET_OUTLINED), ("Ayarlar", ft.Icons.SETTINGS_OUTLINED))),
    ("SİSTEM", (("Güncelleme", ft.Icons.SYSTEM_UPDATE_ALT),)),
)


def button(label, action, color=ACCENT):
    return ft.FilledButton(
        content=label, bgcolor=color, color=BG, on_click=action,
        style=ft.ButtonStyle(padding=ft.Padding.symmetric(horizontal=10, vertical=6)),
    )


CHART_YELLOW = "#FFD600"
RUN_ORANGE = "#FF8A00"
SELECTED_ROW = "#3F5F9F"
SCOPE_STYLE = {"Tek hisse": ("Tek", RED), "Tüm hisseler": ("Tüm", GREEN), "Kod listesi": ("Liste", ACCENT)}


def sort_value(value):
    """Sayısal değerler sayı gibi, metinler alfabetik sıralanır."""
    text = str(value).strip()
    match = re.fullmatch(r"%?\s*([+-]?\d+(?:[.,]\d+)?)\s*%?", text)
    if match:
        return 0, float(match.group(1).replace(",", ".")), ""
    return 1, 0.0, text.lower()


FIELD_WIDTH = 180
FIELD_HEIGHT = 40


def style_field(control):
    """Açılır menü ve metin kutularına aynı en, boy ve iç boşluğu verir."""
    control.width = FIELD_WIDTH
    control.height = FIELD_HEIGHT
    control.dense = True
    control.text_size = 13
    # Açılır menü ok düğmesi nedeniyle ~40 px yüksekliğe iner; metin kutusu iç boşlukla aynı boya getirilir.
    control.content_padding = ft.Padding.symmetric(horizontal=10, vertical=8 if isinstance(control, ft.Dropdown) else 14)
    return control


def select(label, values, value, **kwargs):
    kwargs.pop("width", None)
    return style_field(ft.Dropdown(label=label, value=value,
                                   options=[ft.DropdownOption(key=v) for v in values], **kwargs))


def panel(controls):
    return ft.Container(
        content=ft.Column(controls, spacing=5), padding=8, bgcolor=PANEL,
        border=ft.Border.all(1, BORDER), border_radius=10,
    )


def form_grid(controls):
    items = []
    for control in controls:
        if isinstance(control, (ft.Dropdown, ft.TextField)):
            style_field(control)
        items.append(ft.Container(content=control, width=FIELD_WIDTH))
    return ft.Row(items, wrap=True, spacing=6, run_spacing=6,
                  vertical_alignment=ft.CrossAxisAlignment.CENTER)


def label(value, color=MUTED):
    return ft.Text(str(value), size=12, color=color, selectable=True)


def change_text(value):
    return (f"{value:+.2f}%" if value is not None else "—",
            GREEN if value is not None and value > 0 else RED if value is not None and value < 0 else MUTED)


def save_state(path, data):
    pending = path.with_suffix(".tmp")
    pending.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    pending.replace(path)


def report_options(mode, text):
    if mode not in RESEARCH_DEFAULTS:
        return {}
    if mode == "Fırsat alarmı":
        minimum = int(text)
        if not 0 <= minimum <= 100:
            raise ValueError("Asgari puan 0–100 olmalı.")
        return {"minimum": minimum}
    horizon, target, loss = text.replace(",", ".").split()
    horizon, target, loss = int(horizon), float(target), float(loss)
    if not (1 <= horizon <= 240 and 0 < target < math.inf and 0 < loss < math.inf):
        raise ValueError("Mum sayısı 1–240, hedef ve stop pozitif olmalı.")
    if mode == "Binance TR geçmiş testi":
        return dict(horizon=horizon, target_pct=target, stop_pct=loss)
    return dict(horizon=horizon, gain_pct=target, loss_pct=loss)


class PiyasaMobile:
    def __init__(self, page):
        self.page = page
        self.app_title = f"Piyasa Terminali v{APP_VERSION} · V39"
        self.page.title = self.app_title
        self.page.theme_mode = ft.ThemeMode.DARK
        self.page.bgcolor = BG
        self.page.padding = 0
        self.page.spacing = 0
        folder = os.environ.get("FLET_APP_STORAGE_DATA") or Path.home() / ".piyasa-terminali-flet"
        tc.set_data_dir(str(folder))
        self.data_folder = Path(folder)
        self.update_config_file = self.data_folder / "guncelleme.json"
        self.update_url = ft.TextField(
            label="Güncelleme adresi (manifest.json veya github:kullanici/depo)", dense=True, text_size=13,
            value=str(tc.load_json(self.update_config_file, {}).get("manifest_url") or "github:asistan71/PiyasaTerminal-Windows"), expand=True,
            on_blur=self.save_update_url, on_submit=self.save_update_url)
        self.update_zip = ft.TextField(label="ZIP dosyasının yolu", dense=True, text_size=13, expand=True)
        self.update_progress = ft.ProgressBar(value=0)
        self.update_info = None
        self.update_local = []
        self.update_busy = False
        self.update_note = ""
        self.db = str(Path(folder) / "evre_veri.sqlite3")
        self.archive = str(Path(folder) / "dip_arsiv.sqlite3")
        self.trades = tc.load_trades()
        self.favorites = tc.load_favorites()
        for name, value in tc.load_json(tc.SETTINGS_FILE, {}).items():
            if name in SETTINGS and isinstance(value, (int, float)) and 0 < value < math.inf:
                setattr(tc, name, value)
        self.results = {source: {} for source in SOURCES}
        self.jobs = {}
        self.stopped_report = None
        self.messages = queue.Queue()
        self.updated_at = "—"
        self.section = "Sinyaller"
        self.offset = 0
        self.chart_request = 0
        self.report = []
        self.report_bars = []
        self.prices = {}
        self.body_height = None
        self.chart_viewport = None
        self.picker = ft.FilePicker()
        self.audio = Audio(src="kalkis.wav")
        self.heard_alerts = set()
        self.market_summary = {"evre": label("BIST100 · —"), "futures": label("BTC · —")}
        self.notice = label("")
        self.body = self.make_body()
        self.scroll_pixels = 0
        self.progress_known = set()
        self.report_resume = None
        self.report_sort = None
        self.selected_row = None
        self.previous_section = None
        self.clock = ft.Text(datetime.now().strftime("%H:%M"), size=13, color=MUTED)
        self.section_title = ft.Text(self.section, size=18, weight=ft.FontWeight.BOLD, color=FG)
        self.chart_header = ft.Row(expand=True, scroll=ft.ScrollMode.AUTO, spacing=8, visible=False)
        self.header = ft.Container(
            content=ft.Row([
                ft.Icon(ft.Icons.CANDLESTICK_CHART, size=22, color="#79A4FF"),
                ft.Column([
                    ft.Text(f"Piyasa Terminali · V39 · v{APP_VERSION}", size=12, color=MUTED),
                    self.section_title,
                ], spacing=1, expand=True),
                self.chart_header, self.clock,
            ]),
            padding=ft.Padding.only(left=16, right=16, top=12, bottom=12),
            bgcolor=PANEL, border=ft.Border.only(bottom=ft.BorderSide(1, BORDER)),
        )
        self.tabs = ("Sinyaller", "BIST", "Binance", "Favoriler", "EVRE",
                     "EVRE Alarm", "Dip Alarm", "Dip Hafıza", "İşlemler", "Grafik")
        self.nav = ft.NavigationBar(
            bgcolor=PANEL, selected_index=0, on_change=self.navigate, width=790,
            destinations=[
                ft.NavigationBarDestination(icon=ft.Icons.NOTIFICATIONS_OUTLINED, selected_icon=ft.Icons.NOTIFICATIONS, label="Sinyaller"),
                ft.NavigationBarDestination(icon=ft.Icons.SHOW_CHART, selected_icon=ft.Icons.SHOW_CHART, label="BIST"),
                ft.NavigationBarDestination(icon=ft.Icons.CURRENCY_BITCOIN, selected_icon=ft.Icons.CURRENCY_BITCOIN, label="Binance"),
                ft.NavigationBarDestination(icon=ft.Icons.STAR_OUTLINE, selected_icon=ft.Icons.STAR, label="Favoriler"),
                ft.NavigationBarDestination(icon=ft.Icons.ANALYTICS_OUTLINED, selected_icon=ft.Icons.ANALYTICS, label="EVRE"),
                ft.NavigationBarDestination(icon=ft.Icons.NOTIFICATIONS_ACTIVE_OUTLINED, selected_icon=ft.Icons.NOTIFICATIONS_ACTIVE, label="EVRE Alarm"),
                ft.NavigationBarDestination(icon=ft.Icons.RADAR, selected_icon=ft.Icons.RADAR, label="Dip Alarm"),
                ft.NavigationBarDestination(icon=ft.Icons.HISTORY, selected_icon=ft.Icons.HISTORY, label="Dip Hafıza"),
                ft.NavigationBarDestination(icon=ft.Icons.ACCOUNT_BALANCE_WALLET_OUTLINED, selected_icon=ft.Icons.ACCOUNT_BALANCE_WALLET, label="İşlemler"),
                ft.NavigationBarDestination(icon=ft.Icons.CANDLESTICK_CHART, selected_icon=ft.Icons.CANDLESTICK_CHART, label="Grafik"),
            ],
        )
        self.stock_group = select("Pazar", ["Tümü", *market.BIST_MARKETS], "Tümü")
        self.evre_scope = "Tek hisse"
        self.evre_column_sort = None
        self.table_selection = {}
        self.market_sort = {}
        self.single_market = {}
        self.pair_code = style_field(ft.TextField(label="Parite"))
        self.stock_code = style_field(ft.TextField(label="Tek hisse", hint_text="THYAO"))
        self.offline = ft.Switch(label="Kayıtlı veri")
        self.live_scan = {key: False for key in ("bist", "evre", "tr", "futures")}
        self.bist_filters_enabled = True
        self.tfs = [
            ft.Checkbox(label=tf, value=True, width=54, height=32, scale=0.8,
                        visual_density=ft.VisualDensity.COMPACT, label_style=ft.TextStyle(size=12),
                        tooltip=description)
            for tf, description in (("1W", "Haftalık"), ("1D", "Günlük"), ("1H", "Saatlik"))
        ]
        self.min_score = select("Asgari puan", ["0", "50", "60", "70", "80"], "0", on_select=self.redraw)
        self.evre_phase = select("Evre", ["Tümü", "TL", "Dolar", "Pivot", "Belirsiz"], "Tümü", on_select=self.redraw)
        self.evre_top = ft.Switch(label="Erken fırsatlar · İlk 10", on_change=self.redraw)
        self.evre_sort = select("Sıralama", ["Puan", "Erken puan", "Potansiyel %"], "Puan", on_select=self.evre_sort_changed)
        self.crypto_mode = "Binance Vadeli"
        intervals = ["60", "90", "120", "180", "300"]
        signals = ["Tümü", "TEYITLI LONG", "ERKEN LONG", "IZLE"]
        stages = ["Tümü", "Erken Hacimli Uyanış", "Dipten Toparlanma", "Kalkış Hazırlığı", "Yok"]
        self.tr_interval = select("TR yenileme süresi", intervals, "120")
        self.bist_interval = select("BİST yenileme (sn)", intervals, str(tc.BIST_LIVE_INTERVAL))
        self.tr_signal = select("Sinyal", signals, "Tümü", on_select=self.redraw)
        self.bist_signal = select("Sinyal", signals, "Tümü", on_select=self.redraw)
        self.tr_stage = select("Hazırlık", stages, "Tümü", on_select=self.redraw)
        self.bist_stage = select("Hazırlık", stages, "Tümü", on_select=self.redraw)
        self.research_mode = select("Rapor", research.MODES, research.MODES[0], width=290, on_select=self.mode_changed)
        self.research_scope = "Tek hisse"
        self.research_code = ft.TextField(label="Hisse, parite veya kod listesi")
        self.reference = ft.TextField(label="Referans / tarih aralığı", hint_text="YYYY-AA-GG")
        self.params = ft.TextField(label="Puan / mum / hedef / stop %", value="70")
        self.research_offline = ft.Switch(label="Kayıtlı veri")
        self.sound = ft.Switch(label="Kalkış alarmı sesi")
        self.settings = {k: ft.TextField(label=v, value=str(getattr(tc, k))) for k, v in SETTINGS.items()}
        self.state = {key: label("Hazır") for key in (*SOURCES, "analiz")}
        self.progress = {key: ft.ProgressBar(value=0, color=ACCENT) for key in self.state}
        self.chart_row = None
        self.chart_is_report = False
        self.chart_span = 70
        self.draw_mode = False
        self.user_marks = {}
        self.workshop_enabled = True
        self.workshop_large = False
        self.chart_focus = False
        self.price_ranges = {}
        self.show_trade_plan = True
        self.fit_chart_levels = False
        self.workshop_tool = "İmleç"
        self.pivot_period = "Kapalı"
        self.workshop_file = Path(folder) / "grafik_cizimleri.json"
        self.workshop_drawings = tc.load_json(self.workshop_file, {})
        self.drawing_snapshot = deepcopy(self.workshop_drawings)
        self.drawing_undo, self.drawing_redo = {}, {}
        self.favorite_tools_file = Path(folder) / "favori_cizimler.json"
        self.favorite_tools = tc.load_json(self.favorite_tools_file, ["Trend çizgisi", "Dikdörtgen", "Fibonacci"])
        self.drawing_alert_seen = {}
        self.drawing_style_file = Path(folder) / "cizim_stil_sablonu.json"
        self.drawing_style_template = tc.load_json(self.drawing_style_file, {})
        if not isinstance(self.drawing_style_template, dict):
            self.drawing_style_template = {}
        if "templates" not in self.drawing_style_template:
            self.drawing_style_template = {"templates": {"Varsayılan": self.drawing_style_template} if self.drawing_style_template else {}}
        self.alarm_history_file = Path(folder) / "cizim_alarm_gecmisi.json"
        self.alarm_history = tc.load_json(self.alarm_history_file, [])
        if not isinstance(self.alarm_history, list):
            self.alarm_history = []
        self.ema_periods = set()
        self.indicators = { "VWAP": False, "VWAP bantları": False,
                           "Akümülasyon": False, "Görünür hacim": False}
        self.chart_shift = 0
        self.sidebar_content = ft.ListView(controls=self.sidebar_groups(), spacing=4, padding=10, expand=True)
        self.sidebar = ft.Container(
            content=self.sidebar_content, bgcolor=PANEL, width=192,
            border=ft.Border.only(right=ft.BorderSide(1, BORDER)),
        )
        self.compact_navigation = ft.Row([self.nav], scroll=ft.ScrollMode.AUTO, spacing=0)
        self.configure_layout(getattr(page, "width", None))
        self.page.on_resize = self.resize_layout
        self.page.on_keyboard_event = self.on_keyboard
        self.render_sidebar()
        self.render()
        self.page.add(ft.SafeArea(
            content=ft.Column([
                self.header, ft.Row([self.sidebar, self.body], spacing=0,
                                    vertical_alignment=ft.CrossAxisAlignment.STRETCH, expand=True),
                self.compact_navigation,
            ], spacing=0, expand=True),
            expand=True,
        ))
        self.page.run_task(self.poll)
        self.page.run_task(self.poll_drawing_alerts)
        self.start_update_check(quiet=True)
        self.scan_local_updates()

    def configure_layout(self, width):
        desktop = not isinstance(width, (float, int)) or width >= SIDEBAR_BREAKPOINT
        self.desktop_layout = desktop
        self.apply_chart_focus()

    def apply_chart_focus(self):
        focus = self.chart_focus and self.section == "Grafik"
        desktop = getattr(self, "desktop_layout", True)
        self.header.visible = self.section != "Grafik"
        self.sidebar.visible = desktop and not focus
        self.compact_navigation.visible = not desktop and not focus
        self.body.padding = 2 if self.section == "Grafik" else 8

    def chart_height(self):
        available = self.body_height or getattr(self.page, "height", None)
        if not isinstance(available, (float, int)):
            available = 600
        # ListView pads the chart page by two logical pixels on each edge.
        return max(360, available - 4) + (160 if self.workshop_large and not self.chart_focus else 0)

    def body_resized(self, event):
        if event.height <= 0 or event.height == self.body_height:
            return
        self.body_height = event.height
        if self.chart_viewport is not None:
            self.chart_viewport.height = self.chart_height()
            self.chart_viewport.update()

    def resize_layout(self, event):
        self.configure_layout(event.width)
        if self.section == "Grafik" and self.chart_row:
            self.render()
        self.page.update()

    def sidebar_groups(self):
        groups = []
        for title, entries in NAV_GROUPS:
            links = []
            for name, icon in entries:
                links.append(ft.Container(
                    content=ft.Row([ft.Icon(icon, size=18), ft.Text(name, size=13, color=FG)],
                                   spacing=10),
                    padding=8, border_radius=8, on_click=lambda _, section=name: self.show(section),
                ))
            groups.append(ft.ExpansionTile(
                title=ft.Text(title, size=12, weight=ft.FontWeight.BOLD, color=FG),
                controls=links, dense=True, min_tile_height=38,
                tile_padding=ft.Padding.symmetric(horizontal=8),
                controls_padding=ft.Padding.only(left=8, bottom=4),
                expanded_cross_axis_alignment=ft.CrossAxisAlignment.STRETCH,
                icon_color=ACCENT, collapsed_icon_color=MUTED,
            ))
        return groups

    def render_sidebar(self):
        for group in self.sidebar_content.controls:
            for link in group.controls:
                icon, title = link.content.controls
                active = title.value == self.section
                link.bgcolor = "#304671" if active else None
                title.weight = ft.FontWeight.BOLD if active else ft.FontWeight.NORMAL
                icon.color = "#A7C2FF" if active else MUTED

    def navigate(self, event):
        self.show(self.tabs[event.control.selected_index])

    def make_body(self):
        """Kaydırma izleme Flet sürümüne göre farklı parametre adları ister; olmazsa izleme olmadan açılır."""
        base = dict(expand=True, padding=8, spacing=6, on_size_change=self.body_resized)
        for extra in ({"on_scroll": self.track_scroll, "scroll_interval": 150},
                      {"on_scroll": self.track_scroll}, {}):
            try:
                return ft.ListView(**base, **extra)
            except TypeError:
                continue

    def track_scroll(self, event):
        pixels = getattr(event, "pixels", None)
        if isinstance(pixels, (int, float)):
            self.scroll_pixels = pixels

    async def restore_scroll(self, pixels):
        await asyncio.sleep(0.25)
        try:
            result = self.body.scroll_to(offset=pixels, duration=0)
            if hasattr(result, "__await__"):
                await result
        except Exception:
            pass

    def show(self, section):
        if section == "Grafik" and self.chart_row is None:
            self.open_chart({"Sembol": "THYAO", "source": "bist", "direct_chart": True})
            return
        resume = self.report_resume if (section == "Analiz" and self.section == "Grafik") else None
        self.page.title = f"Grafik · {self.app_title}" if section == "Grafik" else self.app_title
        self.section = section
        self.section_title.value = section
        self.offset = resume["offset"] if resume else 0
        self.notice.value = ""
        if section in self.tabs:
            self.nav.selected_index = self.tabs.index(section)
        self.render_sidebar()
        self.redraw()
        if resume and resume["scroll"] > 1:
            self.page.run_task(self.restore_scroll, resume["scroll"])

    def redraw(self, event=None):
        if event is not None:
            self.offset = 0
        self.apply_chart_focus()
        self.render()
        self.page.update()

    def render(self):
        name = self.section
        self.active_workshop = None
        self.chart_search_focused = False
        self.chart_header.visible = False
        self.header.content.controls[1].expand = not self.chart_header.visible
        controls = {
            "Sinyaller": self.signals, "BIST": self.stocks, "Binance": self.crypto,
            "Favoriler": self.favorite_view, "İşlemler": self.trade_view, "Grafik": self.graph_view,
            "Analiz": self.research_view, "Ayarlar": self.settings_view,
            "EVRE": self.stocks, "Dip Alarm": self.stocks, "Dip Hafıza": self.stocks,
            "EVRE Alarm": self.alarm_view, "Güncelleme": self.update_view,
        }[name]()
        controls = [self.notice, *controls] if self.notice.value else controls
        self.chart_viewport = None
        if name == "Grafik":
            for i, control in enumerate(controls):
                if control.data == "chart-panel":
                    self.chart_viewport = ft.Column(controls[:i + 1], spacing=6, height=self.chart_height(), horizontal_alignment=ft.CrossAxisAlignment.STRETCH)
                    controls = [self.chart_viewport, *controls[i + 1:]]
                    break
        self.body.controls = controls

    def cards(self, rows, builder):
        rows = list(rows)
        if not rows:
            return [label("Kayıt yok.")]
        last = (len(rows) - 1) // PAGE_SIZE
        self.offset = min(self.offset, last)
        start = self.offset * PAGE_SIZE
        cards = [builder(row) for row in rows[start:start + PAGE_SIZE]]
        for card in cards:
            card.col = {"xs": 12, "md": 6, "xl": 4}
        controls = [ft.ResponsiveRow(cards, spacing=6, run_spacing=6,
                                     vertical_alignment=ft.CrossAxisAlignment.START)]
        return controls + self.page_buttons(last)

    def page_buttons(self, last):
        if not last:
            return []
        return [ft.Row([
            button("Önceki", lambda _: self.move(-1)),
            label(f"{self.offset + 1}/{last + 1}"),
            button("Sonraki", lambda _: self.move(1)),
        ], wrap=True)]

    def move(self, step):
        self.offset = max(0, self.offset + step)
        self.redraw()

    def signals(self):
        rows = [row for group in self.results.values() for row in group.values()
                if row.get("Sinyal") not in (None, "IZLE", "YOK")]
        rows.sort(key=lambda row: row.get("Puan", 0), reverse=True)
        return [
            panel([label("Sinyal özeti", FG), form_grid([
                self.metric("Sinyal", len(rows)),
                self.metric("Teyitli sinyal", sum("TEYITLI" in r["Sinyal"] for r in rows)),
                self.metric("Son tarama", self.updated_at),
            ]),
            ft.Row([button("Analiz", lambda _: self.show("Analiz")),
                    button("Ayarlar", lambda _: self.show("Ayarlar"))], wrap=True)]),
            self.result_heading("Sinyaller", len(rows)),
            *self.market_table(rows, "signals"),
        ]

    def metric(self, title, value):
        return panel([label(title), ft.Text(str(value), size=21, weight=ft.FontWeight.BOLD, color=FG)])

    def result_heading(self, title, count):
        return ft.Row([
            ft.Text(title, size=15, weight=ft.FontWeight.BOLD, color=FG, expand=True),
            label(f"{count} kayıt"),
        ])

    def _evre_badge(self, r):
        evre = r.get("Evre", "")
        color = YELLOW
        if "DİP" in evre: color = ORANGE
        elif "KALKIŞ" in evre or "ERKEN" in evre: color = GREEN
        elif "TEPE" in evre: color = RED
        return ft.Container(
            content=ft.Text(evre, size=10, color="white", weight=ft.FontWeight.BOLD),
            bgcolor=color,
            padding=ft.Padding.only(left=6, right=6, top=2, bottom=2),
            border_radius=4,
        ) if evre else ft.Container()

    def _vol_badge(self, r):
        profile = r.get("VolProfile", "")
        score = r.get("VolScore", 0)
        if not profile: return ft.Container()
        color = GREEN if score >= 60 else YELLOW if score >= 40 else MUTED
        return ft.Container(
            content=ft.Text(f"{profile} ({score})", size=10, color="white"),
            bgcolor=color,
            padding=ft.Padding.only(left=6, right=6, top=2, bottom=2),
            border_radius=4,
        )

    
    def _rsi_badge(self, r):
        rsi = r.get("RSI", 0)
        if not rsi: return ft.Container()
        if rsi >= 70:
            color, label = RED, f"RSI {rsi:.0f} AŞIRI"
        elif rsi <= 30:
            color, label = GREEN, f"RSI {rsi:.0f} AŞIRI SAT"
        elif 50 <= rsi < 70:
            color, label = ACCENT, f"RSI {rsi:.0f}"
        else:
            color, label = MUTED, f"RSI {rsi:.0f}"
        return ft.Container(
            content=ft.Text(label, size=10, color="white"),
            bgcolor=color,
            padding=ft.Padding.only(left=6, right=6, top=2, bottom=2),
            border_radius=4,
        )

    def _obv_badge(self, r):
        trend = r.get("OBVTrend", "")
        div = r.get("OBVDiv", False)
        if not trend: return ft.Container()
        color = GREEN if trend == "YUKARI" else RED if trend == "ASAGI" else MUTED
        text = f"OBV {trend}"
        if div: text += " DIV"
        return ft.Container(
            content=ft.Text(text, size=10, color="white"),
            bgcolor=color if not div else ORANGE,
            padding=ft.Padding.only(left=6, right=6, top=2, bottom=2),
            border_radius=4,
        )

    def card(self, row):
        source, symbol = row["source"], row["Sembol"]
        change, color = change_text(row.get("Degisim", row.get("Degisim24h")))
        currency = "USDT" if source == "futures" else "₺"
        favored = any(f["Sembol"] == symbol for f in self.favorites)
        items = [
            ft.Row([
                ft.Column([ft.Text(symbol, color=FG, size=15, weight=ft.FontWeight.BOLD),
                           label(SOURCES[source])], expand=True, spacing=1),
                ft.IconButton(icon=ft.Icons.STAR if favored else ft.Icons.STAR_OUTLINE,
                              icon_size=18, padding=5, width=36, height=36,
                              icon_color=YELLOW if favored else MUTED, tooltip="Favori",
                              on_click=lambda _: self.toggle_favorite(symbol)),
                ft.IconButton(icon=ft.Icons.SHOW_CHART, icon_color=CHART_YELLOW, tooltip="Grafik",
                              icon_size=18, padding=5, width=36, height=36,
                              on_click=lambda _: self.open_chart(row)),
            ], spacing=0),
            ft.Row([label(f"{row['Fiyat']} {currency}") if row.get("Fiyat") is not None else label("Fiyat —"),
                    label(change, color), label(f"{row.get('OlaySayısı')} olay" if source == "memory" else f"{row.get('Puan', '—')}/100", ACCENT),
                    label(row.get("Sinyal") or "İzle", RED if row.get("Yon") == "SHORT" else GREEN)], wrap=True),
        ]
        context = [row.get(field) for field in ("Evre", "Durum", "Hazirlik", "HazirlikNotu", "BTC_Uyum", "Tarih")]
        context_text = " · ".join(str(x) for x in context if x)
        if context_text:
            items.append(label(context_text, YELLOW))
        badges = []
        for key, render_badge in (("Evre", self._evre_badge), ("VolProfile", self._vol_badge),
                                  ("RSI", self._rsi_badge), ("OBVTrend", self._obv_badge)):
            if row.get(key):
                badges.append(render_badge(row))
        if badges:
            items.append(ft.Row(badges, wrap=True, spacing=5))
        return ft.Container(content=ft.Column(items, spacing=3), padding=8, bgcolor=PANEL, border_radius=8)

    def dip_panel(self, key, fields):
        """Dip Alarm ve Dip Hafıza: kutular, düğmeler ve durum çubuğu tek panelde."""
        running = key in self.jobs
        return panel([
            label("Tarama ayarları", FG),
            ft.Row([
                *fields,
                button("Durdur" if running else "Tara", self.scan_action(key, self.start_stock), RED if running else GREEN),
                button("CSV kaydet", lambda _: self.export(self.results[key].values())),
                *([button("Dip arşivi", self.show_archive, RUN_ORANGE)] if key == "memory" else []),
            ], wrap=True, spacing=6, vertical_alignment=ft.CrossAxisAlignment.CENTER),
            self.status_bar(key, running),
            self.state[key],
        ])

    def stock_mode(self):
        return {"EVRE": "EVRE", "BIST": "Hisse", "Dip Alarm": "Dip Radarı", "Dip Hafıza": "Dip Hafızası"}[self.section]

    def evre_sort_changed(self, event):
        self.evre_column_sort = None
        self.redraw(event)

    def toggle_evre_scope(self, _):
        self.evre_scope = "Tek hisse" if self.evre_scope == "Tüm hisseler" else "Tüm hisseler"
        self.redraw()

    def evre_table(self, rows):
        if not rows:
            return [label("Kayıt yok.")]
        fields = (("Sembol", "Hisse"), ("Evre", "Evre"), ("Sinyal", "Sinyal"), ("Puan", "Puan"),
                  ("ErkenPuan", "Erken puan"), ("Potansiyel", "Potansiyel %"), ("Fiyat", "Fiyat ₺"),
                  ("Tarih", "Tarih"), ("Giris", "Giriş"), ("Stop", "Stop"), ("TP2", "Hedef"),
                  ("VAL", "VAL"), ("POC", "POC"), ("VAH", "VAH"))
        return self.result_table(rows, fields, "evre")

    def market_scope_button(self, key):
        def toggle(_):
            self.single_market[key] = not self.single_market.get(key, False)
            self.offset = 0
            self.redraw()
        single = self.single_market.get(key, False)
        return button("Tek" if single else "Tüm", toggle, RED if single else GREEN)

    def market_table(self, rows, key):
        fields = [("Sembol", "Sembol"), ("source", "Piyasa"), ("Sinyal", "Sinyal"), ("Puan", "Puan"),
                  ("Fiyat", "Fiyat"), ("Degisim", "Değişim %"), ("Degisim24h", "24 saat %"),
                  ("Yon", "Yön"), ("Hazirlik", "Hazırlık"), ("Evre", "Evre"), ("RSI", "RSI"),
                  ("Giris", "Giriş"), ("Stop", "Stop"), ("TP1", "TP1"), ("TP2", "TP2"), ("TP3", "TP3"),
                  ("Tarih", "Tarih")]
        keys = {field for row in rows for field in row}
        return self.result_table(rows, [(field, title) for field, title in fields if field in keys], key)

    def result_table(self, rows, fields, table_key):
        if not rows:
            return [label("Kayıt yok.")]
        def sort_by(event, key):
            if table_key == "evre":
                self.evre_column_sort = (key, event.ascending)
            else:
                self.market_sort[table_key] = (key, event.ascending)
            self.offset = 0
            self.redraw()

        def choose(symbol):
            self.table_selection[table_key] = symbol
            self.redraw()

        sort_index = None
        ascending = True
        order = self.evre_column_sort if table_key == "evre" else self.market_sort.get(table_key)
        if order and order[0] in dict(fields):
            key, ascending = order
            sort_index = 1 + [field for field, _ in fields].index(key)
            available = [r for r in rows if r.get(key) is not None]
            rows = sorted(available, key=lambda r: sort_value(r[key]), reverse=not ascending) + [
                r for r in rows if r.get(key) is None]
        last = (len(rows) - 1) // PAGE_SIZE
        self.offset = min(last, self.offset)
        favorites = {f["Sembol"] for f in self.favorites}
        data = []
        for row in rows[self.offset * PAGE_SIZE:(self.offset + 1) * PAGE_SIZE]:
            symbol = row["Sembol"]
            actions = [
                ft.IconButton(icon=ft.Icons.MENU, tooltip="Ayrıntılar", icon_size=18,
                    on_click=lambda _, r=row: self.report_details({k: v for k, v in r.items() if k not in ("detail", "source")})),
                ft.IconButton(icon=ft.Icons.SHOW_CHART, tooltip="Grafik", icon_color=CHART_YELLOW,
                              icon_size=18, on_click=lambda _, r=row: self.open_chart(r)),
                ft.IconButton(icon=ft.Icons.STAR if symbol in favorites else ft.Icons.STAR_OUTLINE,
                              tooltip="Favori", icon_size=18, on_click=lambda _, sym=symbol: self.toggle_favorite(sym))]
            cells = [ft.DataCell(ft.Row(actions, spacing=0))]
            for field, _ in fields:
                value = row.get(field)
                color = FG
                if field == "source":
                    value = SOURCES.get(value, value)
                elif field in ("Degisim", "Degisim24h"):
                    value, color = change_text(value)
                cells.append(ft.DataCell(label("—" if value is None else value, color),
                                         on_tap=lambda _, sym=(row["source"], symbol): choose(sym)))
            data.append(ft.DataRow(cells=cells, color=SELECTED_ROW if (row["source"], symbol) == self.table_selection.get(table_key) else None))
        columns = [ft.DataColumn(label("İşlemler", FG))] + [
            ft.DataColumn(label(title, FG), on_sort=lambda e, key=field: sort_by(e, key)) for field, title in fields]
        table = ft.DataTable(columns=columns, rows=data, sort_column_index=sort_index, sort_ascending=ascending,
                             heading_row_height=36, data_row_min_height=40, data_row_max_height=40,
                             horizontal_margin=8, column_spacing=16)
        return [ft.Row([table], scroll=ft.ScrollMode.ALWAYS), *self.page_buttons(last)]

    def stocks(self):
        mode = self.stock_mode()
        key = "evre" if mode == "EVRE" else "bist" if mode == "Hisse" else "dip" if mode == "Dip Radarı" else "memory"
        rows = self.results[key].values()
        if key == "evre":
            sort_key = {"Erken puan": "ErkenPuan", "Potansiyel %": "Potansiyel"}.get(self.evre_sort.value, "Puan")
            rows = [r for r in rows if r["Puan"] >= int(self.min_score.value)
                    and self.evre_phase.value in ("Tümü", r["Evre"])]
            if self.evre_top.value:
                eligible = dict(top_candidates({r["Sembol"]: r["detail"] for r in rows}))
                rows = [r for r in rows if r["Sembol"] in eligible]
                sort_key = "ErkenPuan"
        else:
            sort_key = "Puan"
        rows = sorted(rows, key=lambda row: row.get(sort_key) or 0, reverse=True)
        if key == "evre":
            running = key in self.jobs
            caption, color = SCOPE_STYLE[self.evre_scope]
            return [panel([
                label("EVRE tarama ayarları", FG),
                form_grid([self.stock_code if self.evre_scope == "Tek hisse" else self.stock_group,
                           self.min_score, self.evre_sort, self.evre_phase]),
                ft.Row([button(caption, self.toggle_evre_scope, color),
                        button("Durdur" if running else "Çalıştır", self.scan_action(key, self.start_stock), RED if running else RUN_ORANGE),
                        button("CSV kaydet", lambda _: self.export(rows)), self.offline, self.live_scan_button(key),
                        self.evre_top], wrap=True, spacing=12),
                self.status_bar(key, running), self.state[key], self.market_summary[key],
            ]), self.result_heading("EVRE sonuçları", len(rows)), *self.evre_table(rows)]
        if key in ("dip", "memory"):
            return [
                self.dip_panel(key, [self.stock_group, self.stock_code]),
                self.result_heading("Tarama sonuçları", len(rows)),
                *self.cards(rows, self.card),
            ]
        rows = [r for r in rows if self.bist_signal.value in ("Tümü", r.get("Sinyal"))
                and self.bist_stage.value in ("Tümü", r.get("Hazirlik") or "Yok")]
        options = [self.stock_code if self.single_market.get(key) else self.stock_group]
        return self.market_view(key, rows, options, [self.bist_filter_button(), self.live_scan_button(key)], self.start_stock)

    def market_view(self, key, rows, options, switches, start):
        running = key in self.jobs
        actions = ft.Row([
            self.market_scope_button(key),
            button("Durdur" if running else "Çalıştır", start, RED if running else RUN_ORANGE),
            *switches, button("CSV kaydet", lambda _: self.export(rows)),
        ], scroll=ft.ScrollMode.AUTO, spacing=12)
        if key == "bist":
            self.bist_interval.disabled = running or bool(self.single_market.get(key))
            settings = [actions, ft.Row([*options, *self.tfs], spacing=1, rtl=False,
                                        wrap=False, scroll=ft.ScrollMode.AUTO),
                        form_grid([self.bist_interval, self.bist_signal, self.bist_stage])]
        else:
            settings = [label("Tarama ayarları", FG), form_grid(options), actions]
        return [panel([
            *settings,
            self.status_bar(key, running), self.state[key],
            *([self.market_summary[key]] if key in self.market_summary else []),
        ]), self.result_heading("Tarama sonuçları", len(rows)), *self.market_table(rows, key)]

    def bist_filter_button(self):
        def toggle(_):
            self.bist_filters_enabled = not self.bist_filters_enabled
            self.redraw()

        control = button("Hisse filtrelerini kaldır" if self.bist_filters_enabled else "Filtreleri uygula",
                         toggle, ACCENT if self.bist_filters_enabled else RUN_ORANGE)
        control.color = "#FFFFFF" if self.bist_filters_enabled else BG
        control.tooltip = "Hisse filtrelerini kaldır" if self.bist_filters_enabled else "Hisse filtrelerini uygula"
        control.disabled = "bist" in self.jobs
        return control

    def live_scan_button(self, key):
        single_stock = ((key == "evre" and self.evre_scope == "Tek hisse") or
                        (key == "bist" and self.single_market.get(key)))
        active = self.live_scan[key] and not single_stock

        def toggle(_):
            self.live_scan[key] = not self.live_scan[key]
            self.redraw()

        caption = "Periyodik tarama" if key == "bist" else "Canlı tarama"
        control = button(caption + " · " + ("Açık" if active else "Kapalı"), toggle, RED)
        control.color = "#FFFFFF"
        control.disabled = key in self.jobs or single_stock
        control.tooltip = ("Tek hisse taraması bir kez çalışır." if single_stock else
                           "Taramayı durdurduktan sonra değiştirebilirsin." if key in self.jobs else
                           "Çalıştırıldığında taramayı belirli aralıklarla tekrarla.")
        return control

    def switch_crypto_market(self, _):
        self.crypto_mode = "Binance Vadeli" if self.crypto_mode == "Binance TR" else "Binance TR"
        self.offset = 0
        self.redraw()

    def crypto(self):
        key = "tr" if self.crypto_mode == "Binance TR" else "futures"
        rows = self.results[key].values()
        market_button = button(self.crypto_mode, self.switch_crypto_market)
        market_button.tooltip = "Binance TR / Binance Vadeli arasında geçiş yap"
        options = [market_button]
        if self.single_market.get(key):
            self.pair_code.hint_text = "BTC_TRY" if key == "tr" else "ETHUSDT"
            options.append(self.pair_code)
        if key == "tr":
            options += [self.tr_interval, self.tr_signal, self.tr_stage]
            rows = [r for r in rows if (self.tr_signal.value in ("Tümü", r["Sinyal"]))
                    and (self.tr_stage.value in ("Tümü", r.get("Hazirlik") or "Yok"))]
        rows = sorted(rows, key=lambda row: row["Puan"], reverse=True)
        return self.market_view(key, rows, options, [self.live_scan_button(key)], self.start_crypto)

    def stop_scan(self, key, stop):
        if self.jobs.get(key) is not stop:
            return
        stop.set()
        self.jobs.pop(key)
        if key == "analiz":
            self.stopped_report = stop
        self.state[key].value = "Durduruldu"
        self.redraw()

    def scan_action(self, key, start):
        stop = self.jobs.get(key)
        return (lambda _: self.stop_scan(key, stop)) if stop is not None else start

    def run_job(self, key, worker):
        if key in self.jobs:
            self.jobs[key].set()
            self.state[key].value = "Durduruluyor…"
            self.redraw()
            return
        if key == "analiz":
            self.stopped_report = None
        stop = self.jobs[key] = threading.Event()
        self.state[key].value = "Veri alınıyor…"
        self.progress[key].value = 0
        self.progress_known.discard(key)
        self.redraw()

        def emit(kind, data=None):
            if not stop.is_set() or kind in ("report", "done"):
                self.messages.put((key, kind, data, stop))

        def run():
            try:
                with data_provider.scan_requests(stop):
                    worker(stop, emit)
            except Exception as exc:
                emit("failure", str(exc))
            finally:
                emit("done", stop.is_set())

        threading.Thread(target=run, daemon=True).start()

    def start_stock(self, _):
        mode = self.stock_mode()
        key = "evre" if mode == "EVRE" else "bist" if mode == "Hisse" else "dip" if mode == "Dip Radarı" else "memory"
        if key in self.jobs and key in ("evre", "dip", "memory"):
            self.stop_scan(key, self.jobs[key])
            return
        symbol, group = (self.stock_code.value or "").strip().upper(), self.stock_group.value
        if key == "bist":
            symbol = symbol if self.single_market.get(key) else ""
            if self.single_market.get(key) and key not in self.jobs and symbol not in market.BIST_CATALOG:
                self.notify("Bir BIST hisse kodu girin.")
                return
        if key == "evre" and self.evre_scope == "Tüm hisseler":
            symbol = ""
        elif key == "evre" and key not in self.jobs and symbol not in market.BIST_CATALOG:
            self.notify("Tek modunda geçerli bir BIST hisse kodu girin.")
            return
        symbols = [symbol] if symbol else market.bist_symbols(group)
        offline, live, unfiltered = self.offline.value, self.live_scan.get(key, False), not self.bist_filters_enabled
        bist_interval = int(self.bist_interval.value)
        tfs = [c.label for c in self.tfs if c.value]
        if key not in self.jobs and key == "bist" and not tfs:
            self.notify("En az bir zaman dilimi seç.")
            return
        if key not in self.jobs:
            self.results[key].clear()

        def work(stop, emit):
            if key == "bist":
                tc.FILTERS_OFF["BIST"] = unfiltered
                if not symbol:
                    tc.run_bist_scan(tfs, group, emit, stop, live_mode=live, interval=bist_interval)
                    return
                result = tc.analyze_bist_stock(symbol, tfs)
                emit("drop" if "Hata" in result or "Filtre" in result else "row", result)
                emit("progress", {"done": 1, "total": 1})
                if "Hata" in result:
                    emit("failure", result["Hata"])
                elif "Filtre" in result:
                    emit("status", f"Filtre · {result['Filtre']}")
                return
            if key in ("dip", "memory"):
                self.run_dip(symbols, mode, stop, emit)
                return
            while not stop.is_set():
                done = errors = 0
                for item in ev.scan_iter(symbols, self.db, False, stop, workers=3, offline=offline):
                    kind, value, *rest = item
                    if kind == "result":
                        r = rest[0]
                        if not offline and signal_history.recent(r["date"]):
                            try:
                                if watch.update(self.db, value, r):
                                    emit("alert", value)
                                signal_history.update(self.db, value, r)
                            except Exception as exc:
                                emit("status", f"Takip kaydı · {exc}")
                        emit("row", {"Sembol": value, "Fiyat": r["price"], "Puan": r["score"],
                                     "Sinyal": "KALKIŞ" if r.get("alarm") else "IZLE",
                                     "Evre": r["phase"]["phase"], "Tarih": r["date"],
                                     "ErkenPuan": r["opportunity"]["early_score"],
                                     "Potansiyel": r["target_pct"], "Giris": r["price"],
                                     "Stop": r["plan"]["stop"], "TP2": r["plan"]["target"],
                                     "VAL": r["val"], "POC": r["poc"], "VAH": r["vah"],
                                     "detail": dict(ev.slim(r), usd_series=r["usd_series"][-320:], usp=r["usp"][-320:])})
                        done += 1
                    elif kind == "error":
                        errors += 1
                        done += 1
                        emit("drop", {"Sembol": value, "Hata": rest[0]})
                    elif kind == "market":
                        emit("index", value)
                    else:
                        emit("status", value)
                    if kind in ("result", "error"):
                        emit("progress", dict(done=done, total=len(symbols), errors=errors))
                if not live or symbol or stop.is_set():
                    break
                emit("cycle", {"next": 900})
                stop.wait(900)

        self.run_job(key, work)

    def run_dip(self, symbols, mode, stop, emit):
        def analyze(symbol):
            with data_provider.scan_requests(stop):
                data_provider.check_stop()
                bars = ev.fetch(symbol, self.db)
                data_provider.check_stop()
            if mode == "Dip Radarı":
                r = dip_core.detect_bottom_volume(bars)
                detail = {name: value for name, value in r.items() if name != "bars"}
                return detail, r.get("score", 0)
            events, series = dip_core.scan_explosions(bars)
            if stop.is_set():
                return [], 0
            dip_core.archive(self.archive, symbol, events, series[-1][0] if series else "")
            return events, events[-1]["score"] if events else 0

        pool = ThreadPoolExecutor(max_workers=4)
        try:
            for start in range(0, len(symbols), 4):
                if stop.is_set():
                    break
                batch = symbols[start:start + 4]
                futures = {pool.submit(analyze, symbol): symbol for symbol in batch}
                n = start
                pending = set(futures)
                while pending and not stop.is_set():
                    completed, pending = wait(pending, timeout=.1, return_when=FIRST_COMPLETED)
                    for result in completed:
                        n += 1
                        symbol = futures[result]
                        if stop.is_set():
                            break
                        try:
                            detail, score = result.result()
                            if score:
                                summary = detail if mode == "Dip Radarı" else detail[-1]
                                row = {"Sembol": symbol, "Puan": score, "Evre": mode, "Tarih": summary.get("date"),
                                       "OlaySayısı": len(detail) if mode == "Dip Hafızası" else None,
                                       "detail": detail}
                                if mode == "Dip Radarı":
                                    row.update(Durum=summary["state"], HacimOran=summary.get("volx"),
                                               Dusus=summary.get("decline"), GrafikTarihi=summary.get("event"))
                                else:
                                    row.update(HacimOran=summary["spike"], Dusus=summary["drop"], GrafikTarihi=summary["date"])
                                emit("row", row)
                        except Exception as exc:
                            emit("drop", {"Sembol": symbol, "Hata": str(exc)})
                        emit("progress", {"done": n, "total": len(symbols)})
        finally:
            pool.shutdown(wait=False, cancel_futures=True)

    def start_crypto(self, _):
        key = "tr" if self.crypto_mode == "Binance TR" else "futures"
        live, interval = self.live_scan[key], int(self.tr_interval.value)
        pair = (self.pair_code.value or "").strip().upper() if self.single_market.get(key) else None
        if key not in self.jobs and pair is not None and not pair.endswith("_TRY" if key == "tr" else "USDT"):
            self.notify("Geçerli bir parite girin: BTC_TRY veya ETHUSDT.")
            return
        if key not in self.jobs:
            self.results[key].clear()

        def work(stop, emit):
            if key == "futures":
                tc.run_binance_scan(emit, stop, live_mode=live, symbol_filter=pair)
                return
            while not stop.is_set():
                final = {}
                fresh = set()

                def cycle(kind, payload):
                    if kind == "finished":
                        final.update(payload)
                    elif kind == "row":
                        fresh.add(payload["Sembol"])
                    emit(kind, payload)

                tc.run_tr_scan(cycle, stop, symbol_filter=pair)
                if not stop.is_set():
                    emit("fresh", fresh)
                if not live or final.get("limited") or stop.is_set() or not final.get("total"):
                    break
                emit("cycle", {"next": interval, "errors": final.get("errors", 0),
                               "received": len(fresh)})
                stop.wait(interval)

        self.run_job(key, work)

    async def poll(self):
        while True:
            self.clock.value = datetime.now().strftime("%H:%M")
            changed = chart_changed = False
            for _ in range(100):
                try:
                    key, event, data, *token = self.messages.get_nowait()
                except queue.Empty:
                    break
                self.receive(key, event, data, *token)
                changed = True
                chart_changed |= self.section == "Grafik" and event in ("chart", "chart_error", "notice")
            if (changed and self.section != "Grafik") or chart_changed:
                self.redraw()
            else:
                self.clock.update()
            await asyncio.sleep(0.3 if self.jobs else 1)

    def receive(self, key, event, data, token=None):
        if token is not None and self.jobs.get(key) is not token:
            if key == "analiz" and event == "report" and self.stopped_report is token:
                self.report, self.report_bars, _ = data
                self.reset_report_view()
                self.offset = 0
            return
        if key == "guncelleme":
            self.update_event(event, data)
            return
        status = self.state.get(key)
        if event == "row":
            self.results[key][data["Sembol"]] = dict(data, source=key)
            self.updated_at = datetime.now().strftime("%H:%M")
        elif event == "drop":
            self.results[key].pop(data["Sembol"], None)
            if data.get("Hata"):
                status.value = f"{data['Sembol']} · {data['Hata']}"
        elif event == "fresh":
            rows = self.results[key]
            for symbol in rows.keys() - data:
                del rows[symbol]
        elif event == "progress" and data.get("total"):
            total, done = data["total"], data.get("done", 0)
            self.progress[key].value = done / total
            self.progress_known.add(key)
            status.value = f"{done}/{total} · {len(self.results.get(key, {}))} sonuç"
        elif event in ("status", "log"):
            status.value = str(data)
            counted = re.match(r"\s*(\d+)\s*/\s*(\d+)", str(data))
            if key == "analiz" and counted and int(counted.group(2)):
                self.progress[key].value = min(1.0, int(counted.group(1)) / int(counted.group(2)))
                self.progress_known.add(key)
        elif event == "alert":
            status.value = f"Kalkış alarmı · {data}"
            if self.sound.value:
                self.page.run_task(self.play_alarm)
        elif event in ("index", "meta"):
            name, trend, change = (("BIST100", data.get("trend"), data.get("change_pct")) if event == "index"
                                   else ("BTC", data["btc_mode"], data.get("btc_change")))
            text, color = change_text(change)
            self.market_summary[key].value = f"{name} · {trend} · {text}"
            self.market_summary[key].color = color
        elif event == "cycle":
            status.value = f"Sonraki tur {data['next']} sn sonra · {data.get('errors', 0)} hata"
            if data.get("received") == 0:
                status.value = f"Veri alınamadı · sonraki tur {data['next']} sn sonra"
        elif event == "finished":
            if data.get("limited"):
                status.value = "API sınırı · tarama durdu"
            elif data.get("errors") and not self.results[key]:
                status.value = f"Veri alınamadı · {data['errors']} hata"
        elif event == "failure":
            status.value = f"Hata · {data}"
        elif event == "report":
            self.report, self.report_bars, source = data
            if key == "analiz":
                self.progress[key].value = 1.0
                self.progress_known.add(key)
            self.reset_report_view()
            status.value = f"{len(self.report)} kayıt · {source}"
            self.offset = 0
            if getattr(self, "report_mode", "") == "Fırsat alarmı" and self.sound.value:
                candidates = {(row.get("symbol"), row.get("date")) for row in self.report
                              if row.get("state") in ("Kalkışta", "Erken kalkış adayı")
                              and row.get("data_status", "").startswith("Yakın tarihli")}
                if candidates - self.heard_alerts:
                    self.heard_alerts.update(candidates)
                    self.page.run_task(self.play_alarm)
        elif event == "done":
            self.jobs.pop(key, None)
            if status is not None and not status.value.startswith(("API", "Hata", "Veri alınamadı")):
                if data:
                    status.value = "Durduruldu"
                elif key != "analiz" and not status.value.startswith("Filtre"):
                    status.value = f"Bitti · {len(self.results[key])} sonuç"
        elif event == "chart":
            request, bars = data
            if request == self.chart_request:
                self.graph_bars = bars
                if bars:
                    self.chart_span = min(self.chart_span, len(bars))
                if bars and self.chart_row.get("direct_chart") and self.graph_tf == "1D":
                    self.chart_row["Fiyat"] = bars[-1][4]
                self.graph_status = "" if bars else "Grafik verisi yok."
                if bars and self.chart_row.get("source") == "memory" and self.graph_tf == "1D":
                    self.memory_viewport()
                    missing = self.memory_marks().keys() - {bar[0] for bar in bars}
                    if missing:
                        self.graph_status = f"{len(missing)} olay için günlük mum bulunamadı."
        elif event == "chart_error":
            request, error = data
            if request == self.chart_request:
                self.graph_status = f"Grafik verisi alınamadı · {error}"
        elif event == "prices":
            self.prices.update(data)
        elif event == "close":
            trade, price = data
            closed = tc.close_virtual_trade(dict(trade), price)
            updated = [closed if row is trade else row for row in self.trades]
            try:
                save_state(tc.TRADES_FILE, updated)
            except OSError as exc:
                self.notice.value = f"İşlem kaydedilemedi · {exc}"
            else:
                trade.update(closed)
                self.notice.value = "Sanal işlem kapatıldı."
        elif event == "notice":
            self.notice.value = data

    async def play_alarm(self):
        try:
            await self.audio.play()
        except Exception as exc:
            self.notify(f"Alarm sesi çalınamadı · {exc}")

    def notify(self, message):
        self.notice.value = message
        self.redraw()

    def mode_changed(self, _):
        self.params.value = RESEARCH_DEFAULTS.get(self.research_mode.value, "")
        self.offset = 0
        self.redraw()

    def alarm_view(self):
        return self.research_view(alarm=True)

    def reset_report_view(self):
        self.report_sort = None
        self.selected_row = None
        self.report_resume = None

    def research_view(self, alarm=False):
        key = "Fırsat alarmı" if alarm else self.research_mode.value
        if alarm and key != self.research_mode.value and not self.jobs.get("analiz"):
            self.research_mode.value = key
            self.params.value = RESEARCH_DEFAULTS[key]
        stock_report = key not in research.PAIR_MODES
        choices = ["Tek hisse", "Tüm hisseler"]
        if key == "Çoklu EVRE testi":
            choices.append("Kod listesi")
        scope = self.research_scope if self.research_scope in choices else "Tek hisse"
        self.research_code.label = ("Parite" if not stock_report else
                                    "Hisse kodları" if scope == "Kod listesi" else "Hisse kodu")
        scope_label, scope_color = SCOPE_STYLE[scope]
        running = "analiz" in self.jobs
        return [panel([
            label("Rapor ayarları", FG),
            form_grid([
                *([] if alarm else [self.research_mode]),
                *([self.research_code] if not stock_report or scope != "Tüm hisseler" else []),
                *([] if alarm else [self.reference]),
                *([self.params] if key in RESEARCH_DEFAULTS else []),
            ]),
            ft.Row([
                *([button(scope_label, lambda _: self.cycle_research_scope(choices, scope), scope_color)]
                  if stock_report else []),
                button("Durdur" if running else "Çalıştır", self.scan_action("analiz", self.start_research), RED if running else RUN_ORANGE),
                button("CSV kaydet", lambda _: self.export([translated_row(row) for row in self.sorted_report()])),
                self.research_offline, self.sound,
            ], wrap=True, spacing=12, vertical_alignment=ft.CrossAxisAlignment.CENTER),
            self.status_bar("analiz", running),
            self.state["analiz"],
            *([button("Çoklu test özetine dön", self.back_to_multi)]
              if getattr(self, "report_mode", "") == "EVRE test ayrıntısı" else []),
        ]), self.result_heading("Rapor sonuçları", len(self.report)), *self.report_table()]

    def status_bar(self, key, running):
        """Durum yüzde çubuğu (Analiz, Dip Alarm ve Dip Hafıza sayfalarında aynı görünüm)."""
        bar = self.progress[key]
        bar.color = RUN_ORANGE
        bar.bgcolor = "#2A3350"
        bar.bar_height = 8
        if running and key not in self.progress_known:
            bar.value = None
            percent = "…"
        else:
            bar.value = bar.value or 0
            percent = f"%{round(bar.value * 100)}"
        return ft.Row([ft.Container(bar, expand=True),
                       ft.Text(percent, size=12, weight=ft.FontWeight.BOLD, color=FG, width=44,
                               text_align=ft.TextAlign.RIGHT)],
                      spacing=8, vertical_alignment=ft.CrossAxisAlignment.CENTER)

    def cycle_research_scope(self, choices, current):
        self.set_research_scope(choices[(choices.index(current) + 1) % len(choices)])

    def set_research_scope(self, scope):
        self.research_scope = scope
        self.redraw()

    def start_research(self, _):
        mode = "Fırsat alarmı" if self.section == "EVRE Alarm" else self.research_mode.value
        raw, ref, offline = self.research_code.value, self.reference.value, self.research_offline.value
        if "analiz" in self.jobs:
            self.stop_scan("analiz", self.jobs["analiz"])
            return
        all_stocks = mode not in research.PAIR_MODES and self.research_scope == "Tüm hisseler"
        raw = "" if all_stocks else (raw or "").strip().upper()
        if mode not in research.PAIR_MODES and not all_stocks:
            list_mode = mode == "Çoklu EVRE testi" and self.research_scope == "Kod listesi"
            if not list_mode and raw not in market.BIST_CATALOG:
                self.notify("Tek hisse için geçerli bir BIST kodu girin (ör. THYAO).")
                return
        try:
            options = report_options(mode, self.params.value)
        except ValueError as exc:
            self.notify(f"Rapor ayarlarını kontrol et. {exc}")
            return
        self.reset_report_view()
        self.report, self.report_bars, self.report_symbol = [], [], raw.strip().upper()
        self.report_mode = mode
        self.report_offline = offline
        self.report_options = options

        def work(stop, emit):
            if all_stocks and mode == "Fırsat alarmı":
                result = research.scan_alerts(ev.universe(), self.db, offline, options["minimum"], stop,
                                              lambda text: emit("status", text))
            elif all_stocks and mode not in ("Sinyal geçmişi", "Kalkış takibi"):
                result = research.run_all(mode, ev.universe(), self.db, offline, ref, options,
                                          stop, lambda text: emit("status", text))
            else:
                result = research.run(mode, raw, self.db, offline, ref, options)
            if all_stocks or not stop.is_set():
                emit("report", result)

        self.run_job("analiz", work)

    def sorted_report(self):
        if not self.report_sort:
            return self.report
        name, ascending = self.report_sort
        values = [(row, translated_row(row).get(name)) for row in self.report]
        filled = sorted((item for item in values if item[1] is not None),
                        key=lambda item: sort_value(item[1]), reverse=not ascending)
        return [row for row, _ in filled] + [row for row, value in values if value is None]

    def sort_report(self, name, event):
        ascending = getattr(event, "ascending", None)
        if ascending is None:
            ascending = not (self.report_sort and self.report_sort[0] == name and self.report_sort[1])
        self.report_sort = (name, bool(ascending))
        self.offset = 0
        self.redraw()

    def sort_picker(self, columns):
        """Sütun başlığı sıralaması desteklenmiyorsa kullanılan yedek: sütun seçimi ve yön düğmesi."""
        name, ascending = self.report_sort or (None, True)
        picker = select("Sırala", ["—", *columns], name or "—", on_select=lambda event: self.pick_sort(event, columns))
        return ft.Row([picker, button("Artan" if ascending else "Azalan", lambda _: self.flip_sort(columns))],
                      wrap=True)

    def pick_sort(self, event, columns):
        chosen = event.control.value
        self.report_sort = None if chosen in (None, "—") else (chosen, True)
        self.offset = 0
        self.redraw()

    def flip_sort(self, columns):
        if self.report_sort:
            self.report_sort = (self.report_sort[0], not self.report_sort[1])
            self.redraw()

    def select_row(self, row, redraw=True):
        self.selected_row = id(row)
        if redraw:
            self.redraw()

    def report_table(self):
        if not self.report:
            return [label("Kayıt yok.")]
        ordered = self.sorted_report()
        last = (len(ordered) - 1) // PAGE_SIZE
        self.offset = min(self.offset, last)
        start = self.offset * PAGE_SIZE
        columns = list(dict.fromkeys(heading(key, row) for row in self.report for key in row))
        rows = []
        for row in ordered[start:start + PAGE_SIZE]:
            values = translated_row(row)
            chosen = id(row) == self.selected_row
            cells = [ft.DataCell(ft.Row(self.report_actions(row), spacing=4))]
            for name in columns:
                value = values.get(name)
                shown = "—" if value is None else str(value).replace("\n", " · ")
                cells.append(ft.DataCell(ft.Container(
                    ft.Text(shown[:120], size=12, max_lines=1, overflow=ft.TextOverflow.ELLIPSIS,
                            weight=ft.FontWeight.BOLD if chosen else ft.FontWeight.NORMAL,
                            color="#FFFFFF" if chosen else None),
                    max_width=240, bgcolor=SELECTED_ROW if chosen else None,
                    on_click=lambda _, item=row: self.select_row(item),
                )))
            try:
                rows.append(ft.DataRow(cells=cells, color=SELECTED_ROW if chosen else None))
            except TypeError:
                rows.append(ft.DataRow(cells=cells))
        sort_index = None
        if self.report_sort and self.report_sort[0] in columns:
            sort_index = columns.index(self.report_sort[0]) + 1
        try:
            header = [ft.DataColumn(label("İşlemler", FG))] + [
                ft.DataColumn(label(name, FG), on_sort=lambda event, item=name: self.sort_report(item, event))
                for name in columns]
            header_sorting = True
        except TypeError:
            header = [ft.DataColumn(label(name, FG)) for name in ["İşlemler", *columns]]
            header_sorting = False
        options = dict(columns=header, rows=rows, heading_row_height=36, data_row_min_height=40,
                       data_row_max_height=40, horizontal_margin=8, column_spacing=16)
        try:
            table = ft.DataTable(**options, sort_column_index=sort_index,
                                 sort_ascending=self.report_sort[1] if self.report_sort else True)
        except TypeError:
            table = ft.DataTable(**options)
            header_sorting = False
        sorter = [] if header_sorting else [self.sort_picker(columns)]
        return [*sorter, ft.Row([table], scroll=ft.ScrollMode.ALWAYS), *self.page_buttons(last)]

    def open_report_details(self, row):
        self.select_row(row)
        self.report_details(row)

    def report_details(self, row):
        colors = {tier: color for tier, _, color in TIERS}
        ranked = sorted(((importance(key), index, key, value) for index, (key, value) in enumerate(row.items())
                         if value is not None), key=lambda item: item[:2])
        fields = []
        for tier, _, key, value in ranked:
            shown = report_value(key, value)
            shown = "—" if shown is None else str(shown)
            fields.append(ft.Container(
                content=ft.Column([
                    ft.Text(heading(key, row), size=11, color=colors[tier],
                            weight=ft.FontWeight.BOLD if tier <= 2 else ft.FontWeight.NORMAL, selectable=True),
                    ft.Text(shown, size=14 if tier == 1 else 13, color=colors[tier] if tier <= 2 else FG if tier == 3 else MUTED,
                            weight=ft.FontWeight.BOLD if tier == 1 else ft.FontWeight.NORMAL, selectable=True),
                ], spacing=0, tight=True),
                padding=ft.Padding.only(left=8, top=2, bottom=2),
                border=ft.Border.only(left=ft.BorderSide(4 if tier == 1 else 3 if tier == 2 else 2, colors[tier])),
            ))
        legend = ft.Row([ft.Text(f"● {name}", size=11, color=color, weight=ft.FontWeight.BOLD)
                         for _, name, color in TIERS], wrap=True, spacing=10)
        self.page.show_dialog(ft.AlertDialog(
            title=ft.Text("Rapor satırı"), scrollable=True,
            content=ft.Column([legend, *fields], tight=True, spacing=6),
            actions=[ft.TextButton(content="Kapat", on_click=lambda _: self.page.pop_dialog())],
        ))

    def report_actions(self, row):
        def icon_action(icon, description, handler, color=ACCENT):
            return ft.IconButton(icon=icon, tooltip=description, icon_color=color,
                                 icon_size=19, width=34, height=34, padding=5, on_click=handler)

        fields = [icon_action(ft.Icons.MENU, "Satır ayrıntıları", lambda _: self.open_report_details(row))]
        if self.row_bars(row):
            fields.append(icon_action(ft.Icons.SHOW_CHART, "Grafikte göster", lambda _: self.report_chart(row),
                                      CHART_YELLOW))
        if getattr(self, "report_mode", "") == "Çoklu EVRE testi" and row.get("state") == "OK":
            fields.append(icon_action(ft.Icons.FACT_CHECK_OUTLINED, "Hisse test ayrıntısı",
                                      lambda _: self.open_test_detail(row["symbol"])))
        if getattr(self, "report_mode", "") == "Kalkış takibi" and row.get("Sembol"):
            fields.append(button("Takipten çıkar", lambda _: self.remove_watch(row["Sembol"]), RED))
        return fields

    def open_test_detail(self, symbol):
        if "analiz" in self.jobs:
            return
        options = self.report_options
        offline = self.report_offline
        self.multi_summary = (self.report, self.report_bars, self.state["analiz"].value, self.report_symbol)
        self.report_mode = "EVRE test ayrıntısı"
        self.report_symbol = symbol

        def work(stop, emit):
            result = research.run("EVRE geçmiş testi", symbol, self.db, offline, options=options)
            if not stop.is_set():
                emit("report", result)

        self.run_job("analiz", work)

    def back_to_multi(self, _):
        if "analiz" in self.jobs:
            return
        self.report, self.report_bars, self.state["analiz"].value, self.report_symbol = self.multi_summary
        self.report_mode = "Çoklu EVRE testi"
        self.offset = 0
        self.redraw()

    def remove_watch(self, symbol):
        watch.remove(self.db, symbol)
        self.report = [row for row in self.report if row.get("Sembol") != symbol]
        self.notify(f"{symbol} takipten çıkarıldı.")

    def row_bars(self, row):
        if isinstance(self.report_bars, dict):
            return self.report_bars.get(row.get("symbol"), [])
        return self.report_bars

    def report_chart(self, row):
        symbol = row.get("symbol") or row.get("Sembol") or row.get("Hisse") or self.report_symbol or "Rapor"
        if getattr(self, "report_mode", None) == "Dip arşivi" and "spike" in row:
            self.report_resume = {"offset": self.offset, "scroll": self.scroll_pixels}
            self.open_chart({"Sembol": symbol, "source": "memory"})
            return
        source = "tr" if symbol.endswith("_TRY") else "bist"
        self.graph_focus = (row.get("SinyalTarihi") or row.get("date") or row.get("Tarih")
                            or row.get("signal_date") or row.get("manual"))
        self.select_row(row, redraw=False)
        self.report_resume = {"offset": self.offset, "scroll": self.scroll_pixels}
        self.chart_is_report = True
        self.chart_shift = 0
        self.chart_row = dict(row, Sembol=symbol, source=source)
        self.graph_tf = "5m" if source == "tr" else "1D"
        self.chart_request += 1
        bars = self.row_bars(row)
        # Raporda mum yoksa veya mumlar günlük değilse (haftalık/aylık), günlük grafik yeniden alınır.
        needs_daily = source == "bist" and (not bars or data_provider.is_coarse(bars))
        self.graph_bars = [] if needs_daily else bars
        if self.graph_bars:
            self.chart_span = min(self.chart_span, len(self.graph_bars))
        self.graph_status = "Günlük grafik hazırlanıyor…" if needs_daily else ""
        self.show("Grafik")
        if needs_daily:
            self.load_chart(full_history=True)

    def show_archive(self, _):
        self.report_mode = "Dip arşivi"
        self.reset_report_view()
        self.report = dip_core.read_archive(self.archive)
        self.report_bars = []
        self.state["analiz"].value = f"{len(self.report)} arşiv kaydı"
        self.show("Analiz")

    def export(self, rows):
        report_rows = []
        for row in rows:
            base = {k: v for k, v in row.items() if k != "detail"}
            detail = row.get("detail")
            if row.get("source") == "memory":
                report_rows.extend({**base, **event} for event in detail)
            elif row.get("source") == "dip":
                report_rows.append({**base, **detail})
            else:
                report_rows.append(base)
        if not report_rows:
            self.notify("Kaydedilecek sonuç yok.")
            return

        async def save():
            try:
                name = f"V39_{datetime.now():%Y%m%d_%H%M%S}.csv"
                if getattr(self.page, "web", False):
                    # Tarayıcıda dosya seçici yok: CSV sunucuda üretilir ve indirme bağlantısı açılır.
                    folder = Path(__file__).with_name("assets") / "exports"
                    folder.mkdir(parents=True, exist_ok=True)
                    for old in folder.glob("*.csv"):
                        if time.time() - old.stat().st_mtime > 86400:
                            old.unlink(missing_ok=True)
                    (folder / name).write_bytes(research.csv_bytes(report_rows))
                    opened = self.page.launch_url(f"/exports/{name}")
                    if hasattr(opened, "__await__"):
                        await opened
                    self.notify("CSV indirme bağlantısı açıldı.")
                    return
                path = await self.picker.save_file(file_name=name, src_bytes=research.csv_bytes(report_rows))
                if path:
                    self.notify("CSV kaydedildi.")
            except Exception as exc:
                self.notify(f"CSV kaydedilemedi · {exc}")

        self.page.run_task(save)

    def toggle_favorite(self, symbol):
        existing = next((item for item in self.favorites if item["Sembol"] == symbol), None)
        updated = [entry for entry in self.favorites if entry != existing]
        if not existing:
            updated.append({"Sembol": symbol, "Tarih": datetime.now().date().isoformat()})
        try:
            save_state(tc.FAV_FILE, updated)
        except OSError as exc:
            self.notify(f"Favori kaydedilemedi · {exc}")
            return
        self.favorites = updated
        self.redraw()

    def favorite_view(self):
        rows = {r["Sembol"]: r for group in self.results.values() for r in group.values()}
        favorites = []
        for entry in self.favorites:
            symbol = entry["Sembol"]
            source = "tr" if symbol.endswith("_TRY") else "bist" if tc.is_bist_symbol(symbol) else "futures"
            favorites.append(rows.get(symbol, dict(entry, source=source)))
        return self.cards(favorites, self.card)

    def memory_marks(self):
        return {event["date"]: f"Dip olayı · Puan {event.get('score', '—')} · Hacim {event.get('spike', '—')}×"
                for event in self.chart_row.get("detail", []) if isinstance(event, dict) and event.get("date")}

    def memory_viewport(self, day=None):
        marks = self.memory_marks()
        indices = [i for i, bar in enumerate(self.graph_bars) if bar[0] in marks]
        if not indices:
            return
        self.graph_focus = day
        if day:
            self.chart_span = min(70, len(self.graph_bars))
            self.chart_shift = 0
        else:
            left = max(0, indices[0] - 8)
            right = min(len(self.graph_bars), indices[-1] + 9)
            self.chart_span = right - left
            self.chart_shift = right - len(self.graph_bars)

    def memory_event_menu(self, marks, bars):
        dates = {bar[0] for bar in bars}
        def choose(day):
            self.memory_viewport(day)
            self.redraw()
        items = [ft.PopupMenuItem(content="Tüm olayları göster", on_click=lambda _: choose(None))]
        items.extend(ft.PopupMenuItem(content=f"{day} · {marks[day]}", disabled=day not in dates,
                                      on_click=lambda _, d=day: choose(d)) for day in sorted(marks, reverse=True))
        return ft.PopupMenuButton(content=label(f"Dip olayları ({len(marks)}) ▾", YELLOW), items=items)

    def open_chart(self, row):
        if self.chart_row and self.chart_row.get("source") == "memory":
            self.chart_span = 70
        if row["source"] == "memory" and not isinstance(row.get("detail"), list):
            row = dict(row, detail=dip_core.read_archive(self.archive, [row["Sembol"]]))
        self.chart_row = row
        self.graph_focus = row.get("GrafikTarihi")
        self.chart_is_report = False
        self.chart_shift = 0
        self.graph_bars = []
        self.graph_status = "Grafik hazırlanıyor…"
        self.graph_tf = "5m" if row["source"] in ("tr", "futures") else "1D"
        self.show("Grafik")
        self.load_chart()

    def load_full_chart(self, _):
        self.chart_shift = 0
        self.load_chart(full_history=True)

    def load_chart(self, full_history=False):
        self.chart_request += 1
        request, row, tf = self.chart_request, self.chart_row, self.graph_tf
        if not full_history:
            self.graph_bars = []
        self.graph_status = "Grafik hazırlanıyor…"
        self.redraw()

        def work():
            try:
                symbol, source = row["Sembol"], row["source"]
                if source in ("tr", "futures"):
                    bars = research.crypto_bars(tc.binance_get_market_data(symbol, tf, 1000, min_bars=1))
                elif source == "memory" and tf == "1D":
                    try:
                        bars = ev.fetch(symbol, self.db, offline=True)
                    except ValueError:
                        bars = []
                    days = {event["date"] for event in row["detail"] if event.get("date")}
                    if full_history or not bars or days.difference(bar[0] for bar in bars):
                        bars = data_provider.chart_bars(symbol, tf, full_history=True)
                elif source == "evre" and tf in ("1D", "USD") and row.get("detail"):
                    bars = row["detail"]["usd_series" if tf == "USD" else "series"]
                else:
                    bars = data_provider.chart_bars(symbol, tf, full_history=full_history)
                self.messages.put(("grafik", "chart", (request, bars)))
            except Exception as exc:
                self.messages.put(("grafik", "chart_error", (request, str(exc))))

        threading.Thread(target=work, daemon=True).start()

    def set_tf(self, period):
        if self.graph_tf == period and self.graph_bars:
            return
        if self.chart_row.get("source") == "memory":
            self.graph_focus = None
            self.chart_span = 70
        self.graph_tf = period
        self.chart_shift = 0
        self.load_chart()

    def chart_window(self, shift, zoom):
        bars = self.graph_bars
        focus = next((i for i, bar in enumerate(bars) if bar[0] == self.graph_focus), None)
        self.chart_span = max(20, min(max(1000, len(bars)), self.chart_span + zoom))
        last = max(0, len(bars) - self.chart_span)
        base = focus - self.chart_span // 2 if focus is not None else last
        proposed = base + self.chart_shift + shift
        self.chart_shift = clamp_view_start(proposed, len(bars), self.chart_span) - base
        self.redraw()

    def toggle_indicator(self, name):
        self.indicators[name] = not self.indicators[name]
        self.redraw()

    def toggle_draw(self, _):
        self.draw_mode = not self.draw_mode
        self.redraw()

    def chart_mark(self, event, window, key):
        if not self.draw_mode or event.type != charts.ChartEventType.TAP_UP:
            return
        i = event.spot_index
        if i is None or not 0 <= i < len(window):
            return
        day = window[i][0]
        marks = self.user_marks.setdefault(key, set())
        if day in marks:
            marks.remove(day)
        else:
            marks.add(day)
        self.draw_mode = False
        self.redraw()

    def volume_chart(self, window):
        return charts.LineChart(
            data_series=[charts.LineChartData(
                points=[charts.LineChartDataPoint(i, bar[5]) for i, bar in enumerate(window)],
                color=MUTED, stroke_width=1,
                below_line_bgcolor=ft.Colors.with_opacity(0.25, ACCENT),
            )], min_y=0, max_y=max(1, max(bar[5] for bar in window) * 1.1), height=80,
        )

    def ema_lines(self, bars):
        lines = []
        for period in sorted(self.ema_periods):
            weight = 2 / (period + 1)
            data = [bars[0][4]]
            for bar in bars[1:]:
                data.append(data[-1] + weight * (bar[4] - data[-1]))
            lines.append((f"EMA {period}", data, EMA_COLORS[period]))
        return lines

    def chart_indicator_menu(self, trade_items):
        def item(name, callback, selected=False, color=FG):
            return ft.MenuItemButton(content=ft.Text(name, size=11, color=color),
                                     leading=ft.Icon(ft.Icons.CHECK, size=13, opacity=1 if selected else 0),
                                     height=30, on_click=callback)

        def submenu(name, options):
            return ft.SubmenuButton(content=ft.Text(name, size=11, color=FG), controls=options, height=30)

        def toggle_ema(period):
            self.ema_periods.symmetric_difference_update({period})
            self.redraw()

        def set_pivot(period):
            self.pivot_period = period
            self.redraw()

        options = [submenu("EMA", [item(f"EMA {period}", lambda _, p=period: toggle_ema(p),
                                        period in self.ema_periods, color)
                                   for period, color in EMA_COLORS.items()])]
        indicators = ["VWAP"]
        if self.workshop_enabled:
            indicators += ["VWAP bantları", "Akümülasyon", "Görünür hacim"]
        for name in indicators:
            caption = "VWAP bantları ±1–4σ" if name == "VWAP bantları" else name
            options.append(item(caption, lambda _, n=name: self.toggle_indicator(n), self.indicators[name]))
        if self.workshop_enabled:
            options.append(submenu("Camarilla", [item(p, lambda _, v=p: set_pivot(v), p == self.pivot_period)
                                                 for p in ("Kapalı", *CAMARILLA)]))
        else:
            options.append(item("İşaretle", self.toggle_draw, self.draw_mode))
        options.extend(item(name, callback, color=RED) for name, callback in trade_items)
        return ft.MenuBar(controls=[submenu("Göstergeler ▾", options)],
                          style=ft.MenuStyle(bgcolor=PANEL, padding=0))

    def indicator_chart(self, bars, start, count):
        lines = self.ema_lines(bars)
        if self.indicators["VWAP"] or self.indicators["VWAP bantları"]:
            lines.append(("VWAP", [v for v, _ in ev.spiral(bars)], YELLOW))
        if not lines:
            return None
        series, values = [], []
        for name, data, color in lines:
            data = data[start:start + count]
            values.extend(data)
            series.append(charts.LineChartData(
                points=[charts.LineChartDataPoint(i, value) for i, value in enumerate(data)],
                color=color, stroke_width=2,
            ))
        low, high = min(values), max(values)
        pad = max((high - low) * 0.1, abs(high) * 0.001, 0.000001)
        return panel([label(" · ".join(name for name, _, _ in lines)),
                      charts.LineChart(data_series=series, min_y=low - pad, max_y=high + pad, height=115)])

    def profile_view(self, bars):
        val, poc, vah, low, step, bins = ev.profile_bins(bars)
        peak = max(bins) or 1
        rows = []
        for i in reversed(range(len(bins))):
            mid = low + (i + 0.5) * step
            color = ACCENT if val <= mid <= vah else MUTED
            rows.append(ft.Row([
                ft.Text(f"{mid:.4g}", width=62, color=color, size=11),
                ft.ProgressBar(value=bins[i] / peak, color=color, bgcolor=PANEL2, expand=True),
            ]))
        return ft.ExpansionTile(title=label("FRVP · Yatay hacim profili", ACCENT),
                                controls=[label(f"VAL {val:.4g} · POC {poc:.4g} · VAH {vah:.4g}"), *rows])

    def latest_candle(self, _):
        self.graph_focus = None
        self.chart_shift = 0
        self.redraw()

    def toggle_workshop(self, _):
        self.workshop_enabled = not self.workshop_enabled
        self.redraw()

    def workshop_option(self, name, event):
        setattr(self, name, event.control.value)
        self.redraw()

    def remember_price_range(self, key, value):
        if value is None:
            self.price_ranges.pop(key, None)
        else:
            self.price_ranges[key] = value

    def reset_price_range(self, key):
        self.price_ranges.pop(key, None)
        self.redraw()

    def toggle_chart_focus(self, _):
        self.chart_focus = not self.chart_focus
        if self.chart_focus and not self.workshop_enabled:
            self.workshop_enabled = True
        self.redraw()

    def workshop_size(self, _):
        self.workshop_large = not self.workshop_large
        self.redraw()

    def record_drawing_history(self):
        for key in self.workshop_drawings.keys() | self.drawing_snapshot.keys():
            before = self.drawing_snapshot.get(key, [])
            after = self.workshop_drawings.get(key, [])
            if before != after:
                stack = self.drawing_undo.setdefault(key, [])
                stack.append(deepcopy(before))
                del stack[:-50]
                self.drawing_redo.pop(key, None)
        self.drawing_snapshot = deepcopy(self.workshop_drawings)

    def persist_drawings(self):
        self.record_drawing_history()
        try:
            save_state(self.workshop_file, self.workshop_drawings)
        except OSError as exc:
            self.notice.value = f"Çizim kaydedilemedi · {exc}"

    def finish_drawing(self):
        self.workshop_tool = "İmleç"
        self.redraw()

    def chart_note(self, key, point):
        field = ft.TextField(label="Grafik notu", autofocus=True, max_length=100)

        def save(_):
            value = (field.value or "").strip()
            if not value:
                field.error_text = "Bir not yazın."
                self.page.update()
                return
            self.workshop_drawings[key].append({"tool": "text", "point": point, "text": value})
            self.persist_drawings()
            self.page.pop_dialog()
            self.finish_drawing()

        self.page.show_dialog(ft.AlertDialog(title=ft.Text("Grafiğe not ekle"), content=field,
            actions=[ft.TextButton(content="Vazgeç", on_click=lambda _: self.page.pop_dialog()),
                     button("Ekle", save)]))

    def undo_drawing(self, key):
        self.restore_drawing_history(key, False)

    def restore_drawing_history(self, key, redo=False):
        source = self.drawing_redo if redo else self.drawing_undo
        dest = self.drawing_undo if redo else self.drawing_redo
        if not source.get(key):
            return
        dest.setdefault(key, []).append(deepcopy(self.workshop_drawings.get(key, [])))
        self.workshop_drawings[key] = source[key].pop()
        self.drawing_snapshot = deepcopy(self.workshop_drawings)
        self.persist_drawings()
        self.workshop_tool = "İmleç"
        self.redraw()

    def on_keyboard(self, event):
        if self.section != "Grafik" or getattr(self, "chart_search_focused", False):
            return
        chart = getattr(self, "active_workshop", None)
        key = getattr(self, "last_chart_key", None)
        if chart is None or key is None or chart.tool != "İmleç":
            return
        if any(getattr(d, "open", False) for d in getattr(self.page, "overlay", [])):
            return
        command = str(getattr(event, "key", "")).upper()
        ctrl = bool(getattr(event, "ctrl", False) or getattr(event, "meta", False))
        if ctrl and command in ("Z", "Y"):
            self.restore_drawing_history(key, redo=command == "Y")
            return
        if ctrl and command == "V":
            copied = getattr(self, "drawing_clipboard", None)
            if copied and copied[0] == key:
                chart.pending_copy = deepcopy(copied[1]), copied[2]
                chart.anchor = None
                chart.redraw_overlay()
            return
        target = getattr(chart, "selected_drawing", None)
        if target is None or not any(d is target for d in chart.drawings):
            return
        if command == "DELETE" and not ctrl:
            if isinstance(target, dict) and target.get("locked"):
                return
            chart.drawings[:] = [d for d in chart.drawings if d is not target]
            self.persist_drawings()
            self.redraw()
        elif ctrl and command == "C":
            origin = chart.cursor
            if origin and origin[0] in chart.bar_index:
                drawing = deepcopy(target)
                if isinstance(drawing, dict):
                    for field in ("alarm", "alarm_level", "all_timeframes", "locked"):
                        drawing.pop(field, None)
                self.drawing_clipboard = key, drawing, origin

    def favorite_drawing_dialog(self):
        tools = [name for names in DRAW_GROUPS.values() for name in names]
        def toggle(name, checked):
            if checked and name not in self.favorite_tools:
                self.favorite_tools.append(name)
            elif not checked and name in self.favorite_tools:
                self.favorite_tools.remove(name)
            save_state(self.favorite_tools_file, self.favorite_tools)
        def close(_):
            self.page.pop_dialog()
            self.redraw()
        self.page.show_dialog(ft.AlertDialog(title=ft.Text("Favori çizim araçları"),
            content=ft.Container(height=350, width=340, content=ft.Column([
                ft.Checkbox(label=name, value=name in self.favorite_tools,
                    on_change=lambda e, n=name: toggle(n, e.control.value)) for name in tools], scroll=ft.ScrollMode.AUTO)),
            actions=[ft.TextButton(content="Kapat", on_click=close)]))

    @staticmethod
    def drawing_quote(source, symbol):
        if source in ("tr", "futures"):
            return float(tc.binance_get("/fapi/v1/klines", {"symbol":symbol,"interval":"5m","limit":1})[-1][4])
        return data_provider.last_price(symbol)

    async def poll_drawing_alerts(self):
        # Independent of the open chart; no requests if there are no enabled alarms.
        while True:
            groups = {}
            for key, drawings in list(self.workshop_drawings.items()):
                fields = key.split("|")
                if len(fields)!=3 or fields[2]=="USD": continue
                source,symbol,period=fields
                if any(isinstance(d,dict) and d.get("alarm") and d.get("alarm_level") is not None for d in drawings):
                    groups.setdefault((source,symbol),[]).append(key)
            for (source,symbol), keys in groups.items():
                try:
                    price = await asyncio.to_thread(self.drawing_quote,source,symbol)
                except Exception:
                    continue
                for key in keys:
                    for i,d in enumerate(self.workshop_drawings.get(key,[])):
                        if not isinstance(d,dict) or not d.get("alarm"): continue
                        level=d.get("alarm_level")
                        if not isinstance(level,(int,float)) or not math.isfinite(level): continue
                        token=(key,i,level)
                        previous=self.drawing_alert_seen.get(token)
                        self.drawing_alert_seen[token]=price
                        if previous is not None and ((previous<level<=price) or (previous>level>=price)):
                            msg = f"Çizim alarmı · {symbol} · {level:g}"
                            self.notice.value = msg
                            self.alarm_history.append({"time": datetime.now().isoformat(), "symbol": symbol, "level": level, "price": price, "key": key})
                            if len(self.alarm_history) > 200:
                                self.alarm_history = self.alarm_history[-200:]
                            try:
                                save_state(self.alarm_history_file, self.alarm_history)
                            except OSError as exc:
                                self.notice.value += f" · Geçmiş kaydedilemedi: {exc}"
                            self.page.update()
                            await self.play_alarm()
            await asyncio.sleep(60)

    def clear_drawings(self, key):
        drawings = self.workshop_drawings.get(key, [])
        if not drawings:
            return
        def confirm(_):
            updated = dict(self.workshop_drawings)
            updated[key] = []
            try:
                save_state(self.workshop_file, updated)
            except OSError as exc:
                self.notice.value = f"Çizimler silinemedi · {exc}"
                self.page.pop_dialog()
                self.page.update()
                return
            drawings.clear()
            if hasattr(self, "drawing_snapshot"):
                self.record_drawing_history()
            self.workshop_tool = "İmleç"
            self.page.pop_dialog()
            self.redraw()
        self.page.show_dialog(ft.AlertDialog(title=ft.Text("Tüm çizimleri sil?"),
            content=ft.Text(f"Bu grafik ve zaman dilimindeki {len(drawings)} çizim kalıcı olarak silinecek."),
            actions=[ft.TextButton(content="Vazgeç", on_click=lambda _: self.page.pop_dialog()),
                     button("Tümünü sil", confirm, RED)]))

    def drawing_objects(self, key):
        drawings = self.workshop_drawings.get(key, [])
        def refresh(index, action):
            if not 0 <= index < len(drawings):
                return
            drawing = drawings[index]
            if not isinstance(drawing, dict):
                drawing = {"tool": "line", "points": list(drawing)}
                drawings[index] = drawing
            if action == "delete":
                if drawing.get("locked"):
                    return
                drawings.pop(index)
            else:
                drawing[action] = not drawing.get(action, False)
            self.persist_drawings()
            self.page.pop_dialog()
            self.redraw()
            self.drawing_objects(key)
        names = {"line": "Çizgi", "frvp": "FVRP", "fib": "Fibonacci", "pen": "Kalem", "text": "Metin", "rectangle": "Dikdörtgen", "circle": "Daire", "channel": "Paralel kanal", "long_position": "Long", "short_position": "Short"}
        rows = []
        for i, drawing in enumerate(drawings):
            d = drawing if isinstance(drawing, dict) else {}
            name = names.get(d.get("tool", "line"), d.get("tool", "Çizgi"))
            rows.append(ft.Row([ft.Text(f"{i+1}. {name}", expand=True),
                ft.TextButton(content="Göster" if d.get("hidden") else "Gizle", on_click=lambda _, j=i: refresh(j, "hidden")),
                ft.TextButton(content="Kilidi aç" if d.get("locked") else "Kilitle", on_click=lambda _, j=i: refresh(j, "locked")),
                ft.IconButton(icon=ft.Icons.DELETE_OUTLINE, tooltip="Sil", disabled=bool(d.get("locked")), on_click=lambda _, j=i: refresh(j, "delete"))]))
        self.page.show_dialog(ft.AlertDialog(title=ft.Text("Çizim nesneleri"),
            content=ft.Container(width=480, height=320, content=ft.Column(rows or [ft.Text("Çizim yok")], scroll=ft.ScrollMode.AUTO)),
            actions=[ft.TextButton(content="Kapat", on_click=lambda _: self.page.pop_dialog())]))

    def open_drawing_properties(self, key, drawing):
        """Properties dialog for a drawing: custom color, 0-100% opacity, style, all-timeframes flag."""
        if not isinstance(drawing, dict):
            return
        if drawing.get("locked"):
            self.notify("Kilitli çizimin önce kilidini açın.")
            return
        style = deepcopy(drawing.get("style", {}))
        color_field = ft.TextField(label="Renk (hex, örn. #FF0000)", value=style.get("color", "#80CFFF"), width=200)
        opacity_slider = ft.Slider(min=0, max=100, value=style.get("opacity", 1) * 100, divisions=100, label="{value}%")
        palette = ft.Row([ft.Container(width=26, height=26, bgcolor=c, on_click=lambda _, color=c: set_color(color)) for c in ("#FFFFFF", "#80CFFF", "#FACC15", "#4ADE80", "#FF7070", "#C4A1FF", "#FB923C", "#758094")], wrap=True)
        def set_color(color):
            color_field.value = color
            color_field.update()
        all_tf = ft.Checkbox(label="Tüm zaman dilimlerinde göster", value=drawing.get("all_timeframes", False))
        def save(_):
            hex_color = (color_field.value or "").strip()
            if hex_color and not hex_color.startswith("#"):
                hex_color = "#" + hex_color
            if len(hex_color) in (4, 7) and all(c in "0123456789ABCDEFabcdef#" for c in hex_color):
                style["color"] = hex_color
            style["opacity"] = max(0, min(1, opacity_slider.value / 100))
            drawing["style"] = style
            drawing["all_timeframes"] = all_tf.value
            self.persist_drawings()
            self.page.pop_dialog()
            self.redraw()
        template_name = ft.TextField(label="Şablon adı", value="Varsayılan", max_length=60)
        template_select = ft.Dropdown(label="Kayıtlı şablonlar", options=[ft.DropdownOption(key=k) for k in self.drawing_style_template.get("templates", {})])
        def save_template(_):
            hex_color = (color_field.value or "").strip().lstrip("#")
            if not re.fullmatch(r"[0-9a-fA-F]{6}", hex_color):
                self.notify("Altı haneli HEX renk girin.")
                return
            template = {**style, "color": "#" + hex_color, "opacity": opacity_slider.value / 100}
            try:
                name = (template_name.value or "").strip()
                if not name:
                    self.notify("Şablon adı girin.")
                    return
                records = deepcopy(self.drawing_style_template)
                records.setdefault("templates", {})[name] = template
                save_state(self.drawing_style_file, records)
                self.drawing_style_template = records
                template_select.options = [ft.DropdownOption(key=k) for k in records["templates"]]
                template_select.value = name
                self.page.update()
                self.notify("Çizim stil şablonu kaydedildi.")
            except OSError as exc:
                self.notify(f"Şablon kaydedilemedi · {exc}")
        def manage_template(rename):
            old = template_select.value
            new = (template_name.value or "").strip()
            records = deepcopy(self.drawing_style_template)
            templates = records.get("templates", {})
            if old not in templates:
                self.notify("Bir şablon seçin.")
                return
            if rename:
                if not new or (new in templates and new != old):
                    self.notify("Benzersiz bir şablon adı girin.")
                    return
                templates[new] = templates.pop(old)
            else:
                templates.pop(old)
            try:
                save_state(self.drawing_style_file, records)
            except OSError as exc:
                self.notify(f"Şablon güncellenemedi · {exc}")
                return
            self.drawing_style_template = records
            template_select.options = [ft.DropdownOption(key=k) for k in templates]
            template_select.value = new if rename else None
            self.page.update()
        def load_template(_):
            template = self.drawing_style_template.get("templates", {}).get(template_select.value or (template_name.value or "").strip(), {})
            if not isinstance(template, dict) or not template:
                self.notify("Kayıtlı stil şablonu yok.")
                return
            style.clear()
            style.update(deepcopy(template))
            color_field.value = style.get("color", "#80CFFF")
            opacity_slider.value = max(0, min(100, style.get("opacity", 1)*100))
            self.page.update()
        self.page.show_dialog(ft.AlertDialog(
            title=ft.Text("Çizim özellikleri"),
            content=ft.Column([color_field, palette, ft.Text("Opaklık %0–100"), opacity_slider, all_tf, template_name, template_select, ft.Row([ft.TextButton(content="Stili şablon olarak kaydet", on_click=save_template), ft.TextButton(content="Şablonu yükle", on_click=load_template), ft.TextButton(content="Yeniden adlandır", on_click=lambda _: manage_template(True)), ft.TextButton(content="Şablonu sil", on_click=lambda _: manage_template(False))], wrap=True)], tight=True),
            actions=[ft.TextButton(content="Vazgeç", on_click=lambda _: self.page.pop_dialog()),
                     ft.TextButton(content="Kaydet", on_click=save)]
        ))

    def export_alarm_history(self, _=None):
        rows = [{"Tarih": h.get("time", ""), "Sembol": h.get("symbol", ""),
                 "Alarm seviyesi": h.get("level", ""), "Fiyat": h.get("price", ""),
                 "Grafik": h.get("key", "")} for h in self.alarm_history if isinstance(h, dict)]
        self.export(rows)

    def alarm_management(self):
        """Panel listing active drawing alarms and history."""
        active = []
        for key, drawings in self.workshop_drawings.items():
            parts = key.split("|")
            symbol = parts[1] if len(parts) > 1 else key
            for i, d in enumerate(drawings):
                if isinstance(d, dict) and d.get("alarm") and d.get("alarm_level") is not None:
                    active.append(ft.Row([
                        ft.Text(f"{symbol} · {d['alarm_level']:g}", expand=True),
                        ft.TextButton(content="Kapat", on_click=lambda _, k=key, idx=i: self._toggle_alarm(k, idx, False))
                    ]))
        history_rows = [ft.Text(f"{h['time'][:19]} · {h['symbol']} · {h['level']:g} (fiyat {h['price']:g})") for h in reversed(self.alarm_history[-30:])]
        self.page.show_dialog(ft.AlertDialog(
            title=ft.Text("Alarm yönetimi"),
            content=ft.Container(width=500, height=400, content=ft.Column([
                ft.Text("Aktif alarmlar", weight=ft.FontWeight.BOLD),
                *(active or [ft.Text("Aktif alarm yok")]),
                ft.Divider(),
                ft.Text("Alarm geçmişi", weight=ft.FontWeight.BOLD),
                *(history_rows or [ft.Text("Geçmiş yok")])
            ], scroll=ft.ScrollMode.AUTO)),
            actions=[ft.TextButton(content="CSV dışa aktar", on_click=self.export_alarm_history, disabled=not self.alarm_history), ft.TextButton(content="Kapat", on_click=lambda _: self.page.pop_dialog())]
        ))

    def _toggle_alarm(self, key, index, enable):
        drawings = self.workshop_drawings.get(key, [])
        if 0 <= index < len(drawings) and isinstance(drawings[index], dict):
            drawings[index]["alarm"] = enable
            self.persist_drawings()
        self.page.pop_dialog()
        self.alarm_management()

    def price_levels(self, row):
        colors = {"Giris": ACCENT, "Stop": RED, "TP1": GREEN, "TP2": GREEN, "TP3": GREEN,
                  "VAL": ACCENT, "POC": YELLOW, "VAH": ACCENT, "Hedef": GREEN}
        if self.graph_tf == "USD":
            return []
        return [(name, row[name], color) for name, color in colors.items()
                if isinstance(row.get(name), (float, int)) and math.isfinite(row[name]) and row[name] > 0]

    def compact_action(self, icon, caption, description, callback=None, active=False, disabled=False, url=None):
        width = getattr(self.page, "width", None)
        color = ACCENT if active else FG
        if isinstance(width, (int, float)) and width < 1100:
            return ft.IconButton(icon=icon, tooltip=description, on_click=callback, url=url, disabled=disabled,
                                 icon_size=17, width=32, height=32, padding=4, icon_color=color)
        return ft.TextButton(content=ft.Text(caption, size=11), icon=icon, tooltip=description,
                             on_click=callback, url=url, disabled=disabled, height=32,
                             style=ft.ButtonStyle(color=color, icon_size=15,
                                                  padding=ft.Padding.symmetric(horizontal=5)))

    def workshop(self, row, bars, start, window, marks, quick_actions, readout=None):
        key = f"{row['source']}|{row['Sembol']}|{self.graph_tf}"
        self.last_chart_key = key
        drawings = self.workshop_drawings.setdefault(key, [])
        shared_sources = {}
        shared = project_drawings(self.workshop_drawings, key, bars, sources=shared_sources)
        segments = []
        if self.pivot_period != "Kapalı":
            segments = pivots(bars, self.pivot_period)
        overlays = [(data, color) for _, data, color in self.ema_lines(bars)]
        if self.indicators["VWAP"] or self.indicators["VWAP bantları"]:
            detail = row.get("detail")
            key_vwap = "usp" if self.graph_tf == "USD" else "tlsp"
            if row["source"] == "evre" and self.graph_tf in ("USD", "1D") and detail and key_vwap in detail:
                result = detail[key_vwap]
            else:
                result = ev.spiral(bars)
            visible = result
            overlays.append(([v for v, _ in visible], YELLOW))
            if self.indicators["VWAP bantları"]:
                for factor in (-2, -1, 1, 2):
                    overlays.append(([v + factor * sd for v, sd in visible],
                                     RED if factor < 0 else ACCENT))
                for factor in (-4, -3, 3, 4):
                    # Geniş bantlar otomatik fiyat ölçeğini bozmasın diye ölçeğe katılmaz.
                    overlays.append(([v + factor * sd for v, sd in visible],
                                     "#FF8A80" if factor < 0 else "#80D8FF", False))
        focus = next((i for i, bar in enumerate(bars) if bar[0] == self.graph_focus), None)

        def remember_view(left, count):
            self.chart_span = count
            base = focus - count // 2 if focus is not None else max(0, len(bars) - count)
            self.chart_shift = left - base

        def commit_shared(drawing, before):
            original = shared_sources.get(id(drawing))
            if original is not None and commit_projection(original, before, drawing):
                self.persist_drawings()
        chart = Workshop(bars, self.price_levels(row) if self.show_trade_plan else [], segments, overlays, drawings,
                         self.workshop_tool, height=self.chart_height(),
                         on_change=self.persist_drawings, on_finish=self.finish_drawing, marks=marks, focus=self.graph_focus,
                         start=start, span=self.chart_span, on_view=remember_view, fit_levels=self.fit_chart_levels,
                         price_range=self.price_ranges.get(key),
                         accumulation_line=self.indicators["Akümülasyon"],
                         visible_volume=self.indicators["Görünür hacim"],
                         on_range=lambda value: self.remember_price_range(key, value),
                         note_at=lambda point: self.chart_note(key, point), readout=readout, watermark=row.get("Sembol"),
                         on_properties=lambda drawing: self.open_drawing_properties(key, shared_sources.get(id(drawing), drawing)), shared_drawings=shared, on_shared_edit=commit_shared)
        self.active_workshop = chart
        history_available = (row["source"] in ("bist", "dip", "memory")
                             and self.graph_tf == "1D" and not self.chart_is_report)
        def toggle_levels(_):
            self.fit_chart_levels = not self.fit_chart_levels
            if self.fit_chart_levels:
                self.price_ranges.pop(key, None)
            self.redraw()

        quick_actions.controls.extend([
            self.compact_action(ft.Icons.MENU, "Nesneler", "Çizim nesne listesi", lambda _: self.drawing_objects(key)),
            self.compact_action(ft.Icons.NOTIFICATIONS, "Alarmlar", "Alarm yönetim paneli ve geçmiş", lambda _: self.alarm_management()),
            self.compact_action(ft.Icons.DELETE_OUTLINE, "Tüm çizimleri sil", "Bu grafikteki tüm çizimleri sil", lambda _: self.clear_drawings(key), disabled=not drawings),
            self.compact_action(ft.Icons.UNDO, "Geri al", "Son çizimi geri al", lambda _: self.undo_drawing(key)),
            self.compact_action(ft.Icons.RESTART_ALT, "Ölçeği sıfırla", "Fiyat ölçeğini sıfırla",
                           lambda _: self.reset_price_range(key)),
            self.compact_action(ft.Icons.OPEN_IN_FULL, "Küçült" if self.workshop_large else "Büyüt",
                           "Grafiği küçült" if self.workshop_large else "Grafiği büyüt", self.workshop_size),
            self.compact_action(ft.Icons.HISTORY, "BIST geçmişi", "Tüm BIST geçmişini al", self.load_full_chart,
                           disabled=not history_available),
            self.compact_action(ft.Icons.FIT_SCREEN, "Seviyeleri sığdır",
                           "Seviyeleri ölçeğe sığdır · " + ("Açık" if self.fit_chart_levels else "Kapalı"),
                           toggle_levels, active=self.fit_chart_levels),
        ])
        def select_tool(tool):
            self.workshop_tool = tool
            self.redraw()

        quick_actions.controls.extend([
            self.compact_action(ft.Icons.REDO, "İleri al", "Çizimi ileri al", lambda _: self.restore_drawing_history(key, True)),
            self.compact_action(ft.Icons.STAR_OUTLINE, "Favori araçlar", "Favori araçları düzenle", lambda _: self.favorite_drawing_dialog()),
        ])
        rail = ft.Column([
            ft.TextButton(content=ft.Text("★ " + name, size=10), tooltip=name,
                on_click=lambda _, tool=name: select_tool(tool)) for name in self.favorite_tools] + [
            ft.PopupMenuButton(
                content=ft.Container(content=ft.Text(group, size=10, color=FG),
                    bgcolor=SELECTED_ROW if self.workshop_tool in names else PANEL,
                    padding=5, width=75),
                items=[ft.PopupMenuItem(content=name, on_click=lambda _, tool=name: select_tool(tool))
                       for name in names])
            for group, names in DRAW_GROUPS.items()
        ], spacing=2, scroll=ft.ScrollMode.AUTO)
        pivot_notice = [label("Seçilen dönem için yeterli geçmiş yok.")] if (
            self.pivot_period != "Kapalı" and not segments
        ) else []
        return [
            *pivot_notice,
            ft.Row([rail, ft.Container(chart.control, expand=True)], spacing=0, expand=True, vertical_alignment=ft.CrossAxisAlignment.STRETCH),
        ]

    def graph_view(self):
        row = self.chart_row
        if not row:
            return [label("Grafiği açmak için bir sonuç kartına dokun.")]
        currency = "USDT" if row["source"] == "futures" else "USD" if self.graph_tf == "USD" else "₺"
        periods = ["5m", "15m", "1h", "4h", "1d", "1w"]
        crypto = row["source"] in ("tr", "futures")
        if row["source"] == "evre" and row.get("detail", {}).get("usd_series"):
            periods.append("USD")
        symbol = row["Sembol"]
        search = ft.TextField(label="BIST hisse kodu", width=124, dense=True, hint_text="THYAO")

        def open_symbol(_):
            code = (search.value or "").strip().upper()
            if code not in market.BIST_CATALOG:
                search.error_text = "Kodu kontrol et"
                self.page.update()
                return
            self.open_chart({"Sembol": code, "source": "bist", "direct_chart": True})

        search.on_submit = open_symbol
        search.on_focus = lambda _: setattr(self, "chart_search_focused", True)
        search.on_blur = lambda _: setattr(self, "chart_search_focused", False)
        fields = [search, ft.IconButton(icon=ft.Icons.SEARCH, tooltip="Hisse grafiğini aç",
                                                  on_click=open_symbol)]
        self.chart_header.controls = []
        controls = []
        if self.graph_status:
            controls.append(label(self.graph_status))
        trade_items = []
        quick_actions = ft.Row(spacing=2, scroll=ft.ScrollMode.AUTO, expand=True)
        for caption in periods:
            period = caption if crypto or caption.endswith("m") else caption.upper()
            selected = period == self.graph_tf
            quick_actions.controls.append(ft.TextButton(
                content=ft.Text(caption, size=10, weight=ft.FontWeight.W_600,
                                color="#FFFFFF" if selected else FG),
                width=34, height=26,
                style=ft.ButtonStyle(bgcolor=SELECTED_ROW if selected else PANEL, padding=0),
                on_click=lambda _, value=period: self.set_tf(value),
            ))
        market_label = ft.Text(f"{SOURCES[row['source']]} · {currency}", size=10, color=MUTED,
                               weight=ft.FontWeight.W_600, text_align=ft.TextAlign.RIGHT, no_wrap=True)
        chart_bar = ft.Row([search, ft.IconButton(icon=ft.Icons.SEARCH, tooltip="Hisse grafiğini aç",
                        on_click=open_symbol), quick_actions, market_label], spacing=6, vertical_alignment=ft.CrossAxisAlignment.CENTER)
        if row["source"] != "tr" and symbol.isalnum():
            ticker = f"BINANCE:{symbol}.P" if row["source"] == "futures" else f"BIST:{symbol}"
            quick_actions.controls.append(self.compact_action(ft.Icons.OPEN_IN_NEW, "TradingView", "TradingView’de aç",
                                          url="https://www.tradingview.com/chart/?" + urlencode({"symbol": ticker, "interval": {"5m": "5", "15m": "15", "1h": "60", "4h": "240", "1d": "D", "1w": "W", "usd": "D"}[self.graph_tf.lower()]})))
        bars = self.graph_bars
        focus_caption = "Tam ekrandan çık" if self.chart_focus else "Tam ekran"
        view_caption = "Basit görünüm" if self.workshop_enabled else "Etkileşimli grafik"
        quick_actions.controls.extend([
            self.compact_action(ft.Icons.FULLSCREEN_EXIT if self.chart_focus else ft.Icons.FULLSCREEN,
                                focus_caption, focus_caption, self.toggle_chart_focus, disabled=not (bars or self.chart_focus)),
            self.compact_action(ft.Icons.SHOW_CHART, view_caption, view_caption, self.toggle_workshop, disabled=not bars),
            self.compact_action(ft.Icons.ADD_SHOPPING_CART, "Sanal AL", "Sanal AL", lambda _: self.trade_dialog(row, "LONG"),
                                disabled=row.get("Fiyat") is None),
        ])
        if row.get("Fiyat") is not None and row["source"] == "futures":
            trade_items.append(("Sanal SHORT", lambda _: self.trade_dialog(row, "SHORT")))
        for trade in self.trades:
            if trade.get("Sembol") == symbol and trade.get("Durum") == "AÇIK":
                caption = "Sanal SAT" if trade["Tür"] == "LONG" else "SHORT kapat"
                trade_items.append((f"{caption} · {trade['Miktar']:g} @ {trade['Giris']:g}",
                                      lambda _, position=trade: self.close_trade(position)))
        levels = [ft.Text(f"{'Giriş' if name == 'Giris' else name} {row[name]} {currency}",
                          size=11, color=RED if name == "Stop" else FG, no_wrap=True)
                  for name in ("Giris", "Stop", "TP1", "TP2", "TP3", "VAL", "POC", "VAH", "Hedef")
                  if row.get(name) is not None and self.graph_tf != "USD"]
        readout = ft.Text(size=11, color=FG, no_wrap=True)
        plan_toggle = ft.Checkbox(label="İşlem planı", value=self.show_trade_plan,
                                  disabled=not levels, height=28,
                                  on_change=lambda event: self.workshop_option("show_trade_plan", event))
        visible_levels = levels if self.show_trade_plan else []
        footer = ft.Row([readout, plan_toggle, *visible_levels],
                        spacing=10, scroll=ft.ScrollMode.AUTO)
        if not bars:
            quick_actions.controls.extend(button(name, callback, RED) for name, callback in trade_items)
            controls.append(chart_bar)
            if levels:
                controls.append(footer)
        if bars:
            focus = next((i for i, bar in enumerate(bars) if bar[0] == self.graph_focus), None)
            span = self.chart_span
            last = max(0, len(bars) - span)
            base = focus - span // 2 if focus is not None else last
            start = (clamp_view_start(base + self.chart_shift, len(bars), span) if self.workshop_enabled
                     else max(0, min(base + self.chart_shift, last)))
            window = bars[max(0, start):start + span]
            lo, hi = min(b[3] for b in window), max(b[2] for b in window)
            pad = max((hi - lo) * 0.07, abs(hi) * 0.001, 0.000001)
            marks = {day: name for name, day in row.get("detail", {}).get("marks", {}).items()} \
                if isinstance(row.get("detail"), dict) else {}
            if row["source"] == "evre" and not self.chart_is_report and self.graph_tf in ("USD", "1D"):
                marks.update({item["date"]: item["status"] for item in early_liftoff_signals(bars)})
            key = (row["source"], row["Sembol"], self.graph_tf)
            marks.update({day: "Kullanıcı işareti" for day in self.user_marks.get(key, ())})
            if row["source"] == "memory" and self.graph_tf == "1D":
                events = self.memory_marks()
                marks.update(events)
                quick_actions.controls.append(self.memory_event_menu(events, bars))
            readout.value = f"{window[0][0]} — {window[-1][0]}   Hacim {window[-1][5]:.5g}"
            primary = self.workshop(row, bars, start, window, marks, quick_actions, readout) if self.workshop_enabled else [
                charts.CandlestickChart(
                    spots=[charts.CandlestickChartSpot(i, o, h, low, c, selected=day == self.graph_focus or day in marks,
                                                       tooltip=f"{day}\nA {o:g} · Y {h:g}\nD {low:g} · K {c:g}\nHacim {v:g}"
                                                       + (f"\n{marks[day]}" if day in marks else ""))
                           for i, (day, o, h, low, c, v) in enumerate(window)],
                    min_y=lo - pad, max_y=hi + pad,
                    on_event=lambda event: self.chart_mark(event, window, key),
                )]
            primary[-1] = ft.Stack([
                primary[-1],
                ft.Container(content=self.chart_indicator_menu(trade_items), top=4,
                             left=38 if self.workshop_enabled else 4),
            ], fit=ft.StackFit.EXPAND, expand=True)
            chart_panel = panel([
                chart_bar, *primary, footer,
                *([] if self.workshop_enabled else [self.volume_chart(window)]),
            ])
            chart_panel.data = "chart-panel"
            chart_panel.expand = True
            chart_panel.content.expand = True
            chart_panel.content.tight = False
            controls.append(chart_panel)
            if self.chart_focus:
                chart_panel.padding = 4
            if not self.workshop_enabled:
                indicator = self.indicator_chart(bars, start, len(window))
                if indicator is not None:
                    controls.append(indicator)
            if self.chart_focus:
                return controls
            if row["source"] == "evre" and self.graph_tf in ("USD", "1D"):
                peak_day = row["detail"]["peak"]
                profile_bars = [bar for bar in bars if bar[0] >= peak_day]
                if profile_bars:
                    controls.append(self.profile_view(profile_bars))
            elif self.chart_is_report and row.get("VAL") is not None:
                controls.append(self.profile_view(bars))
        if row.get("detail"):
            detail = row["detail"]
            if isinstance(detail, dict):
                fields = dict(detail)
                for name in ("series", "usd_series", "tlsp", "usp", "bars"):
                    fields.pop(name, None)
                controls.append(ft.ExpansionTile(title=label("V39 analiz ayrıntıları"),
                                                  controls=[label(f"{k} · {v}") for k, v in fields.items()]))
            else:
                controls.append(ft.ExpansionTile(title=label("Dip olayları"),
                                                  controls=[label(str(v)) for v in detail]))
        return controls

    def trade_dialog(self, row, side):
        fields = {key: ft.TextField(label=title, value=str(row[key]) if row.get(key) is not None else "")
                  for key, title in (("Miktar", "Miktar"), ("Giris", "Giriş fiyatı"), ("Stop", "Stop"),
                                     ("TP2", "TP2"), ("TP3", "TP3"))}
        fields["Giris"].value = str(row.get("Giris") or row["Fiyat"])
        leverage = ft.TextField(label="Kaldıraç", value=str(int(tc.BINANCE_MAX_LEVERAGE)))
        message = label("", RED)

        def confirm(_):
            try:
                numbers = {key: float(f.value.replace(",", ".")) if f.value.strip() else None
                           for key, f in fields.items()}
                qty, price = numbers["Miktar"], numbers["Giris"]
                if qty is None or price is None or not all(math.isfinite(v) for v in numbers.values() if v is not None):
                    raise ValueError("Geçerli miktar ve fiyat gir.")
                if tc.is_bist_symbol(row["Sembol"]) and qty < 1:
                    raise ValueError("BIST miktarı en az bir lot olmalı.")
                lev = int(leverage.value) if row["source"] == "futures" else 1
                if not 1 <= lev <= tc.BINANCE_MAX_LEVERAGE and row["source"] == "futures":
                    raise ValueError("Kaldıraç ayarlardaki sınırı aşıyor.")
                updated = list(self.trades)
                trade = tc.open_virtual_trade(updated, row["Sembol"], side, price, qty, numbers["Stop"],
                                              numbers["TP2"], numbers["TP3"], lev)
                trade.update(TP1=row.get("TP1"), TP2=numbers["TP2"], TP3=numbers["TP3"])
                save_state(tc.TRADES_FILE, updated)
                self.trades = updated
            except (ValueError, OSError) as exc:
                message.value = str(exc)
                self.page.update()
                return
            self.page.pop_dialog()
            self.show("İşlemler")

        self.page.show_dialog(ft.AlertDialog(
            title=ft.Text(f"Sanal {side} · {row['Sembol']}"),
            content=ft.Column([*fields.values(), *([leverage] if row["source"] == "futures" else []), message],
                              tight=True, scroll=ft.ScrollMode.AUTO),
            actions=[ft.TextButton(content="Vazgeç", on_click=lambda _: self.page.pop_dialog()),
                     button("Onayla", confirm)],
        ))

    def trade_view(self):
        balance = tc.tr_spot_available_tl(self.trades, tc.CAPITAL_TL)
        return [panel([label(f"Kullanılabilir sanal bakiye {balance:,.2f} ₺", GREEN),
                       button("Fiyatları yenile", self.refresh_prices)]),
                *self.cards(reversed(self.trades), self.trade_card)]

    def trade_card(self, trade):
        opened = trade["Durum"] == "AÇIK"
        price = self.prices.get(trade["Sembol"])
        pnl = tc.calc_pnl(trade, price) if opened else trade.get("KZ")
        color = MUTED if not pnl else GREEN if pnl > 0 else RED
        controls = [label(f"{trade['Sembol']} · {trade['Tür']} · {trade['Durum']}", FG),
                    label(f"Giriş {trade['Giris']} · {trade['Miktar']} adet · {trade['Para']}"),
                    label(f"Güncel fiyat {price if price is not None else '—'}"),
                    label(f"K/Z {pnl if pnl is not None else '—'} {trade['Para']}", color)]
        if opened:
            controls.append(button("Sanal işlemi kapat", lambda _: self.close_trade(trade), RED))
        return panel(controls)

    def refresh_prices(self, _):
        symbols = {trade["Sembol"] for trade in self.trades if trade["Durum"] == "AÇIK"}
        self.prices.clear()
        self.notify("Fiyatlar alınıyor…" if symbols else "Açık sanal işlem yok.")

        def work():
            prices = tc.fetch_prices(symbols)
            self.messages.put(("portföy", "prices", prices))
            self.messages.put(("portföy", "notice", f"{len(prices)}/{len(symbols)} fiyat alındı."))
        if symbols:
            threading.Thread(target=work, daemon=True).start()

    def close_trade(self, trade):
        symbol = trade["Sembol"]
        self.notify(f"{symbol} için kapanış fiyatı alınıyor…")

        def work():
            price = tc.fetch_prices([symbol]).get(symbol)
            if price is None:
                self.messages.put(("portföy", "notice", "Fiyat alınamadı · sanal işlem açık."))
            else:
                self.messages.put(("portföy", "close", (trade, price)))

        threading.Thread(target=work, daemon=True).start()

    # ------------------------------------------------------------------ güncelleme
    def save_update_url(self, _=None):
        try:
            save_state(self.update_config_file, {"manifest_url": self.update_url.value.strip()})
        except OSError as exc:
            self.update_note = f"Adres kaydedilemedi · {exc}"

    def start_update_check(self, quiet=False):
        url = self.update_url.value.strip()
        if not url or self.update_busy:
            if not quiet and not url:
                self.update_note = "Önce GitHub yayın kanalını veya HTTPS manifest adresini girip denetleyin."
                self.redraw()
            return
        self.update_busy = True
        self.update_info = None
        if not quiet:
            self.update_note = "Denetleniyor…"
            self.redraw()

        def work():
            try:
                info = updater.check_chatgpt_channel(url, APP_VERSION)
                self.messages.put(("guncelleme", "found", dict(info, quiet=quiet)))
            except Exception as exc:
                self.messages.put(("guncelleme", "error", None if quiet else str(exc)))

        threading.Thread(target=work, daemon=True).start()

    def check_update_click(self, _):
        self.save_update_url()
        self.start_update_check(quiet=False)

    def scan_local_updates(self, _=None, announce=True):
        folders = [updater.APP_DIR / "guncelleme", Path.home() / "Downloads", updater.APP_DIR.parent]

        def work():
            found = updater.find_local_updates(folders, APP_VERSION)
            self.messages.put(("guncelleme", "local", {"items": found, "announce": announce}))

        threading.Thread(target=work, daemon=True).start()

    def scan_local_click(self, _):
        self.update_note = "Klasörler taranıyor…"
        self.scan_local_updates(announce=False)
        self.redraw()

    def run_update(self, task, note):
        if self.update_busy:
            return
        self.update_busy = True
        self.update_progress.value = 0
        self.update_note = note
        self.redraw()

        def work():
            try:
                self.messages.put(("guncelleme", "applied", task()))
            except Exception as exc:
                self.messages.put(("guncelleme", "error", str(exc)))

        threading.Thread(target=work, daemon=True).start()

    def backups(self):
        return self.data_folder / "kod_yedekleri"

    def install_update(self, _):
        info = self.update_info
        if not info or not info.get("available"):
            return

        def task():
            return updater.install_checked_release(
                info, APP_VERSION, self.data_folder / "indirilen" / "guncelleme.zip",
                lambda fraction: self.messages.put(("guncelleme", "progress", fraction)),
                backup_dir=self.backups())

        self.run_update(task, f"v{info['version']} indiriliyor…")

    def apply_local(self, path):
        path = str(path or "").strip().strip('"')
        if not path:
            self.update_note = "ZIP dosyasının yolunu yazın veya listeden seçin."
            self.redraw()
            return

        def task():
            _, version = updater.inspect_zip(path)
            if not updater.is_newer(version, APP_VERSION):
                raise updater.UpdateError(f"ZIP sürümü v{version}; kurulu v{APP_VERSION}. Yeni sürüm değil.")
            return updater.apply_zip(path, backup_dir=self.backups())

        self.run_update(task, "ZIP uygulanıyor…")

    def rollback_update(self, _):
        self.run_update(lambda: updater.rollback_latest(backup_dir=self.backups()), "Önceki sürüme dönülüyor…")

    def update_event(self, event, data):
        if event == "found":
            self.update_busy = False
            self.update_info = data
            if data["available"]:
                notes = f"\n{data['notes']}" if data.get("notes") else ""
                self.update_note = f"Yeni sürüm var: v{data['version']} (kurulu v{APP_VERSION}).{notes}"
                self.notice.value = f"Yeni sürüm v{data['version']} var · Güncelleme sekmesinden yükleyin"
            elif not data.get("quiet"):
                self.update_note = f"Güncelsiniz. Kurulu v{APP_VERSION}, son sürüm v{data['version']}."
        elif event == "local":
            self.update_local = data["items"]
            if data["items"] and data["announce"] and not self.notice.value:
                self.notice.value = f"Bilgisayarda yeni sürüm ZIP'i bulundu: v{data['items'][0]['version']} · Güncelleme sekmesi"
            elif not data["announce"]:
                self.update_note = ("Yeni sürüm ZIP'i bulundu." if data["items"]
                                    else "Klasörlerde yeni sürüm ZIP'i bulunamadı.")
        elif event == "progress":
            self.update_progress.value = data
        elif event == "note":
            self.update_note = data
        elif event == "error":
            self.update_busy = False
            if data:
                self.update_note = f"Hata · {data}"
        elif event == "applied":
            self.update_progress.value = 1.0
            self.update_info = None
            action = "Geri alındı" if data.get("rollback") else "Güncellendi"
            line = f"{action}: v{data['old']} → v{data['new']}."
            if data.get("requirements_changed") and os.environ.get("PIYASA_LAUNCHER") != "1":
                self.update_note = (line + " Gereksinimler değişti: önce `pip install -r requirements.txt` çalıştırıp "
                                    "uygulamayı yeniden açın.")
                self.update_busy = False
                return
            self.update_note = line + " Uygulama yeniden başlatılıyor…"
            self.page.run_task(self.restart_after_update)

    async def restart_after_update(self):
        await asyncio.sleep(2)
        updater.restart()

    def update_view(self):
        info = self.update_info
        bar = self.update_progress
        bar.color, bar.bgcolor, bar.bar_height = RUN_ORANGE, "#2A3350", 8
        if self.update_busy and not bar.value:
            bar.value = None
        percent = "…" if bar.value is None else f"%{round(bar.value * 100)}"
        last_backup = updater.latest_backup(self.backups())
        found = [ft.Row([label(f"v{item['version']} · {item['path']}"),
                         button(f"v{item['version']} uygula", lambda _, path=item["path"]: self.apply_local(path),
                                GREEN)], wrap=True) for item in self.update_local]
        return [
            panel([label("Sürüm", FG), label(f"Kurulu sürüm: v{APP_VERSION}"),
                   label(f"Program klasörü: {updater.APP_DIR}"),
                   label(f"Veri klasörü: {self.data_folder} · güncellemede ve geri almada korunur")]),
            panel([
                label("ChatGPT sürümleri · GitHub / HTTPS yayın kanalı", FG),
                label("ChatGPT sohbeti doğrudan sorgulanmaz. Yeni ZIP yayın kanalına yüklenince burada bulunur."),
                ft.Row([self.update_url]),
                ft.Row([button("ChatGPT’den Güncellemeyi Denetle", self.check_update_click, ACCENT),
                        *([button(f"v{info['version']} sürümüne güncelle ve yeniden başlat", self.install_update, GREEN)]
                          if info and info.get("available") else [])], wrap=True),
            ]),
            panel([
                label("ZIP dosyasından güncelleme · internet gerekmez, sanal ortam yeniden kurulmaz", FG),
                label("Yeni ZIP'i Downloads klasöründe bırakın veya programın guncelleme klasörüne koyun."),
                ft.Row([self.update_zip]),
                ft.Row([button("Yerel güncellemeleri ara", self.scan_local_click, ACCENT),
                        button("Bu ZIP'ten güncelle", lambda _: self.apply_local(self.update_zip.value), RUN_ORANGE)],
                       wrap=True),
                *found,
            ]),
            panel([
                ft.Row([ft.Container(bar, expand=True),
                        ft.Text(percent, size=12, weight=ft.FontWeight.BOLD, color=FG, width=44,
                                text_align=ft.TextAlign.RIGHT)],
                       spacing=8, vertical_alignment=ft.CrossAxisAlignment.CENTER),
                label(self.update_note or "Hazır"),
            ]),
            panel([label("Geri alma", FG),
                   label(f"Son yedek: {last_backup.name}" if last_backup else "Yedek yok. Her güncellemeden önce otomatik alınır."),
                   ft.Row([button("Önceki sürüme dön", self.rollback_update, RED if last_backup else MUTED)])]),
        ]

    def settings_view(self):
        return [
            panel([label("Sanal portföy ve risk", FG), form_grid(list(self.settings.values())),
                   ft.Row([button("Kaydet", self.save_settings),
                           button("Güncelleme", lambda _: self.show("Güncelleme"), RUN_ORANGE)])]),
        ]

    def save_settings(self, _):
        try:
            values = {key: float(field.value.replace(",", ".")) for key, field in self.settings.items()}
            if not all(0 < x < math.inf for x in values.values()):
                raise ValueError("Ayarlar pozitif sayı olmalı.")
            save_state(tc.SETTINGS_FILE, values)
        except (ValueError, OSError) as exc:
            self.notify(str(exc))
            return
        for key, value in values.items():
            setattr(tc, key, value)
        self.notify("Ayarlar kaydedildi.")


def main(page):
    PiyasaMobile(page)


def run_app(argv=None):
    import argparse
    parser = argparse.ArgumentParser(description="Piyasa Terminali")
    parser.add_argument("--web", action="store_true", help="Pencere yerine tarayıcıda aç")
    parser.add_argument("--lan", action="store_true", help="Web arayüzünü yerel ağdaki cihazlara aç (şifre yoktur)")
    parser.add_argument("--port", type=int, default=8550, help="Web arayüzü portu (varsayılan 8550)")
    args = parser.parse_args(argv)
    assets = str(Path(__file__).with_name("assets"))
    if not args.web:
        ft.run(main, assets_dir=assets)
        return
    host = "0.0.0.0" if args.lan else "127.0.0.1"
    print(f"Web arayüzü: http://localhost:{args.port}" + ("  (ağdaki diğer cihazlar için bu bilgisayarın IP adresini kullanın)"
                                                          if args.lan else ""))
    # Use Flet's explicit browser mode; None can select desktop mode.
    ft.run(main, view=ft.AppView.WEB_BROWSER, host=host, port=args.port, assets_dir=assets)


if __name__ == "__main__":
    run_app()
