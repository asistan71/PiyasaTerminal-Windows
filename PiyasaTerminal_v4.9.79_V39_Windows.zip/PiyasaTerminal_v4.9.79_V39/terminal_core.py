# -*- coding: utf-8 -*-
"""Piyasa Terminali — Android çekirdeği (arayüzsüz).

Bu dosya Piyasa_Terminali_v23_5_Evre.py içindeki BIST puanlama, Binance (USDT
vadeli + TR spot) tarama ve sanal işlem fonksiyonlarının Tkinter'siz kopyasıdır.
Fonksiyon gövdeleri AST ile aynen alınmıştır; yalnızca veri kaynağı
(borsapy -> data_provider) ve dosya yolu değişmiştir.
"""
from __future__ import annotations
import csv, json, time, threading
from datetime import datetime
from decimal import Decimal, ROUND_DOWN, ROUND_UP, ROUND_HALF_UP
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from market import bist_symbols
import data_provider
try:
    import requests
except Exception:
    requests = None

bp = True  # borsapy yerine data_provider kullanılır (aşağıda fetch_* yeniden tanımlı)
DATA_DIR = Path(".")
from v49_indicators import obv_analysis, deep_volume_analysis

def set_data_dir(p):
    global DATA_DIR, BIST_CSV, BINANCE_CSV, FAV_FILE, TRADES_FILE, SETTINGS_FILE
    DATA_DIR = Path(p); DATA_DIR.mkdir(parents=True, exist_ok=True)
    BIST_CSV = DATA_DIR / "bist_tarama_sonuclari.csv"; BINANCE_CSV = DATA_DIR / "binance_tarama_sonuclari.csv"
    FAV_FILE = DATA_DIR / "favoriler.json"; TRADES_FILE = DATA_DIR / "sanal_islemler.json"; SETTINGS_FILE = DATA_DIR / "ayarlar.json"
set_data_dir(Path.home() / ".piyasa_terminali")

CAPITAL_TL = 100000.0
BIST_RISK_PERCENT = 2.0
BIST_MIN_PCT = 61
BIST_CONFIRMED_PCT = 78
BIST_LIVE_INTERVAL = 60
BIST_WORKERS = 6
BINANCE_CAPITAL_USDT = 80.0
BINANCE_RISK_PERCENT = 2.0
BINANCE_MAX_LEVERAGE = 1.0
BINANCE_WORKERS = 8
BINANCE_LIVE_INTERVAL = 45
BINANCE_MIN_VOLUME = 20_000_000
BINANCE_MAX_COINS = 100
BINANCE_EARLY_SCORE = 70
BINANCE_CONFIRMED_SCORE = 80
BINANCE_STRUCTURE_LOOKBACK = 20
BINANCE_ATR_BUFFER = 0.10
BINANCE_BTC_CHANGE_LIMIT = 0.5
HTTP_TIMEOUT = 15
BINANCE_MAX_COINS_NOFILTER = 200
FILTERS_OFF = {"BIST": False, "BINANCE": False}
_bist_cache = {}
_bist_cache_lock = threading.Lock()
BIST_WEIGHTS = {"1W": 30, "1D": 25, "1H": 25}
_binance_thread = threading.local()
BINANCE_BASE_URL = "https://fapi.binance.com"
SYMBOL_FILTERS = {}
TR_TYPES = {}
_binance_kline_cache = {}
_binance_cache_lock = threading.Lock()
BINANCE_FIELDS = ["Tarih","Sembol","Sinyal","Yon","Puan","LONG","SHORT","Fiyat","Degisim24h","RSI","RVOL","5m","15m","1h","BTC_Modu",
                  "BTC_15m","BTC_1h","BTC_4h","BTC_Uyum","BTC_4H_Degisim","Hacim","PlanDurumu","Giris","Stop","RiskMesafesi","TP2","TP3",
                  "RiskYuzde","RiskUSDT","Miktar","PozisyonUSDT","TeminatUSDT","KullanilanRiskUSDT","RR"]

def is_bist_symbol(sym):
    return not str(sym).endswith(("USDT", "_TRY"))

def load_json(path, default):
    if path.exists():
        try:
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            pass
    return default

def save_json(path, data):
    try:
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    except OSError as exc:
        print("Kayıt hatası:", exc)

def normalize_trade(t):
    t["id"] = str(t.get("id", datetime.now().strftime("%Y%m%d%H%M%S%f")))
    t.setdefault("Para", "TL" if is_bist_symbol(t.get("Sembol", "")) else "USDT")
    if "K/Z (TL)" in t: t["KZ"] = t.pop("K/Z (TL)")
    if "Çıkış" in t: t["Cikis"] = t.pop("Çıkış")
    return t

def write_csv(path, results, fields=None):
    rows = sorted(results, key=lambda x: x.get("Puan", 0), reverse=True)
    if not rows: return
    if fields is None:
        fields = list(dict.fromkeys(k for r in rows for k in r.keys()))
    try:
        with open(path, "w", newline="", encoding="utf-8-sig") as f:
            w = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
            w.writeheader(); w.writerows(rows)
    except OSError:
        pass

def _decimals(step):
    if not step: return 8
    return max(0, -Decimal(str(step)).normalize().as_tuple().exponent)

def _round_tick(value, tick, mode=ROUND_HALF_UP):
    if not tick: return float(value)
    d = Decimal(str(tick))
    q = (Decimal(str(value)) / d).to_integral_value(rounding=mode) * d
    return round(float(q), _decimals(tick))

def _round_step(value, step):
    return _round_tick(value, step, ROUND_DOWN)

def bist_ema(values, period):
    if len(values) < period: return None
    m = 2 / (period + 1)
    result = sum(values[:period]) / period
    for value in values[period:]: result = value * m + result * (1 - m)
    return result

def bist_rsi(values, period=14):
    if len(values) < period + 1: return None
    gains, losses = [], []
    for i in range(1, len(values)):
        delta = values[i] - values[i - 1]
        gains.append(max(delta, 0)); losses.append(max(-delta, 0))
    avg_gain = sum(gains[:period]) / period
    avg_loss = sum(losses[:period]) / period
    for i in range(period, len(gains)):
        avg_gain = (avg_gain * (period - 1) + gains[i]) / period
        avg_loss = (avg_loss * (period - 1) + losses[i]) / period
    if avg_loss == 0: return 100.0
    return 100 - 100 / (1 + avg_gain / avg_loss)

def bist_stoch_rsi(close, period=14):
    if len(close) < (period * 2 + 1): return None
    rsis = [bist_rsi(close[:end + 1], period) for end in range(period, len(close))]
    rsis = [x for x in rsis if x is not None]
    if len(rsis) < period: return None
    window = rsis[-period:]
    lo, hi = min(window), max(window)
    return 50.0 if hi == lo else (window[-1] - lo) / (hi - lo) * 100

def bist_vol_ratio(volume, last_date):
    """Gün içindeki tamamlanmamış günlük mumu kıyaslamaya katmaz."""
    if volume is None or len(volume) < 12: return 1.0
    now = datetime.now()
    idx = len(volume) - 1
    if last_date == now.date() and (now.hour * 60 + now.minute) < 18 * 60 + 15:
        idx -= 1
    prior = volume[idx - 10:idx]
    avg = sum(prior) / len(prior) if prior else 0
    return float(volume[idx]) / avg if avg > 0 else 1.0

def bist_analyze_tf(close, high, low, volume=None, last_date=None):
    if len(close) < 50: return None
    price = float(close[-1])
    e20, e50 = bist_ema(close, 20), bist_ema(close, 50)
    rsi_value = bist_rsi(close, 14)
    if e20 is None or e50 is None or rsi_value is None: return None
    trend = "YUKARI" if price > e20 and e20 > e50 else "ASAGI" if price < e20 and e20 < e50 else "YATAY"
    pct_change = ((price - float(close[-2])) / float(close[-2]) * 100) if len(close) > 1 and close[-2] else 0.0
    return {"price": price, "rsi": rsi_value, "trend": trend, "high": high, "low": low, "close": close,
            "vol_ratio": bist_vol_ratio(volume, last_date), "pct_change": pct_change}

def bist_max_score(tf_list):
    m = sum(BIST_WEIGHTS.get(tf, 20) for tf in tf_list)
    if "1D" in tf_list: m += 25   # hacim 15 + değişim 10
    if "1H" in tf_list: m += 10   # RSI
    return max(m, 1)

def analyze_bist_stock(symbol, tf_list):
    try:
        raw = fetch_bist_data(symbol, tf_list)
        if any(tf not in raw for tf in tf_list): return {"Sembol": symbol, "Hata": "Eksik veri"}
        analyzed = {}
        for tf in tf_list:
            d = raw[tf]
            analyzed[tf] = bist_analyze_tf(d["close"], d["high"], d["low"], d["volume"], d.get("last_date"))
            if analyzed[tf] is None: return {"Sembol": symbol, "Hata": "İndikatör için yetersiz mum"}
        day_pct = analyzed["1D"]["pct_change"] if "1D" in analyzed else None

        def filt(reason): return {"Sembol": symbol, "Filtre": reason, "Degisim": day_pct}

        off = FILTERS_OFF["BIST"]
        if not off and "1D" in analyzed and analyzed["1D"]["vol_ratio"] < 1.0: return filt("Hacim filtresi")
        stoch_w = None
        if "1W" in analyzed:
            stoch_w = bist_stoch_rsi(analyzed["1W"]["close"])
            if not off and stoch_w is not None and stoch_w < 20: return filt("StochRSI filtresi")
        raw_score = 0
        for tf in tf_list:
            w = BIST_WEIGHTS.get(tf, 20)
            t = analyzed[tf]["trend"]
            if t == "YUKARI": raw_score += w
            elif t == "YATAY": raw_score += w // 3
        if "1D" in analyzed:
            vr = analyzed["1D"]["vol_ratio"]
            raw_score += 15 if vr >= 2.0 else 10 if vr >= 1.5 else 5 if vr > 1.0 else 0
            pct = analyzed["1D"]["pct_change"]
            raw_score += 10 if pct >= 3.0 else 5 if pct >= 1.0 else 0
        if "1H" in analyzed and 50 <= analyzed["1H"]["rsi"] <= 68: raw_score += 10
        score = int(round(raw_score / bist_max_score(tf_list) * 100))
        if not off and score < BIST_MIN_PCT: return filt(f"Puan {BIST_MIN_PCT} altı")

        signal = "TEYITLI LONG" if score >= BIST_CONFIRMED_PCT else "ERKEN LONG" if score >= BIST_MIN_PCT else "IZLE"
        plan = {}
        plan_tf = tf_list[-1] if tf_list[-1] in analyzed else next(iter(analyzed))
        d = analyzed[plan_tf]
        highs, lows, closes = d["high"], d["low"], d["close"]
        tr = [max(highs[i] - lows[i], abs(highs[i] - closes[i - 1]), abs(lows[i] - closes[i - 1]))
              for i in range(max(1, len(closes) - 14), len(closes))]
        stop_dist = (sum(tr) / len(tr)) * 1.5 if tr else 0
        if stop_dist > 0 and d["price"] > 0:
            price = d["price"]
            risk_tl = CAPITAL_TL * BIST_RISK_PERCENT / 100
            qty = min(risk_tl / stop_dist, CAPITAL_TL / price)
            plan = {"Giris": round(price, 2), "Stop": round(price - stop_dist, 2), "TP1": round(price + stop_dist * 2, 2),
                    "TP2": round(price + stop_dist * 3, 2), "TP3": round(price + stop_dist * 3, 2), "Miktar": int(qty), "PlanTF": plan_tf}
        daily = analyzed.get("1D", analyzed[tf_list[-1]])
        result = {"Tarih": datetime.now().strftime("%Y-%m-%d %H:%M:%S"), "Sembol": symbol, "Sinyal": signal, "Yon": "LONG",
                  "Puan": score, "Fiyat": round(analyzed[tf_list[-1]]["price"], 2), "RSI": round(analyzed[tf_list[-1]]["rsi"], 1),
                  "Degisim": round(daily["pct_change"], 2), "HacimOran": round(daily["vol_ratio"], 2),
                  "StochW": round(stoch_w, 1) if stoch_w is not None else "-"}
        for tf in tf_list: result[tf] = analyzed[tf]["trend"]
        from tr_early_stages import classify_tr_early_stage
        # Exclude the latest bar, which may still be trading on the BIST feed.
        stage_data = {key: raw[plan_tf][key][:-1] for key in ("open", "high", "low", "close", "volume")
                      if key in raw[plan_tf]}
        stage = classify_tr_early_stage(stage_data, f"{plan_tf} · son mum hariç")
        result.update(Hazirlik=stage["stage"] if stage else "", HazirlikNotu=stage["note"] if stage else "")
        result.update(plan)
        result.update(obv_analysis(d["close"], raw[plan_tf]["volume"]))
        result.update(deep_volume_analysis(raw[plan_tf]["volume"], d["close"], d["high"], d["low"]))
        return result
    except Exception as exc:
        return {"Sembol": symbol, "Hata": str(exc)[:100]}

def run_bist_scan(tf_list, market_name, progress, stop_event, live_mode=False, interval=BIST_LIVE_INTERVAL):
    symbols = bist_symbols(market_name)
    results = {}
    errors = done = scored = 0
    total = len(symbols)
    progress("started", {"total": total, "market": market_name})
    pool = ThreadPoolExecutor(max_workers=BIST_WORKERS)
    try:
        while not stop_event.is_set():
            errors = done = scored = 0
            futures = {pool.submit(analyze_bist_stock, sym, tf_list): sym for sym in symbols}
            for future in as_completed(futures):
                if stop_event.is_set(): break
                sym = futures[future]
                try: row = future.result()
                except Exception as exc: row = {"Sembol": sym, "Hata": str(exc)[:100]}
                if "Hata" in row:
                    errors += 1
                    results.pop(sym, None)
                    progress("drop", row)
                elif "Filtre" in row:
                    results.pop(sym, None); progress("drop", row)
                else:
                    scored += 1
                    results[sym] = row; progress("row", row)
                done += 1
                progress("progress", {"done": done, "total": total, "symbol": sym})
            write_csv(BIST_CSV, list(results.values()))
            if stop_event.is_set() or not live_mode: break
            progress("cycle", {"count": len(results), "errors": errors, "done": done, "scored": scored, "total": total, "next": interval})
            for _ in range(interval):
                if stop_event.is_set(): break
                time.sleep(1)
    finally:
        pool.shutdown(wait=False, cancel_futures=True)
    progress("finished", {"count": len(results), "errors": errors, "done": done, "scored": scored, "total": total, "stopped": stop_event.is_set()})
    return list(results.values())

def binance_session():
    if requests is None: raise RuntimeError("requests kurulu değil. (pip install requests)")
    sess = getattr(_binance_thread, "session", None)
    if sess is None:
        sess = requests.Session()
        sess.headers.update({"User-Agent": "PiyasaTerminal/3.0"})
        _binance_thread.session = sess
    return sess

def tr_get(url, params=None):
    response = binance_session().get(url, params=params, timeout=HTTP_TIMEOUT)
    response.raise_for_status()
    data = response.json()
    if isinstance(data, dict) and "code" in data:
        if data["code"] != 0: raise RuntimeError(str(data.get("msg", data)))
        return data.get("data")
    return data

def tr_symbols():
    data = tr_get("https://www.binance.tr/open/v1/common/symbols")
    rows = data["list"]
    result = []
    for row in rows:
        if row.get("quoteAsset") != "TRY" or row.get("type") not in (1,3): continue
        if not row.get("spotTradingEnable", 1): continue
        sym = row["symbol"]
        TR_TYPES[sym] = row["type"]
        result.append(sym)
    return sorted(set(result))

def tr_market(endpoint, params):
    params = dict(params); sym = params["symbol"]
    if sym not in TR_TYPES: tr_symbols()
    typ = TR_TYPES.get(sym)
    if typ not in (1,3): raise ValueError("Binance TR paritesi desteklenmiyor: " + sym)
    base = "https://api.binance.me/api/v1/" if typ == 1 else "https://cloudme-tr.2meta.app/api/v1/"
    name = endpoint.rsplit("/",1)[-1]
    if typ == 1:
        params["symbol"] = sym.replace("_", "")
        if name == "depth": base = "https://api.binance.me/api/v3/"
    if "limit" in params: params["limit"] = min(1000,params["limit"])
    return tr_get(base + name, params)

def binance_get(endpoint, params=None):
    if params and str(params.get("symbol", "")).endswith("_TRY"):
        return tr_market(endpoint, params)
    last_error = None
    for attempt in range(4):
        try:
            response = binance_session().get(BINANCE_BASE_URL + endpoint, params=params, timeout=HTTP_TIMEOUT)
            if response.status_code in (418, 429):
                ra = response.headers.get("Retry-After", "")
                try: wait = min(30.0, float(ra))
                except ValueError: wait = min(8.0, 1.5 ** (attempt + 1))
                time.sleep(wait)
            response.raise_for_status()
            return response.json()
        except Exception as exc:
            last_error = exc
            if attempt < 3: time.sleep(0.5 * (attempt + 1))
    raise RuntimeError(str(last_error))

def binance_ema(values, period):
    if len(values) < period: return None
    mult = 2 / (period + 1)
    value = sum(values[:period]) / period
    for x in values[period:]: value = x * mult + value * (1 - mult)
    return value

def binance_rsi(values, period=14):
    if len(values) < period + 1: return None
    gains, losses = [], []
    for i in range(1, len(values)):
        delta = values[i] - values[i - 1]
        gains.append(max(delta, 0)); losses.append(max(-delta, 0))
    ag, al = sum(gains[:period]) / period, sum(losses[:period]) / period
    for i in range(period, len(gains)):
        ag = (ag * (period - 1) + gains[i]) / period
        al = (al * (period - 1) + losses[i]) / period
    return 100.0 if al == 0 else 100 - 100 / (1 + ag / al)

def binance_atr(highs, lows, closes, period=14):
    if len(closes) < period + 1: return None
    trs = [max(highs[i] - lows[i], abs(highs[i] - closes[i - 1]), abs(lows[i] - closes[i - 1])) for i in range(1, len(closes))]
    value = sum(trs[:period]) / period
    for tr in trs[period:]: value = (value * (period - 1) + tr) / period
    return value

def binance_get_market_data(symbol, interval, limit=100, min_bars=55):
    cache_key = (symbol, interval, limit, min_bars)
    with _binance_cache_lock:
        cached = _binance_kline_cache.get(cache_key)
        if cached and time.time() - cached[0] < 20: return cached[1]
    raw = binance_get("/fapi/v1/klines", {"symbol": symbol, "interval": interval, "limit": limit})[:-1]
    o = [float(x[1]) for x in raw]; h = [float(x[2]) for x in raw]; l = [float(x[3]) for x in raw]
    c = [float(x[4]) for x in raw]; v = [float(x[5]) for x in raw]
    if len(c) < min_bars: raise ValueError("Yeterli mum verisi yok")
    result = {"open": o, "high": h, "low": l, "close": c, "volume": v, "time_ms": [int(x[0]) for x in raw]}
    with _binance_cache_lock: _binance_kline_cache[cache_key] = (time.time(), result)
    return result

def binance_analyze_tf(data):
    c, h, l, v = data["close"], data["high"], data["low"], data["volume"]
    price = c[-1]
    e20, e50 = binance_ema(c, 20), binance_ema(c, 50)
    r, a = binance_rsi(c, 14), binance_atr(h, l, c, 14)
    if None in (e20, e50, r, a): raise ValueError("İndikatör hesaplanamadı")
    trend = "YUKARI" if price > e20 > e50 else "ASAGI" if price < e20 < e50 else "YATAY"
    prior_vol = v[-21:-1]
    avg_vol = sum(prior_vol) / len(prior_vol) if prior_vol else 0
    rvol = v[-1] / avg_vol if avg_vol > 0 else 0
    return {"price": price, "ema20": e20, "ema50": e50, "rsi": r, "atr": a, "trend": trend, "rvol": rvol,
            "breakout_up": price > max(h[-21:-1]), "breakout_down": price < min(l[-21:-1])}

def get_btc_market():
    raw, data = {}, {}
    for tf in ("15m", "1h", "4h"):
        raw[tf] = binance_get_market_data("BTCUSDT", tf)
        data[tf] = binance_analyze_tf(raw[tf])
    trends = [data[x]["trend"] for x in ("15m", "1h", "4h")]
    ups, downs = trends.count("YUKARI"), trends.count("ASAGI")
    btc_change = (raw["4h"]["close"][-1] / raw["4h"]["open"][-1] - 1) * 100
    if ups == 3 and btc_change >= BINANCE_BTC_CHANGE_LIMIT: mode = "YUKARI_GUCLU"
    elif downs == 3 and btc_change <= -BINANCE_BTC_CHANGE_LIMIT: mode = "ASAGI_GUCLU"
    elif ups >= 2: mode = "YUKARI"
    elif downs >= 2: mode = "ASAGI"
    else: mode = "KARISIK"
    return mode, data, btc_change

def btc_alignment(side, mode):
    if mode in ("YUKARI_GUCLU", "YUKARI"):
        if side == "LONG": return "UYUMLU", 5
        return ("TERS", -15 if mode == "YUKARI_GUCLU" else -10)
    if mode in ("ASAGI_GUCLU", "ASAGI"):
        if side == "SHORT": return "UYUMLU", 5
        return ("TERS", -15 if mode == "ASAGI_GUCLU" else -10)
    return "KARISIK", -5

def btc_blocks_signal(side, mode):
    if FILTERS_OFF["BINANCE"]: return False
    return (mode == "ASAGI_GUCLU" and side == "LONG") or (mode == "YUKARI_GUCLU" and side == "SHORT")

def score_direction(m5, m15, h1, side, btc_mode):
    score = 0
    desired = "YUKARI" if side == "LONG" else "ASAGI"
    for d, weight, neutral in ((m5, 20, 8), (m15, 25, 10), (h1, 20, 8)):
        if d["trend"] == desired: score += weight
        elif d["trend"] == "YATAY": score += neutral
    if side == "LONG":
        if 50 <= m5["rsi"] <= 68: score += 10
        elif 45 <= m5["rsi"] < 50: score += 5
    else:
        if 32 <= m5["rsi"] <= 50: score += 10
        elif 50 < m5["rsi"] <= 55: score += 5
    if m5["rvol"] >= 2: score += 10
    elif m5["rvol"] >= 1.5: score += 8
    elif m5["rvol"] >= 1: score += 5
    if side == "LONG" and m5["breakout_up"]: score += 10
    elif side == "SHORT" and m5["breakout_down"]: score += 10
    if side == "LONG" and m5["price"] > m5["ema20"]: score += 5
    elif side == "SHORT" and m5["price"] < m5["ema20"]: score += 5
    _, adjustment = btc_alignment(side, btc_mode)
    score = max(0, min(100, score + adjustment))
    if btc_blocks_signal(side, btc_mode): score = min(score, 49)
    return score

def determine_signal(long_score, short_score, m5, m15, h1, btc_mode):
    best = max(long_score, short_score)
    if long_score > short_score: side, desired = "LONG", "YUKARI"
    elif short_score > long_score: side, desired = "SHORT", "ASAGI"
    else: return "IZLE", "YOK", best
    if btc_blocks_signal(side, btc_mode): return "IZLE", side, best
    if best >= BINANCE_CONFIRMED_SCORE and m15["trend"] == desired and h1["trend"] == desired: return "TEYITLI " + side, side, best
    if best >= BINANCE_EARLY_SCORE: return "ERKEN " + side, side, best
    return "IZLE", side, best

def calculate_binance_plan(symbol, data5, m5, side):
    f = SYMBOL_FILTERS.get(symbol, {})
    tick, step = f.get("tick"), f.get("step")
    entry, atr_value = _round_tick(m5["price"], tick), m5["atr"]
    highs = data5["high"][-BINANCE_STRUCTURE_LOOKBACK:]
    lows = data5["low"][-BINANCE_STRUCTURE_LOOKBACK:]
    if side == "LONG":
        stop = _round_tick(min(lows) - atr_value * BINANCE_ATR_BUFFER, tick, ROUND_DOWN); distance = entry - stop
    else:
        stop = _round_tick(max(highs) + atr_value * BINANCE_ATR_BUFFER, tick, ROUND_UP); distance = stop - entry
    if distance <= 0 or entry <= 0: return None
    budget = BINANCE_CAPITAL_USDT * BINANCE_RISK_PERCENT / 100
    max_value = BINANCE_CAPITAL_USDT * BINANCE_MAX_LEVERAGE
    capped = (max_value / entry) < (budget / distance)
    qty = _round_step(min(budget / distance, max_value / entry), step)
    if qty <= 0: return None
    pos_value, actual_risk = qty * entry, qty * distance
    sign = 1 if side == "LONG" else -1
    tp2 = _round_tick(entry + sign * distance * 2, tick)
    tp3 = _round_tick(entry + sign * distance * 3, tick)
    status = "SERMAYE LIMITI" if capped else "HESAPLANDI"
    if qty < f.get("minQty", 0) or pos_value < f.get("minNotional", 0): status = "MIN LOT/NOTIONAL ALTI"
    return {"Giris": entry, "Stop": stop, "RiskMesafesi": round(distance, 8), "TP1": tp2, "TP2": tp3, "TP3": tp3, "PlanTF": "5m",
            "RiskYuzde": round(actual_risk / BINANCE_CAPITAL_USDT * 100, 3), "RiskUSDT": round(budget, 4), "Miktar": qty,
            "PozisyonUSDT": round(pos_value, 4), "TeminatUSDT": round(pos_value / BINANCE_MAX_LEVERAGE, 4),
            "KullanilanRiskUSDT": round(actual_risk, 4), "RR": "1:2 / 1:3", "PlanDurumu": status}

def get_binance_symbols(symbol_filter=None):
    info = binance_get("/fapi/v1/exchangeInfo")
    tickers = binance_get("/fapi/v1/ticker/24hr")
    ticker_map = {x["symbol"]: x for x in tickers}
    items = []
    for item in info["symbols"]:
        symbol = item["symbol"]
        ticker = ticker_map.get(symbol, {})
        volume = float(ticker.get("quoteVolume", 0) or 0)
        if (item["status"] == "TRADING" and item["contractType"] == "PERPETUAL" and item["quoteAsset"] == "USDT"
                and symbol.endswith("USDT") and (symbol == symbol_filter if symbol_filter else
                    symbol != "BTCUSDT" and volume >= (0 if FILTERS_OFF["BINANCE"] else BINANCE_MIN_VOLUME))):
            items.append((symbol, volume, float(ticker.get("priceChangePercent", 0) or 0)))
            filt = {}
            for fl in item.get("filters", []):
                t = fl.get("filterType")
                if t == "PRICE_FILTER": filt["tick"] = float(fl["tickSize"])
                elif t == "LOT_SIZE": filt["step"] = float(fl["stepSize"]); filt["minQty"] = float(fl["minQty"])
                elif t == "MIN_NOTIONAL": filt["minNotional"] = float(fl.get("notional", 0) or 0)
            SYMBOL_FILTERS[symbol] = filt
    items.sort(key=lambda x: x[1], reverse=True)
    return items[:BINANCE_MAX_COINS_NOFILTER if FILTERS_OFF["BINANCE"] else BINANCE_MAX_COINS]

def analyze_binance_coin(item, btc_mode, btc_data, btc_change):
    symbol, volume, change_24h = item
    try:
        d5 = binance_get_market_data(symbol, "5m"); d15 = binance_get_market_data(symbol, "15m"); d1h = binance_get_market_data(symbol, "1h")
        m5, m15, h1 = binance_analyze_tf(d5), binance_analyze_tf(d15), binance_analyze_tf(d1h)
        long_score = score_direction(m5, m15, h1, "LONG", btc_mode)
        short_score = score_direction(m5, m15, h1, "SHORT", btc_mode)
        signal, side, score = determine_signal(long_score, short_score, m5, m15, h1, btc_mode)
        alignment = btc_alignment(side, btc_mode)[0] if side in ("LONG", "SHORT") else "YOK"
        tick = SYMBOL_FILTERS.get(symbol, {}).get("tick")
        row = {"Tarih": datetime.now().strftime("%Y-%m-%d %H:%M:%S"), "Sembol": symbol, "Sinyal": signal, "Yon": side, "Puan": score,
               "LONG": long_score, "SHORT": short_score, "Fiyat": _round_tick(m5["price"], tick), "Degisim24h": change_24h,
               "RSI": round(m5["rsi"], 2), "RVOL": round(m5["rvol"], 2), "5m": m5["trend"], "15m": m15["trend"], "1h": h1["trend"],
               "BTC_Modu": btc_mode, "BTC_15m": btc_data["15m"]["trend"], "BTC_1h": btc_data["1h"]["trend"], "BTC_4h": btc_data["4h"]["trend"],
               "BTC_Uyum": alignment, "BTC_4H_Degisim": round(btc_change, 3), "Hacim": round(volume, 2), "PlanDurumu": "PLAN YOK"}
        row.update(obv_analysis(d5["close"], d5["volume"]))
        row.update(deep_volume_analysis(d5["volume"], d5["close"], d5["high"], d5["low"]))
        if signal.startswith(("ERKEN", "TEYITLI")):
            plan = calculate_binance_plan(symbol, d5, m5, side)
            if plan: row.update(plan)
            else: row["PlanDurumu"] = "PLAN HESAPLANAMADI"
        return row
    except Exception as exc:
        return {"Sembol": symbol, "Hata": str(exc)[:120]}

def _btc_meta(total, btc_mode, btc_data, btc_change):
    return {"total": total, "btc_mode": btc_mode, "btc_change": btc_change, "btc_15m": btc_data["15m"]["trend"],
            "btc_1h": btc_data["1h"]["trend"], "btc_4h": btc_data["4h"]["trend"]}

def run_binance_scan(progress, stop_event, live_mode=False, symbol_filter=None):
    progress("started", {"status": "BTC ve coin listesi alınıyor"})
    btc_mode, btc_data, btc_change = get_btc_market()
    symbols = get_binance_symbols(symbol_filter) if symbol_filter else get_binance_symbols()
    if symbol_filter and not symbols:
        raise ValueError("Vadeli parite bulunamadı: " + symbol_filter)
    progress("meta", _btc_meta(len(symbols), btc_mode, btc_data, btc_change))
    results, errors = {}, 0
    pool = ThreadPoolExecutor(max_workers=BINANCE_WORKERS)
    try:
        while not stop_event.is_set():
            errors, done, total = 0, 0, len(symbols)
            futures = {pool.submit(analyze_binance_coin, item, btc_mode, btc_data, btc_change): item[0] for item in symbols}
            for future in as_completed(futures):
                if stop_event.is_set(): break
                symbol = futures[future]
                try: row = future.result()
                except Exception as exc: row = {"Sembol": symbol, "Hata": str(exc)[:120]}
                if "Hata" in row: errors += 1
                else:
                    results[symbol] = row; progress("row", row)
                done += 1
                progress("progress", {"done": done, "total": total, "symbol": symbol})
            write_csv(BINANCE_CSV, list(results.values()), BINANCE_FIELDS)
            if stop_event.is_set() or not live_mode: break
            progress("cycle", {"count": len(results), "errors": errors, "next": BINANCE_LIVE_INTERVAL})
            try:  # BTC + coin evrenini yenile
                btc_mode, btc_data, btc_change = get_btc_market()
                symbols = get_binance_symbols(symbol_filter) if symbol_filter else get_binance_symbols()
                names = {s[0] for s in symbols}
                for s in [s for s in results if s not in names]:
                    results.pop(s, None); progress("drop", {"Sembol": s})
                progress("meta", _btc_meta(len(symbols), btc_mode, btc_data, btc_change))
            except Exception as exc:
                progress("log", f"Yenileme hatası: {str(exc)[:80]}")
            for _ in range(BINANCE_LIVE_INTERVAL):
                if stop_event.is_set(): break
                time.sleep(1)
    finally:
        pool.shutdown(wait=False, cancel_futures=True)
    progress("finished", {"count": len(results), "errors": errors, "total": len(symbols), "stopped": stop_event.is_set(), "btc_mode": btc_mode})
    return list(results.values())

def tr_spot_available_tl(trades, starting_tl):
    """Sanal spot TR alışları için kullanılabilir TRY; açık pozisyonların maliyeti ayrılır."""
    realized = sum(float(t.get("KZ", 0) or 0) for t in trades
                   if t.get("Durum") != "AÇIK" and t.get("Para") == "TL")
    realized += sum(float(t.get("GerceklesenKZ", 0) or 0) for t in trades
                    if t.get("Durum") == "AÇIK" and t.get("Para") == "TL")
    reserved = sum(float(t.get("Giris", 0) or 0) * float(t.get("Miktar", 0) or 0)
                   for t in trades if t.get("Durum") == "AÇIK" and t.get("Para") == "TL")
    return starting_tl + realized - reserved

def calc_pnl(trade, price):
    if price is None: return None
    d = (price - trade["Giris"]) if trade["Tür"] == "LONG" else (trade["Giris"] - price)
    return d * trade["Miktar"]


# ---- Veri katmanı: borsapy yerine data_provider (Yahoo Finance, yalnızca requests) ----
def fetch_bist_data(symbol, requested_tfs):
    cache_key = (symbol, tuple(requested_tfs))
    with _bist_cache_lock:
        cached = _bist_cache.get(cache_key)
        if cached and time.time() - cached[0] < 45: return cached[1]
    result = {}
    for tf in ("1W", "1D", "1H"):
        if tf not in requested_tfs: continue
        d = data_provider.history_tf(symbol, tf)
        if d is not None: result[tf] = d
    with _bist_cache_lock: _bist_cache[cache_key] = (time.time(), result)
    return result

def fetch_bist_price(symbol):
    return data_provider.last_price(symbol)

def is_try_pair(sym): return str(sym).endswith("_TRY")

def fetch_prices(symbols):
    """Güncel fiyatlar: TR spot, Binance vadeli ve BIST (özgün fetch_prices ile aynı mantık)."""
    out = {}
    bins = [s for s in symbols if not is_bist_symbol(s) and not s.endswith("_TRY")]
    for sym in symbols:
        if sym.endswith("_TRY"):
            try: out[sym] = float(tr_market("klines", {"symbol": sym, "interval": "5m", "limit": 1})[-1][4])
            except Exception: pass
    if bins and requests is not None:
        try:
            m = {x["symbol"]: float(x["price"]) for x in binance_get("/fapi/v1/ticker/price")}
            for s in bins:
                if s in m: out[s] = m[s]
        except Exception:
            pass
    for s in symbols:
        if is_bist_symbol(s):
            try: out[s] = fetch_bist_price(s)
            except Exception: pass
    return out

def analyze_tr_symbol(sym, stop=None):
    """Binance TR (TRY) paritesi: özgün _tr_worker_cycle içindeki analyze() ile aynı kural."""
    from tr_early_stages import classify_tr_early_stage
    frames = []; raw5 = None
    for tf in ("5m", "15m", "1h"):
        if stop is not None and stop.is_set(): return None
        data = binance_get_market_data(sym, tf, 250)
        if tf == "5m": raw5 = data
        frames.append(binance_analyze_tf(data))
    m5, m15, h1 = frames
    stage = classify_tr_early_stage(raw5)
    score = score_direction(m5, m15, h1, "LONG", "KARISIK")
    signal = ("TEYITLI LONG" if score >= BINANCE_CONFIRMED_SCORE and m15["trend"] == h1["trend"] == "YUKARI"
              else "ERKEN LONG" if score >= BINANCE_EARLY_SCORE else "IZLE")
    row = dict(Sembol=sym, Fiyat=m5["price"], Puan=score, Sinyal=signal, Yon="LONG", RSI=m5["rsi"], RVOL=m5["rvol"],
                Hazirlik=stage["stage"] if stage else "", HazirlikNotu=stage["note"] if stage else "")
    row.update(obv_analysis(raw5["close"], raw5["volume"]))
    row.update(deep_volume_analysis(raw5["volume"], raw5["close"], raw5["high"], raw5["low"]))
    return row


def run_tr_scan(progress, stop_event, workers=5, symbol_filter=None):
    """Binance TR taraması (tek tur). progress(kind, payload) UI iş parçacığı dışından çağrılır."""
    symbols = tr_symbols()
    if symbol_filter:
        if symbol_filter not in symbols:
            raise ValueError("Binance TR paritesi bulunamadı: " + symbol_filter)
        symbols = [symbol_filter]
    total = len(symbols); done = errors = 0
    progress("started", {"total": total})
    with ThreadPoolExecutor(max_workers=workers) as pool:
        futs = {pool.submit(analyze_tr_symbol, s, stop_event): s for s in symbols}
        for f in as_completed(futs):
            if stop_event.is_set(): break
            s = futs[f]
            try:
                row = f.result()
                if row: progress("row", row)
            except Exception as exc:
                errors += 1
                if "429" in str(exc) or "418" in str(exc):
                    progress("finished", {"done": done, "total": total, "errors": errors, "limited": True}); stop_event.set(); return
            done += 1; progress("progress", {"done": done, "total": total, "symbol": s})
    progress("finished", {"done": done, "total": total, "errors": errors, "limited": False, "stopped": stop_event.is_set()})

# ---- Sanal işlem / favori yönetimi (özgün open_trade_popup + _finalize_close mantığı) ----
def load_trades():
    return [normalize_trade(t) for t in load_json(TRADES_FILE, []) if isinstance(t, dict)]

def save_trades(trades): save_json(TRADES_FILE, trades)

def load_favorites():
    out = []
    for x in load_json(FAV_FILE, []):
        if isinstance(x, str): out.append({"Sembol": x, "Tarih": datetime.now().strftime("%Y-%m-%d")})
        elif isinstance(x, dict) and "Sembol" in x: out.append(x)
    return out

def save_favorites(favs): save_json(FAV_FILE, favs)

def open_virtual_trade(trades, symbol, side, price, qty, stop=None, tp2=None, tp3=None, leverage=1):
    bist, tr_spot = is_bist_symbol(symbol), symbol.endswith("_TRY")
    if tr_spot and side != "LONG": raise ValueError("Spot piyasada sanal SHORT yok.")
    if price <= 0 or qty <= 0: raise ValueError("Fiyat ve miktar 0'dan büyük olmalı.")
    if stop is not None and ((side == "LONG" and stop >= price) or (side == "SHORT" and stop <= price)):
        raise ValueError("Stop, işlem yönüne göre yanlış tarafta.")
    if bist: qty = float(int(qty))
    if tr_spot or bist:
        cost = qty * price; available = tr_spot_available_tl(trades, CAPITAL_TL)
        if cost > available + 1e-8: raise ValueError(f"Yetersiz sanal TL bakiyesi: {available:,.2f} TL kullanılabilir, {cost:,.2f} TL gerekli.")
        leverage = 1
    trade = {"id": datetime.now().strftime("%Y%m%d%H%M%S%f"), "Tarih": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
             "Sembol": symbol, "Tür": side, "Para": "TL" if bist or tr_spot else "USDT", "Giris": price, "Miktar": qty,
             "Stop": stop, "TP1": tp2, "TP2": tp3, "TP3": tp3, "Kaldirac": leverage, "PlanTF": "5m", "Durum": "AÇIK",
             "TP1Gerceklesti": False, "GerceklesenKZ": 0.0}
    trades.append(trade); return trade

def close_virtual_trade(trade, price, reason="MANUEL"):
    if trade.get("Durum") != "AÇIK": return trade
    pnl = calc_pnl(trade, price)
    trade.update({"Cikis": price, "Durum": "KAPALI", "KZ": round(pnl + float(trade.get("GerceklesenKZ", 0) or 0), 4),
                  "KapanisNedeni": reason, "KapanisTarihi": datetime.now().strftime("%Y-%m-%d %H:%M:%S")})
    return trade
