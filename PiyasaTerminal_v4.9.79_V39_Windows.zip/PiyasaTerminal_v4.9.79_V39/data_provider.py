# -*- coding: utf-8 -*-
"""Android için veri katmanı: yalnızca `requests`, pandas yok.

Özgün masaüstü sürüm BIST verisini `borsapy` ile alıyordu. borsapy, pandas'a
bağlıdır ve Android paketini ağırlaştırıp derlemeyi riskli hale getirir; bu yüzden
burada Yahoo Finance'in herkese açık grafik uç noktası kullanılır:

    BIST hissesi  THYAO   -> THYAO.IS
    Endeks        XU100   -> XU100.IS
    Dolar/TL      USDTRY  -> USDTRY=X

ÖNEMLİ: Kaynak değiştiği için fiyat/hacim değerleri borsapy ile birebir aynı olmayabilir.
Puanlar ve evre geçişleri deneyseldir; sonuçları kendi grafiğinizle doğrulayın.
Fiyatlar bölünme (bedelsiz) düzeltmelidir; temettü düzeltmesi UYGULANMAZ.
"""
from __future__ import annotations
from contextlib import contextmanager
from concurrent.futures import CancelledError
import time
import threading
from datetime import date, datetime, timedelta, timezone

try:
    import requests
except Exception:  # pragma: no cover
    requests = None

HTTP_TIMEOUT = 20
_HOSTS = ("https://query1.finance.yahoo.com", "https://query2.finance.yahoo.com")
_HEADERS = {"User-Agent": "Mozilla/5.0 (Linux; Android 13) PiyasaTerminali/1.0", "Accept": "application/json"}
_local = threading.local()
_gate = threading.Semaphore(4)  # eşzamanlı istek sınırı


@contextmanager
def scan_requests(stop):
    previous = getattr(_local, "stop", None)
    _local.stop = stop
    try:
        yield
    finally:
        _local.stop = previous


def check_stop():
    stop = getattr(_local, "stop", None)
    if stop is not None and stop.is_set():
        raise CancelledError()


def retry_delay(seconds):
    stop = getattr(_local, "stop", None)
    if stop is None:
        time.sleep(seconds)
    elif stop.wait(seconds):
        raise CancelledError()


def yahoo_symbol(symbol: str) -> str:
    s = str(symbol).strip().upper()
    if s == "USDTRY":
        return "USDTRY=X"
    if s.endswith((".IS", "=X")):
        return s
    return s + ".IS"


def _session():
    sess = getattr(_local, "s", None)
    if sess is None:
        if requests is None:
            raise RuntimeError("requests kurulu değil.")
        sess = requests.Session()
        sess.headers.update(_HEADERS)
        _local.s = sess
    return sess


def _get(path: str, params: dict):
    """JSON döndürür; 429/5xx'te üstel bekleme ile en çok 4 deneme."""
    last = None
    for attempt in range(4):
        check_stop()
        host = _HOSTS[attempt % 2]
        try:
            with _gate:
                check_stop()
                r = _session().get(host + path, params=params, timeout=HTTP_TIMEOUT)
            check_stop()
            if r.status_code in (429, 500, 502, 503, 504):
                retry_delay(min(10.0, 1.5 ** (attempt + 1)))
                last = RuntimeError(f"HTTP {r.status_code}")
                continue
            r.raise_for_status()
            return r.json()
        except CancelledError:
            raise
        except Exception as exc:  # ağ hatası
            last = exc
            retry_delay(0.4 * (attempt + 1))
    raise RuntimeError(f"Veri alınamadı: {last}")


def _chart(symbol: str, interval: str, rng: str | None = None, start: str | None = None, end: str | None = None):
    """[(datetime, o, h, l, c, v), ...] — boş/None değerli mumlar atılır; zaman borsa saatindedir."""
    params = {"interval": interval, "includePrePost": "false", "events": "div,splits"}
    if start:
        p1 = int(datetime.fromisoformat(start).replace(tzinfo=timezone.utc).timestamp())
        p2 = int((datetime.fromisoformat(end) if end else datetime.now()).replace(tzinfo=timezone.utc).timestamp()) + 86400
        params.update(period1=p1, period2=p2)
    else:
        params["range"] = rng or "max"
    js = _get("/v8/finance/chart/" + yahoo_symbol(symbol), params)
    chart = js.get("chart") or {}
    if chart.get("error"):
        raise RuntimeError(str(chart["error"].get("description", chart["error"]))[:120])
    res = (chart.get("result") or [None])[0]
    if not res or not res.get("timestamp"):
        raise RuntimeError("Veri boş")
    meta = res.get("meta") or {}
    if interval == "1d" and meta.get("dataGranularity") not in (None, "1d"):
        raise ValueError("Veri sağlayıcı günlük mum döndürmedi.")
    off = int((res.get("meta") or {}).get("gmtoffset", 0) or 0)
    q = res["indicators"]["quote"][0]
    out = []
    for i, ts in enumerate(res["timestamp"]):
        try:
            o, h, l, c, v = q["open"][i], q["high"][i], q["low"][i], q["close"][i], q["volume"][i]
        except (IndexError, KeyError):
            continue
        if None in (o, h, l, c):
            continue
        dt = datetime.fromtimestamp(ts + off, timezone.utc).replace(tzinfo=None)
        out.append((dt, float(o), float(h), float(l), float(c), float(v or 0)))
    return out


DAILY_START = "1970-01-02"


def is_coarse(rows):
    """Mumlar günlük değilse (haftalık/aylık gibi seyrek) True. rows: (datetime | 'YYYY-AA-GG', ...) kayıtları."""
    stamps = []
    for row in rows:
        value = row[0]
        stamps.append(value if isinstance(value, datetime) else datetime.fromisoformat(str(value)[:10]))
    if len(stamps) < 6:
        return False
    gaps = sorted((b - a).days for a, b in zip(stamps, stamps[1:]))
    return gaps[len(gaps) // 2] > 4


def daily_rows(symbol, start=None, end=None):
    """Her zaman GÜNLÜK mumlar.

    Yahoo çok uzun aralıklarda (range=max gibi) haftalık veya aylık mum döndürebilir. Bu durumda
    aralık 4 yıllık parçalara bölünerek günlük mumlar yeniden alınır.
    """
    first = start or DAILY_START
    rows = _chart(symbol, "1d", start=first, end=end)
    if not is_coarse(rows):
        return rows
    merged = {}
    cursor = datetime.fromisoformat(first)
    stop = datetime.fromisoformat(end) if end else datetime.now()
    while cursor <= stop:
        chunk_end = min(stop, cursor.replace(year=cursor.year + 4) - timedelta(days=1)) \
            if cursor.year + 4 <= stop.year else stop
        try:
            for row in _chart(symbol, "1d", start=cursor.date().isoformat(), end=chunk_end.date().isoformat()):
                merged[row[0]] = row
        except RuntimeError:
            pass  # veri olmayan eski yıllar
        cursor = chunk_end + timedelta(days=1)
    return [merged[key] for key in sorted(merged)]


class MiniFrame:
    """evre_core.normalize'ın beklediği minimal DataFrame benzeri (df[cols].itertuples(name=None))."""
    COLS = ("Open", "High", "Low", "Close", "Volume")

    def __init__(self, rows, cols=None):
        self._rows = rows
        self._cols = list(cols or self.COLS)

    def __getitem__(self, keys):
        keys = [keys] if isinstance(keys, str) else list(keys)
        return MiniFrame(self._rows, keys)

    def itertuples(self, name=None):
        idx = [self.COLS.index(k) for k in self._cols]
        for r in self._rows:
            yield (r[0], *[r[1 + i] for i in idx])

    def __len__(self):
        return len(self._rows)


def daily_df(symbol: str, start: str | None = None, end: str | None = None) -> MiniFrame:
    """Günlük mumlar. start verilmezse tüm geçmiş."""
    return MiniFrame(daily_rows(symbol, start=start, end=end))


def _weekly_from_daily(rows):
    weeks = {}
    for dt, o, h, l, c, v in rows:
        key = dt.date() - timedelta(days=dt.weekday())
        w = weeks.get(key)
        if w is None:
            weeks[key] = [dt, o, h, l, c, v]
        else:
            w[2] = max(w[2], h); w[3] = min(w[3], l); w[4] = c; w[5] += v
    return [tuple(w) for _, w in sorted(weeks.items())]


# Özgün BIST_TF_CFG ile aynı pencereler: 1W -> 2y, 1D -> 6mo, 1H -> 1mo
TF_CFG = {"1W": ("2y", "1wk"), "1D": ("6mo", "1d"), "1H": ("1mo", "1h")}


def history_tf(symbol: str, tf: str):
    """{'close','high','low','volume','last_date'} ya da None (en az 50 mum gerekir)."""
    rng, itv = TF_CFG[tf]
    rows = None
    try:
        rows = _chart(symbol, itv, rng=rng)
    except Exception:
        rows = None
    if (not rows or len(rows) < 50) and tf == "1W":
        try:
            w = _weekly_from_daily(_chart(symbol, "1d", rng="2y"))
            rows = w if len(w) >= 50 else None
        except Exception:
            rows = None
    if not rows or len(rows) < 50:
        return None
    return {
        "open": [r[1] for r in rows], "close": [r[4] for r in rows], "high": [r[2] for r in rows],
        "low": [r[3] for r in rows], "volume": [r[5] for r in rows],
        "last_date": rows[-1][0].date(),
    }


def last_price(symbol: str) -> float:
    for rng, itv in (("5d", "1h"), ("5d", "1d")):
        try:
            rows = _chart(symbol, itv, rng=rng)
            if rows:
                return float(rows[-1][4])
        except Exception:
            continue
    raise RuntimeError("fiyat alınamadı")


def chart_bars(symbol: str, tf: str = "1D", full_history: bool = False):
    """Grafik dönemine göre yerel tarihli OHLCV mumlarını getir."""
    if tf == "1W":
        rows = _weekly_from_daily(_chart(symbol, "1d", rng="5y"))
    elif tf in ("5m", "15m", "1H"):
        rows = _chart(symbol, tf.lower(), rng="1mo")
    elif tf == "4H":
        groups = {}
        for dt, op, high, low, close, volume in _chart(symbol, "1h", rng="3mo"):
            key = (dt.date(), (dt.hour - 10) // 4)
            if key not in groups:
                groups[key] = [dt, op, high, low, close, volume]
            else:
                bar = groups[key]
                bar[2] = max(bar[2], high)
                bar[3] = min(bar[3], low)
                bar[4] = close
                bar[5] += volume
        rows = list(groups.values())
    elif tf == "1D":
        rows = daily_rows(symbol) if full_history else _chart(symbol, "1d", rng="2y")
    else:
        raise ValueError(f"Desteklenmeyen grafik dönemi: {tf}")
    stamp = "%Y-%m-%d" if tf in ("1D", "1W") else "%Y-%m-%d %H:%M"
    return [(r[0].strftime(stamp), r[1], r[2], r[3], r[4], r[5]) for r in rows]
