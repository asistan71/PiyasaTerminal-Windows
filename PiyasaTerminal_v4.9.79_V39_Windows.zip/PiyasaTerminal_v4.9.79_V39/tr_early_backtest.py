"""Binance TR erken evre geçmiş değerlendirmesi; yalnız kapanmış 5m mumları.

Sinyal kararında i sonrasını kullanmaz. Sonuçlar sonraki OHLC mumlarıyla
ölçülür; işlem getirisi, emir gerçekleşmesi ya da gelecek tahmini değildir.
"""
from __future__ import annotations
from collections import Counter
from tr_early_stages import classify_tr_early_stage


def analyze_history(data, horizon=24, target_pct=3.0, stop_pct=3.0,
                    cooldown=12):
    if not isinstance(horizon, int) or not 1 <= horizon <= 240:
        raise ValueError('Takip mumu 1–240 arasında olmalı.')
    if target_pct <= 0 or stop_pct <= 0 or cooldown < 0:
        raise ValueError('Hedef/stop pozitif, bekleme sıfır veya pozitif olmalı.')
    required = ('open', 'high', 'low', 'close', 'volume')
    try:
        n = min(len(data[k]) for k in required)
        arrays = {key: list(data[key])[-n:] for key in required}
    except (TypeError, KeyError, ValueError):
        raise ValueError('OHLCV veri dizisi eksik.') from None
    if n < 62:
        raise ValueError('Geçmiş test için en az 62 kapanmış 5m mum gerekli.')
    events = []
    last_by_stage = {}
    for i in range(60, n):
        history = {key: values[:i+1] for key, values in arrays.items()}
        signal = classify_tr_early_stage(history)
        if not signal:
            continue
        stage = signal['stage']
        if i - last_by_stage.get(stage, -100000) <= cooldown:
            continue
        last_by_stage[stage] = i
        entry = float(arrays['close'][i]); target = entry*(1+target_pct/100)
        stop = entry*(1-stop_pct/100)
        status = 'BEKLEMEDE' if i+horizon >= n else 'HEDEFE ULAŞMADI'
        elapsed = None
        result_index = None
        end = min(i+horizon, n-1)
        for j in range(i+1, end+1):
            high = float(arrays['high'][j]); low = float(arrays['low'][j])
            hit_target = high >= target
            hit_stop = low <= stop
            if hit_target or hit_stop:
                elapsed = j-i
                result_index = j
                status = ('AYNI MUM BELİRSİZ' if hit_target and hit_stop else
                          'HEDEF' if hit_target else 'STOP')
                break
        events.append({
            'index': i, 'stage': stage, 'entry': entry,
            'rvol': signal.get('rvol'), 'cluster': signal.get('cluster'),
            'status': status, 'candles': elapsed,
            'result_index': result_index,
            'followed': end-i,
        })
    counts = Counter(e['status'] for e in events)
    completed = counts['HEDEF']+counts['STOP']+counts['HEDEFE ULAŞMADI']
    wins = [e['candles'] for e in events if e['status']=='HEDEF']
    stage_summary = {}
    for stage in ('Erken Hacimli Uyanış','Dipten Toparlanma','Kalkış Hazırlığı'):
        group = [e for e in events if e['stage']==stage]
        resolved = sum(e['status'] in ('HEDEF','STOP','HEDEFE ULAŞMADI') for e in group)
        good = sum(e['status']=='HEDEF' for e in group)
        stage_summary[stage] = {'signals':len(group), 'completed':resolved,
                                'hits':good, 'rate':100*good/resolved if resolved else None}
    return {'events':events, 'counts':dict(counts), 'completed':completed,
            'success_rate':100*counts['HEDEF']/completed if completed else None,
            'avg_candles_to_target':sum(wins)/len(wins) if wins else None,
            'stage_summary':stage_summary,
            'horizon':horizon,'target_pct':target_pct,'stop_pct':stop_pct}
