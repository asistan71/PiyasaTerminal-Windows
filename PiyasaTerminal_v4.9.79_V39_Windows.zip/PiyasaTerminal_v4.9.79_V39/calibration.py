"""Manuel referanslara karşı ölçüm; stratejiyi veya geçmiş sinyalleri değiştirmez."""
import csv
EVENTS=(('start','FRVP başı',2),('end','FRVP sonu',4),('fake','Sahte tepe',2),('real','Gerçek tepe',2))

def compare(symbol, result, manual, tolerance=3):
    bars=result['series']; usd=result['usd_series']; dates={b[0]:i for i,b in enumerate(bars)}
    auto={'start':result['phase']['peak'],'end':len(bars)-1,'fake':result['structure']['fake'],'real':result['structure']['real']}
    rows=[]
    for key,label,col in EVENTS:
        if key not in manual: continue
        a=auto[key]; m=dates.get(manual[key]); valid=a is not None and 0<=a<len(bars)
        delta=a-m if valid and m is not None else None
        status='Referans veri dışında' if m is None else 'Bulunamadı' if not valid else 'Uyumlu' if abs(delta)<=tolerance else 'Farklı'
        def diff(series):
            return (series[a][col]/series[m][col]-1)*100 if delta is not None and series[m][col] else None
        rows.append(dict(symbol=symbol,event=label,manual=manual[key],automatic=bars[a][0] if valid else '',days=delta,tl=diff(bars),usd=diff(usd),status=status))
    return rows

def summarize(rows):
    peaks=[r for r in rows if r['event'] in ('Sahte tepe','Gerçek tepe') and r['status']!='Referans veri dışında']
    measured=[abs(r['days']) for r in peaks if r['days'] is not None]
    return dict(total=len(peaks),matched=sum(r['status']=='Uyumlu' for r in peaks),missing=sum(r['status']=='Bulunamadı' for r in peaks),mae=sum(measured)/len(measured) if measured else None)

def export(path, rows):
    with open(path,'w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=('symbol','event','manual','automatic','days','tl','usd','status'),delimiter=';'); w.writeheader(); w.writerows(rows)
