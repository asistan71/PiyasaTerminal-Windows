@echo off
rem Ayni uygulamayi yerel agdaki cihazlara acar (telefon, tablet). Sifre yoktur: yalnizca guvendiginiz agda kullanin.
echo UYARI: Bu pencere acik oldugu surece ayni agdaki herkes terminale erisebilir.
echo Adres: http://BU_BILGISAYARIN_IP_ADRESI:8550
call "%~dp0BASLAT_WINDOWS.bat" --web --lan
exit /b %errorlevel%
