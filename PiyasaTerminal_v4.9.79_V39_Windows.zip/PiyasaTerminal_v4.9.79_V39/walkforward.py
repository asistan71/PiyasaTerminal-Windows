"""Tarihte yalnızca o güne kadar bilinen mumlarla adım adım sınama.
Bu modül yatırım sinyali oluşturmaz, geçmiş model tutarlılığını inceler.
"""

def checkpoints(n, count=12):
    if n < 65: return []
    start=max(64,n-300)
    return sorted(set(round(start+(n-1-start)*k/max(1,count-1)) for k in range(count)))

def examine(result, analyze_fn, count=12):
    bars=result['series']; fx=result['usd_series']; rows=[]
    # TL/USD'nin aynı tarihteki fiyatlarıyla araştırma: kuru tekrar bölmek gerekmez.
    # Analyze fonksiyonunun kur verisi beklentisine göre USD bölümlerinden günlük kur geri kurulur.
    rates=[]
    for b,u in zip(bars,fx):
        if u[4] <= 0: continue
        rate=b[4]/u[4]
        rates.append((b[0],rate,rate,rate,rate,0))
    from datetime import date, timedelta
    # analyze() güncel tarihteki mumu dışlar; sondaki tarihten bir gün sonrasını geçici olarak veririz.
    for last in checkpoints(len(bars),count):
        prefix=bars[:last+1]
        # analyze() bugün mumu atıyorsa son mum geçmiş günlere ait olduğundan etkilenmez.
        try:
            snapshot=analyze_fn(prefix,rates[:last+1])
        except Exception as exc:
            rows.append(dict(date=bars[last][0],status='HATA',detail=str(exc)[:150],phase='—',fake='—',real='—',frvp='—',score='—'))
            continue
        st=snapshot['structure']; ph=snapshot['phase']; n=len(prefix)
        # Her indeks yalnızca o güne kadar bilinen mumları göstermeli.
        indices=[st.get(k) for k in ('dip','fake','real','retest','signal')]
        legal=all(x is None or isinstance(x,int) and 0<=x<n for x in indices) and 0<=ph['peak']<n
        def dt(i): return prefix[i][0] if isinstance(i,int) and 0<=i<n else '—'
        rows.append(dict(date=prefix[-1][0],status='UYGUN' if legal else 'HATA',detail='İlgili tarihteki verilerle ileriye bakış denetimi' if legal else 'Gelecek indeks / geçersiz FRVP çıpası',phase=ph['phase'],fake=dt(st['fake']),real=dt(st['real']),frvp=dt(ph['peak']),score=snapshot['score']))
    for field, title in (('fake','Sahte tepe'),('real','Gerçek tepe'),('frvp','Hacim profili başlangıcı')):
        observed=[r[field] for r in rows if r['status']=='UYGUN' and r[field]!='—']
        if len(set(observed))>1:
            rows.append(dict(date='ÖZET',status='İNCELE',detail=f'{title}: {len(set(observed))} farklı tarih; değişim yeni verilerle oluşmuş olabilir, manuel kontrol gerekli',phase='—',fake='—',real='—',frvp='—',score='—'))
    return rows

def export(path,rows):
    import csv
    fields=('Hisse','Tarih','Durum','Evre','Sahte tepe','Gerçek tepe','FRVP başı','Puan','Açıklama')
    with open(path,'w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields,delimiter=';'); w.writeheader(); w.writerows(rows)
