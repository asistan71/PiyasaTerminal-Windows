"""Fiyattan bağımsız, yalnızca tamamlanmış günlük HACİM dizisi.
Çıktı: deneysel hazırlık puanı; yön / kesin kalkış tahmini değildir.
Tüm pencereler incelenen gün ile sonlanan geçmişe bakar; ileri veri kullanılmaz.
"""
from statistics import mean, median

def _avg(seq):
    return mean(seq) if seq else 0.0

def measure(bars, end=None):
    """bars: (tarih, open, high, low, close, volume), end: dahil son bar indeksi.
    Tüm fiyat alanları bilinçli şekilde kullanılmaz.
    """
    if end is None: end=len(bars)-1
    if end<0 or end>=len(bars): raise ValueError('Geçersiz son mum')
    sample=bars[:end+1]
    vol=[max(0.,float(b[5])) for b in sample]
    if len(vol)<61 or not any(vol[-60:]):
        return dict(score=None,state='Veri yetersiz',count=0,mean_gap=None,cluster=0,accel=None,contraction=None,days=len(vol),latest=sample[-1][0])
    base=vol[-61:-1] # bugün hariç 60 tamamlanmış günlük hacim
    baseline=median(x for x in base if x>0) if any(x>0 for x in base) else 0
    if baseline<=0:
        return dict(score=None,state='Veri yetersiz',count=0,mean_gap=None,cluster=0,accel=None,contraction=None,days=len(vol),latest=sample[-1][0])
    # Day-specific adaptive baseline: each day uses only its preceding 20 bars.
    spikes=[]
    start=max(20,end-59)
    for i in range(start,end+1):
        p=vol[i-20:i]; avg=_avg(p)
        if avg>0 and vol[i]>=2.0*avg: spikes.append(i)
    recent=vol[-10:]; prev=vol[-30:-10]; old=vol[-60:-30]
    m10=_avg(recent); m20=_avg(prev); m30=_avg(old)
    intervals=[b-a for a,b in zip(spikes,spikes[1:])]
    # A score composed of 4 pure-volume temporal characteristics.
    count10=sum(i>=end-9 for i in spikes)
    count30=sum(i>=end-29 for i in spikes)
    count_prev30=sum(end-59<=i<=end-30 for i in spikes)
    frequency=min(30,round(30*count30/6))
    clustering=min(25, 5*sum(g<=5 for g in intervals if g>0))
    # Acceleration of activity, not of price. Compare recent 10 with prior 20.
    acceleration=m10/m20 if m20>0 else 0.0
    acceleration_score=0 if acceleration<0.85 else min(25,round((acceleration-0.85)*20))
    # Rising frequency compared with the previous 30-day window.
    density_score=min(20,max(0,5*(count30-count_prev30)+2*count10))
    score=int(max(0,min(100,frequency+clustering+acceleration_score+density_score)))
    state='Hacim hazırlığı (aday)' if score>=70 else 'Hacim izleme' if score>=40 else 'Hacim sakin'
    return dict(score=score,state=state,count=count30,count10=count10,previous_count=count_prev30,
                mean_gap=round(_avg(intervals),2) if intervals else None,cluster=sum(g<=5 for g in intervals if g>0),
                accel=round(acceleration,2),contraction=round(m10/m30,2) if m30>0 else None,
                days=len(vol),latest=sample[-1][0],mean10=round(m10,1),mean20=round(m20,1),mean30=round(m30,1),
                median60=round(baseline,1),parts=(frequency,clustering,acceleration_score,density_score))

def timeline(bars,days=90):
    """Tarihsel rapor; her satır yalnızca o tarihe kadarki barlarla hesaplanır."""
    return [(bars[i][0],measure(bars,i)) for i in range(max(60,len(bars)-days),len(bars))]
