"""Start application, preserving console output and startup diagnostics."""
import subprocess
import sys
from pathlib import Path


def main():
    root = Path(__file__).resolve().parent
    logfile = root / 'baslatma_log.txt'
    with logfile.open('w', encoding='utf-8', errors='replace') as log:
        def emit(message):
            log.write(message + '\n')
            log.flush()
            try:
                print(message, flush=True)
            except UnicodeEncodeError:
                print(message.encode('ascii', 'replace').decode(), flush=True)
        emit('Python: ' + sys.version)
        emit('Baslatiliyor: ' + str(root))
        import os
        env = dict(os.environ, PYTHONIOENCODING='utf-8', PYTHONUNBUFFERED='1')
        try:
            proc = subprocess.Popen([sys.executable, '-u', str(root / 'piyasa_mobile.py'), *sys.argv[1:]], cwd=root, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, encoding='utf-8', errors='replace')
            for line in proc.stdout:
                emit(line.rstrip('\r\n'))
            code = proc.wait()
        except Exception:
            import traceback
            emit(traceback.format_exc())
            code = 1
        emit(f'Cikis kodu: {code}')
        return code

if __name__ == '__main__':
    raise SystemExit(main())
