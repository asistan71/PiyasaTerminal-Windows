"""Nedensel ve YAKLAŞIK günlük OHLCV hacim-profili POC hesabı.
Gerçek işlemlerden oluşturulmuş POC/VWAP yerine geçmez.
"""
from math import isfinite


def approximate_poc(bars, index, window=40, bins=48):
    if index < window - 1 or index >= len(bars):
        return None
    sample = bars[index-window+1:index+1]
    try:
        lows = [float(b[3]) for b in sample]
        highs = [float(b[2]) for b in sample]
        closes = [float(b[4]) for b in sample]
        vols = [float(b[5]) for b in sample]
        if not all(isfinite(x) for seq in (lows, highs, closes, vols) for x in seq): return None
        if any(v < 0 for v in vols): return None
        lo, hi = min(lows), max(highs)
        if lo <= 0 or hi <= lo: return None
        step=(hi-lo)/bins
        levels=[0.0]*bins
        for low, high, vol in zip(lows,highs,vols):
            if high < low: return None
            if high == low:
                levels[min(bins-1,max(0,int((low-lo)/step)))] += vol
                continue
            left = max(0, min(bins-1, int((low-lo)/step)))
            right = max(0, min(bins-1, int((high-lo)/step)))
            for j in range(left,right+1):
                overlap=max(0,min(high,lo+(j+1)*step)-max(low,lo+j*step))
                levels[j] += vol*overlap/(high-low)
        poc = lo+(max(range(bins),key=levels.__getitem__)+.5)*step
        close = closes[-1]
        diff=100*(close/poc-1)
        state=('ÜZERİNDE' if diff >= .5 else 'ALTINDA' if diff <= -.5 else 'YAKININDA')
        return {'value':round(poc,4),'distance_pct':round(diff,2),'state':state,
                'note':f'Yaklaşık POC {poc:.4f} ({state}, fark %{diff:+.2f}); günlük OHLCV dağılım tahmini, gerçek işlem profili değil'}
    except (IndexError,TypeError,ValueError,ZeroDivisionError):
        return None


COLORS={
    'ERKEN HACİMLİ UYANIŞ':'#67D6EF',
    'DİPTEN TOPARLANMA':'#A998F4',
    'KALKIŞ HAZIRLIĞI':'#F7C96D',
    'ERKEN KIRILIM TEYİDİ':'#35D69A',
    'İLK KALKIŞ HAZIRLIĞI':'#F7C96D',
    'YENİDEN BİRİKİM ADAYI':'#8CE0A3',
    'SATIŞ EMİLİMİ ADAYI':'#FB9E78',
}


def signal_color(kind):
    return COLORS.get(str(kind).upper(),'#35D69A')
