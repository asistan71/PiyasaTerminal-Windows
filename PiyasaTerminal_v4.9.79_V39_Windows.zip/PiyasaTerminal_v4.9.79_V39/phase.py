"""Deneysel, nedensel evre geçmişi; eşikler henüz doğrulanmadı."""
def phases(usd, sp):
    phase='Belirsiz'; peak=0; start=0; high=0; reached=False; locked=False; events=[]; segments=[]; cycles=0
    for i,b in enumerate(usd):
        m,s=sp[i]
        if i==0 or b[2]>usd[high][2]: high=i
        if not s or i<10: continue
        z=(b[4]-m)/s; new=None; anchor=peak; reason=''
        if phase=='Belirsiz' and z<-.5:
            new='TL'; anchor=high; reason='İlk kırmızı bant altı'
        elif phase=='TL' and z>=0:
            new='Dolar'; anchor=high; reason='USD VWAP geri kazanıldı'
        elif phase in ('Dolar','Pivot'):
            if z>=2.5: reached=True
            if reached and not locked and i>high and b[4]<usd[high][4]:
                peak=high; locked=True
            if z<-.5:
                new='TL'; anchor=high; reason='Kırmızı bant altına dönüş'
            elif reached and 0<=z<=.5 and i>high:
                new='Pivot'; anchor=high; reason='Üst bant sonrası VWAP dönüşü'; cycles+=1
        if new is not None:
            if phase!='Belirsiz': segments.append(dict(phase=phase,start=start,end=i-1,peak=peak,locked=locked))
            phase=new; start=i; peak=anchor; high=i; reached=False; locked=phase=='TL'; events.append((b[0],phase));
            # Aynı evrede ikinci zirve FRVP başlangıcını değiştirmez.
            if phase=='Pivot': locked=True
        if phase=='Belirsiz': peak=high
    segments.append(dict(phase=phase,start=start,end=len(usd)-1,peak=peak,locked=locked))
    return dict(phase=phase,peak=peak,events=events,cycles=cycles,days=len(usd)-1-start,segments=segments)

def score(phase, st, z, ratio, top30, green, target_pct, current, latest_idx):
    # Puan, olasılık değildir. Eski kalkış yeni alarm üretmez.
    a=20 if phase!='Belirsiz' else 0
    b=sum(5 for k in ('dip','fake','real','retest') if st[k] is not None)
    fresh=st['signal']==latest_idx
    c=20 if fresh else 10 if st['retest'] is not None else 0
    d=25 if green and top30 and ratio>=2.5 else 15 if green and ratio>=1.5 else 0
    e= min(15,max(0,int((target_pct or 0)/2))) if target_pct is not None else 0
    return dict(score=a+b+c+d+e,parts=(a,b,c,d,e),alarm=fresh and phase!='Belirsiz',target_pct=target_pct)
