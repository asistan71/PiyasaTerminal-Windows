"""Experimental causal daily radar and next-open backtest; independent of legacy scoring."""
from math import isfinite
from statistics import mean
from poc_context import approximate_poc


def radar(bars, benchmark=None):
    if len(bars)<71: raise ValueError('En az 71 kapanmış günlük mum gerekli.')
    bars=bars[-71:]
    if any(a[0]>=b[0] for a,b in zip(bars,bars[1:])): raise ValueError('Mum sırası geçersiz.')
    for b in bars:
        o,h,l,c,v=map(float,b[1:6])
        if not all(map(isfinite,(o,h,l,c,v))) or not (0<l<=min(o,c)<=max(o,c)<=h and v>=0): raise ValueError('OHLCV geçersiz.')
    old=bars[:-1]; last=bars[-1]; c=last[4]; v=last[5]
    avg=mean(b[5] for b in old[-20:]); rv=v/avg if avg else 0
    width=(max(b[2] for b in old[-10:])-min(b[3] for b in old[-10:]))/c
    poc=approximate_poc(bars,70); previous=approximate_poc(bars,65)
    high=max(b[2] for b in old[-20:]); low=min(b[3] for b in old[-20:]); breakout=c>high
    scores={'Hacim puanı':min(25,round(max(0,rv-0.8)*12)) if c>=last[1] else 0,
            'Sıkışma puanı':max(0,min(20,round(20*(1-width/.2)))),
            'POC puanı':(10 if poc and c>=poc['value'] else 0)+(10 if poc and previous and poc['value']>previous['value'] else 0),
            'Trend puanı':sum(5 for n in (10,30,60) if c>mean(b[4] for b in old[-n:])),
            'Kırılım puanı':10 if breakout else 0}
    # Benchmark must contain matching dates; never substitute absolute return.
    relative=None
    if benchmark:
        by={b[0]:b[4] for b in benchmark}; a=bars[-21][0]; z=last[0]
        if a in by and z in by and by[a]>0 and by[z]>0:
            relative=100*(c/bars[-21][4]-by[z]/by[a]); scores['Göreceli güç puanı']=max(0,min(10,round(relative)))
    score=sum(scores.values()); maximum=100 if relative is not None else 90
    normalized=round(score*100/maximum)
    state='Teyitli kırılım' if normalized>=80 and breakout and rv>=1.5 else 'Erken aday' if normalized>=70 and rv>=1.15 else 'İzle'
    return {'Tarih':last[0],'Puan':normalized,'Durum':state,'Fiyat':c,'Hacim oranı':round(rv,2),'POC':poc['value'] if poc else None,'Destek':low,'Direnç':high,'Göreceli güç %':relative,'Puan kapsamı':maximum,**scores,**{f'Hacim ort. {n}':round(mean(b[5] for b in old[-n:]),2) for n in (10,30,40,60,70)}}


def backtest(bars, horizon=10, target=0.10, stop=0.07, cost=0.002, threshold=70):
    if not (1<=horizon<=240 and 0<target and 0<stop<1 and 0<=cost<1): raise ValueError('Test parametreleri geçersiz.')
    trades=[]; i=70; equity=peak=1.; drawdown=0.
    while i+horizon<len(bars):
        r=radar(bars[i-70:i+1]);
        if r['Puan']<threshold or r['Durum']=='İzle': i+=1; continue
        entry=bars[i+1][1]; exit_price=bars[i+horizon][4]; reason='Süre'; end=i+horizon
        for j in range(i+1,i+horizon+1):
            _,o,h,l,c,_=bars[j]
            if o<=entry*(1-stop): exit_price=o; reason='Stop'; end=j; break
            if o>=entry*(1+target): exit_price=o; reason='Hedef'; end=j; break
            if l<=entry*(1-stop): exit_price=entry*(1-stop); reason='Stop'; end=j; break
            if h>=entry*(1+target): exit_price=entry*(1+target); reason='Hedef'; end=j; break
        ret=exit_price/entry*(1-cost)/(1+cost)-1; equity*=1+ret; peak=max(peak,equity); drawdown=max(drawdown,1-equity/peak)
        trades.append({'Tarih':bars[i][0],'Giriş tarihi':bars[i+1][0],'Çıkış tarihi':bars[end][0],'Puan':r['Puan'],'Giriş':entry,'Çıkış':exit_price,'Sonuç':reason,'Net %':round(ret*100,3)}); i=end+1
    summary={'İşlem':len(trades),'Kazanma %':round(100*sum(t['Net %']>0 for t in trades)/len(trades),2) if trades else None,'Bileşik net %':round((equity-1)*100,2),'Kapanan işlem maksimum düşüş %':round(drawdown*100,2)}
    return trades,summary
