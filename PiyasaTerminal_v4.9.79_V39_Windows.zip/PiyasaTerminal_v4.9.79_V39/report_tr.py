"""Analiz kartları ve CSV çıktısı için Türkçe rapor sunumu."""
import re

# Motor anahtarları yalnızca rapor gösterilirken dönüştürülür.
FIELDS = dict(line.split("|", 1) for line in """
symbol|Sembol
date|Tarih
score|Puan
status|Durum
state|Değerlendirme
source|Veri kaynağı
candles|Mum sayısı
signals|Sinyaller
resolved|Sonuçlanan sinyaller
wins|Hedefe ulaşanlar
failed|Başarısız sonuçlar
unknown|Sonucu belirsiz olanlar
win_rate|Başarı oranı (%)
first_signal|İlk sinyal tarihi
error|Hata açıklaması
note|Not
missing|Eksik koşullar
bars_count|Mum sayısı
volume_score|Hacim puanı
data_status|Veri durumu
listing_decision|Listeye alınma kararı
phase|Evre
recovery|Yeniden güçlenme
relative_volume|Göreceli hacim
daily_pct|Günlük değişim (%)
index|Mum sıra numarası
stage|Aşama
entry|Giriş fiyatı
rvol|Göreceli hacim (RVOL)
cluster|Hacim kümelenmesi
result_index|Sonuç mumunun sıra numarası
followed|İzlenen mum sayısı
reason|Gerekçe
reasons|Gerekçeler
kind|Sinyal türü
close|Kapanış
poc|En yoğun hacim fiyatı (POC)
poc_state|POC durumu
poc_note|POC açıklaması
outcome|Test sonucu
outcome_date|Sonuç tarihi
days|Gün sayısı
region|Bölge
count30|Son 30 seansta hacim patlaması
accel|Hacim ivmesi
entry_date|Giriş tarihi
exit_date|Çıkış tarihi
mae_pct|En olumsuz fiyat hareketi (%)
mfe_pct|En olumlu fiyat hareketi (%)
elapsed|Geçen mum sayısı
detail|Açıklama
fake|Sahte tepe
real|Gerçek tepe
frvp|Hacim profili başlangıcı (FRVP)
manual|Manuel tarih
automatic|Otomatik tarih
event|Olay
tl|TL bazında fiyat farkı (%)
usd|Dolar bazında fiyat farkı (%)
total|Toplam tepe sayısı
matched|Eşleşen tepe sayısı
mae|Ortalama mutlak gün farkı
name|Yöntem
rows|Ayrıntılı sonuçlar
change_pct|Fiyat değişimi (%)
type|Olay türü
stage_note|Aşama açıklaması
windows|İnceleme dönemleri
window_days|Dönem uzunlukları (seans)
checkpoints|Kontrol noktaları
first_alert_date|İlk uyarı tarihi
lead_days|İlk uyarıdan kalkışa kadar geçen seans
stable_alert_date|İlk kalıcı uyarı tarihi
stable_lead_days|Kalıcı uyarıdan kalkışa kadar geçen seans
alert_days|Uyarı verilen seans sayısı
threshold|Eşik
prior_date|Önceki seans tarihi
prior_score|Önceki seans puanı
launch_diagnostic|Kalkış koşullarının değerlendirmesi
absorption_signals|Satış emilimi sinyalleri
early_liftoff|Erken kalkış işaretleri
listing_audit|Listeye alınma denetimi
first_date|İlk tarih
last_date|Son tarih
lead_bars|Kalkışa kalan mum sayısı
avg_volume|Ortalama hacim
max_volume|En yüksek hacim
spike_count|Hacim patlaması sayısı
mean_spike_gap|Hacim patlamaları arası ortalama seans
spikes30|Son 30 seansta hacim patlaması
acceleration|Hacim ivmesi
candidate|Aday
asof_date|Değerlendirme tarihi
peak_score|Zirve puanı
trough_score|Dip puanı
peak_date|Zirve tarihi
trough_date|Dip tarihi
rebound|Dipten toparlanma puanı
count10|Son 10 seansta hacim patlaması
confirmed|Teyit edildi
early|Erken kalkış koşulları sağlandı
checks|Koşul kontrolleri
eligible|Kalkış koşullarını sağlıyor
blocking_date|Beklemeye neden olan tarih
distance|Seans aralığı
cooldown|Bekleme süresi
cooldown_note|Bekleme açıklaması
band_pct|Bant genişliği (%)
support|Destek
basis|Hesaplama dayanağı
count|Son 30 seansta hacim patlaması
previous_count|Önceki 30 seansta hacim patlaması
mean_gap|Patlamalar arası ortalama seans
contraction|Hacim daralma oranı
latest|Son seans tarihi
mean10|Son 10 seansın ortalama hacmi
mean20|Önceki 20 seansın ortalama hacmi
mean30|İlk 30 seansın ortalama hacmi
median60|60 seanslık ortanca hacim
parts|Puan bileşenleri (sıklık, kümelenme, ivme, yoğunluk)
lower_wick|Alt fitil
close_position|Mum aralığında kapanış konumu
confirmation_date|Teyit tarihi
KalanSeans|Kalan seans
SinyalTarihi|Sinyal tarihi
İlkUyarı|İlk uyarı
İlkKalıcıUyarı|İlk kalıcı uyarı
o|Açılış
h|En yüksek
l|En düşük
c|Kapanış
volume|Hacim
spike|Hacim artış katsayısı
volume60|60 seanslık hacme oran
quiet_ratio|Sakin dönem hacim oranı
quiet_days|Sakin seans sayısı
drop|Zirveden düşüş (%)
bottom_gap|Dibe uzaklık (%)
result|Sonuç
VAL|Değer alanı alt sınırı (VAL)
VAH|Değer alanı üst sınırı (VAH)
POC|En yoğun hacim fiyatı (POC)
""".strip().splitlines())


def heading(key, row):
    if key == "days" and "manual" in row:
        return "İşlem günü farkı"
    if key == "missing" and "matched" in row:
        return "Bulunamayan tepe sayısı"
    if key == "candles" and "result_index" in row:
        return "Sonuca kadar geçen mum sayısı"
    if key == "signals" and isinstance(row[key], int):
        return "Sinyal sayısı"
    match = re.fullmatch(r"(return|peak|drawdown|near_limit)_(\d+)", str(key))
    if match:
        names = {"return": "Kapanış getirisi (%)", "peak": "Zirve getirisi (%)",
                 "drawdown": "En düşük getiri (%)", "near_limit": "Tavana yakın kapanış sayısı"}
        return f"{match[2]} seans · {names[match[1]]}"
    return FIELDS.get(key, str(key))


def report_value(key, value):
    if isinstance(value, bool):
        return "Evet" if value else "Hayır"
    if isinstance(value, dict):
        return "\n".join(f"{k} · {v}" for k, v in translated_row(value).items() if v is not None) or "—"
    if isinstance(value, (tuple, list)):
        return " / ".join(str(report_value(key, item)) for item in value) or "—"
    if isinstance(value, str) and key in {"state", "status", "outcome", "Sonuç", "Durum"}:
        return {"OK": "Başarılı", "STOP": "Zarar durdur", "HEDEF": "Hedefe ulaştı"}.get(value, value)
    return value


def translated_row(row):
    return {heading(key, row): report_value(key, value) for key, value in row.items()}


# Satır ayrıntılarında alan önemi: 1 kritik, 2 önemli, 3 destekleyici, 4 teknik ayrıntı.
CRITICAL = {
    "symbol", "Sembol", "date", "Tarih", "score", "Puan", "status", "Durum", "state", "outcome", "result",
    "Sonuç", "error", "eligible", "confirmed", "candidate", "early", "listing_decision", "stage",
    "SinyalTarihi", "KalanSeans", "kind", "Sinyal",
}
IMPORTANT = {
    "phase", "entry", "entry_date", "exit_date", "win_rate", "wins", "failed", "resolved", "signals",
    "mfe_pct", "mae_pct", "change_pct", "daily_pct", "reason", "reasons", "missing", "rebound", "recovery",
    "poc", "POC", "VAL", "VAH", "poc_state", "rvol", "relative_volume", "spike", "accel", "acceleration",
    "lead_days", "stable_lead_days", "first_alert_date", "stable_alert_date", "İlkUyarı", "İlkKalıcıUyarı",
    "tl", "usd", "total", "matched", "confirmation_date", "drop", "bottom_gap", "volume_score", "cluster",
    "Fiyat", "Giris", "Stop", "TP1", "TP2", "TP3", "Hedef", "launch_diagnostic", "absorption_signals",
    "early_liftoff", "listing_audit", "data_status", "region", "type", "event", "count30", "spikes30",
}
TECHNICAL = {
    "o", "h", "l", "c", "volume", "index", "result_index", "candles", "bars_count", "followed", "elapsed",
    "windows", "window_days", "checkpoints", "threshold", "basis", "source", "asof_date", "prior_date",
    "prior_score", "mean10", "mean20", "mean30", "median60", "avg_volume", "max_volume", "band_pct",
    "mean_gap", "mean_spike_gap", "previous_count", "count10", "parts", "checks", "volume60", "quiet_ratio",
    "quiet_days", "lower_wick", "close_position", "cooldown", "cooldown_note", "distance", "blocking_date",
    "first_date", "last_date", "latest", "peak_date", "trough_date", "peak_score", "trough_score",
    "lead_bars", "alert_days", "spike_count", "support", "contraction", "name", "rows", "manual",
    "automatic", "stage_note", "poc_note", "note", "close", "frvp", "fake", "real", "mae",
}
TIERS = ((1, "Kritik", "#FF6B35"), (2, "Önemli", "#79A4FF"),
         (3, "Destekleyici", "#D1D4DC"), (4, "Teknik ayrıntı", "#7C8599"))


def importance(key):
    key = str(key)
    if re.fullmatch(r"(return|peak|drawdown)_\d+", key):
        return 2
    if re.fullmatch(r"near_limit_\d+", key):
        return 3
    if key in CRITICAL:
        return 1
    if key in IMPORTANT:
        return 2
    if key in TECHNICAL:
        return 4
    return 3
