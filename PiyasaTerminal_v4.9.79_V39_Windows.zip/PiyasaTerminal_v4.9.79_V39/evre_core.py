# -*- coding: utf-8 -*-
"""EVRE çekirdeği — evre.py içindeki analiz/tarama fonksiyonlarının Tkinter'siz kopyası.

analyze, spiral, profile, normalize, cached_analyze ve scan_iter gövdeleri AST ile
aynen alınmıştır. Yalnızca fetch() yeniden yazıldı: borsapy yerine data_provider.
"""
import json, math, sqlite3, threading, queue
from bisect import bisect_right
from datetime import date, datetime, timedelta
from contextlib import closing
import time, hashlib, struct, re
from collections import OrderedDict
from pathlib import Path
from statistics import mean
from structure import detect
import watch, signal_history, volume_time, market
from phase import phases, score
from opportunity import evaluate, top_candidates
from plan import make_plan
from concurrent.futures import ThreadPoolExecutor, as_completed, wait, FIRST_COMPLETED
import data_provider
ANCHOR='2020-03-18'
SYMBOLS='OZATD DURDO PEKGY ANELE NIBAS'

# Android belleği için küçük tutuldu (masaüstünde 600). Sonuçlar zaten SQLite'tan hızlı yeniden hesaplanır.
ANALYSIS_CACHE_MAX=25
_analysis_cache=OrderedDict()
_analysis_lock=threading.Lock()

def universe():
    return market.bist_symbols()

def analysis_key(bars,fx):
    today=date.today().isoformat()
    h=hashlib.sha256()
    if bars: h.update(min(b[0] for b in bars).encode('ascii'))
    for b in bars:
        if b[0]<today:
            h.update(b[0].encode('ascii')); h.update(struct.pack('!5d',*b[1:]))
    h.update(b'FX')
    for b in fx:
        if b[0]<today:
            h.update(b[0].encode('ascii')); h.update(struct.pack('!d',b[4]))
    return h.digest()

def cached_analyze(symbol,bars,fx,db,force=False):
    key=(str(Path(db).resolve()),symbol); digest=analysis_key(bars,fx)
    with _analysis_lock:
        old=_analysis_cache.get(key)
        if not force and old and old[0]==digest:
            _analysis_cache.move_to_end(key)
            return dict(old[1]),True
    result=analyze(bars,fx)
    with _analysis_lock:
        _analysis_cache[key]=(digest,result); _analysis_cache.move_to_end(key)
        while len(_analysis_cache)>ANALYSIS_CACHE_MAX: _analysis_cache.popitem(last=False)
    return dict(result),False

def scan_iter(syms, db, refresh, stop, workers=4, offline=False):
    if stop.is_set(): return
    yield ('progress','USD kuru kontrol ediliyor…')
    started=time.monotonic()
    fx=fetch('USDTRY',db,refresh,offline)
    if stop.is_set(): return
    yield ('progress',f'USD hazır ({len(fx)} gün) | BIST100 kontrol ediliyor…')
    try:
        index_bars=fetch('XU100',db,refresh,offline)
        index_state=market.index_context(index_bars)
    except Exception as e:
        index_bars=[]; index_state={'trend':'Veri yok','change_pct':None,'date':None,'error':str(e)}
    if stop.is_set(): return
    yield ('market',index_state)
    sectors=market.load_sectors(Path(__file__).with_name('sektorler.json'))
    yield ('progress',f'USD hazır ({len(fx)} gün) | Hisseler taranıyor…')
    pending={}; it=iter(syms)
    def job(s):
        with data_provider.scan_requests(stop):
            data_provider.check_stop()
            t=time.monotonic(); bars=fetch(s,db,refresh,offline); elapsed=time.monotonic()-t
            data_provider.check_stop()
        r,reused=cached_analyze(s,bars,fx,db,refresh); r=market.enrich(r,index_bars,sectors.get(s)); r['reused']=reused; r['fetch_sec']=elapsed; r['analysis_sec']=time.monotonic()-t-elapsed
        return r
    pool = ThreadPoolExecutor(max_workers=workers)
    try:
        def fill():
            while len(pending)<workers and not stop.is_set():
                s=next(it,None)
                if s is None: break
                pending[pool.submit(job,s)]=s
        fill()
        while pending and not stop.is_set():
            done,_=wait(pending,timeout=.2,return_when=FIRST_COMPLETED)
            for f in done:
                if stop.is_set(): return
                s=pending.pop(f)
                try: yield ('result',s,f.result())
                except Exception as e: yield ('error',s,str(e))
            fill()
    finally:
        pool.shutdown(wait=False, cancel_futures=True)

def spiral(bars):
    w=m=m2=0.; out=[]
    for d,o,h,l,c,v in bars:
        p=(h+l+c)/3
        if v>0:
            w+=v; delta=p-m; m+=v/w*delta; m2+=v*delta*(p-m)
        s=math.sqrt(max(0,m2/w)) if w else 0
        out.append((m,s))
    return out

def profile_levels(a, lo, step):
    n = len(a)
    p=max(range(n),key=a.__getitem__); x=y=p; total=a[p]
    threshold=sum(a)*.7
    while total<threshold and (x>0 or y<n-1):
        if y<n-1 and (x==0 or a[y+1]>=a[x-1]): y+=1; total+=a[y]
        else: x-=1; total+=a[x]
    return lo+x*step,lo+(p+.5)*step,lo+(y+1)*step

def profile_bins(bars, n=48, *, developing=None):
    """Optionally collect cumulative levels on this fixed range's price grid."""
    lo = min(b[3] for b in bars)
    hi = max(b[2] for b in bars)
    step = (hi - lo) / n
    a = [0.] * (n if step else 1)
    total = 0.
    edges = [lo+k*step for k in range(n+1)] if step else []
    last_levels = None
    for _, o, h, l, c, v in bars:
        total += v
        if v == 0:
            if developing is not None: developing.append(last_levels)
            continue
        if not step:
            a[0] += v
        else:
            i = max(0, min(n-1, int((l-lo)/step)))
            j = max(0, min(n-1, int((h-lo)/step)))
            if h == l:
                a[i] += v
            else:
                for k in range(i, j+1):
                    a[k] += v * max(0, min(h, edges[k+1]) - max(l, edges[k])) / (h-l)
        if developing is not None:
            last_levels = profile_levels(a, lo, step) if total > 0 else None
            developing.append(last_levels)
    return (*profile_levels(a, lo, step), lo, step, a)

def profile(bars,n=48):
    return profile_bins(bars,n)[:3]

def normalize(df,fx=False):
    result={}
    keys=['Close'] if fx else ['Open','High','Low','Close','Volume']
    for idx,*r in df[keys].itertuples(name=None):
        d=idx.strftime('%Y-%m-%d')
        try:
            if fx:
                c=float(r[0]); vals=(c,c,c,c,0.)
            else: vals=tuple(map(float,r))
        except (ValueError,TypeError,KeyError): continue
        if all(math.isfinite(x) for x in vals) and min(vals[:4])>0 and vals[4]>=0 and vals[2]<=min(vals[0],vals[3])<=max(vals[0],vals[3])<=vals[1]: result[d]=(d,*vals)
    return sorted(result.values())

def analyze(bars,fx,anchor=ANCHOR):
    bars=sorted(bars); first=bars[0][0]; provisional=first>anchor
    bars=[b for b in bars if b[0]>=anchor]
    if provisional: bars=bars[1:]
    # Gün içi tamamlanmamış mumu dışarıda bırak.
    bars=[b for b in bars if b[0]<date.today().isoformat()]
    if len(bars)<32: raise ValueError('En az 32 tamamlanmış günlük mum gerekli')
    rates={b[0]:b[4] for b in fx if math.isfinite(b[4]) and b[4]>0}; days=sorted(rates); usd=[]; carried=0
    for d,o,h,l,c,v in bars:
        i=bisect_right(days,d)-1
        if i<0 or (date.fromisoformat(d)-date.fromisoformat(days[i])).days>4:
            raise ValueError('USD geçmişi yetersiz: '+d+' (Veriyi yenile)')
        carried+=days[i]!=d
        f=rates[days[i]]; usd.append((d,o/f,h/f,l/f,c/f,v))
    tlsp=spiral(bars); usp=spiral(usd); m,s=usp[-1]; c=usd[-1][4]; z=(c-m)/s if s else 0
    # Evre geçişleri henüz kalibre edilmedi: sadece gözlenen bölge ve temas geçmişi.
    region='TL adayı' if z<-.5 else 'VWAP çevresi' if z<=.5 else 'Üst bant'
    last=bars[-1]; prev=bars[-31:-1]; v=last[5]; avg=mean(b[5] for b in prev); ratio=v/avg if avg else 0
    green=last[4]>last[1]; top10=v>max(b[5] for b in prev[-10:]); top30=v>max(b[5] for b in prev)
    launch=green and top30 and ratio>=2.5
    # İlk ana zirve için geçici aday: mevcut geçmişin en yüksek önceki zirvesi.
    ph=phases(usd,usp); peak=ph['peak']; val,poc,vah=profile(bars[peak:]); tm,ts=tlsp[-1]
    structure=detect(bars,peak,profile)
    plan=make_plan(bars,tlsp,ph,structure)
    target=plan["target"]
    # Üst evre hedefleri önceki bant temaslarıyla ayrıca kalibre edilecek.
    sc=score(ph["phase"],structure,z,ratio,top30,green,(target/last[4]-1)*100 if target else None,last[4],len(bars)-1)
    result = dict(plan=plan,phase=ph,**sc,structure=structure,carried=carried,date=last[0],anchor=bars[0][0],provisional=provisional,region=region,z=z,price=last[4],usd=c,vwap=tm,usd_vwap=m,ratio=ratio,top10=top10,top30=top30,launch=launch,peak=bars[peak][0],val=val,poc=poc,vah=vah,series=bars,tlsp=tlsp,usp=usp,usd_series=usd)

    result["volume_time"]=volume_time.measure(bars)
    result["opportunity"]=evaluate(result)
    return result


def stock_history(symbol,cached,full):
    """Yeni geçmiş: 45 günlük örtüşme tutarlıysa birleştir, değilse tam geçmiş (özgün mantık)."""
    if cached and not full:
        begin=(date.fromisoformat(cached[-1][0])-timedelta(days=45)).isoformat()
        try:
            new=normalize(data_provider.daily_df(symbol,start=begin,end=date.today().isoformat()))
            old={b[0]:b for b in cached if begin<=b[0]<date.today().isoformat()}
            fresh={b[0]:b for b in new if begin<=b[0]}
            if old and new and all(fresh.get(d)==b for d,b in old.items()) and new[-1][0]>=max(old):
                merged={b[0]:b for b in cached}; merged.update(fresh)
                return sorted(merged.values()),False
        except Exception:
            pass
    return normalize(data_provider.daily_df(symbol,start=None,end=None)),True

def fetch(symbol, db, force=False, offline=False):
    with closing(sqlite3.connect(db,timeout=10)) as con, con:
        con.execute('CREATE TABLE IF NOT EXISTS bars (symbol TEXT,d TEXT,o REAL,h REAL,l REAL,c REAL,v REAL, PRIMARY KEY(symbol,d))')
        con.execute('CREATE TABLE IF NOT EXISTS updates (symbol TEXT PRIMARY KEY,day TEXT)')
        con.execute('CREATE TABLE IF NOT EXISTS full_checks (symbol TEXT PRIMARY KEY,day TEXT)')
        old=con.execute('SELECT day FROM updates WHERE symbol=?',(symbol,)).fetchone()
        cached=con.execute('SELECT d,o,h,l,c,v FROM bars WHERE symbol=? ORDER BY d',(symbol,)).fetchall()
        coarse=bool(cached) and not offline and data_provider.is_coarse(cached)  # eski haftalık kayıt: günlükle değiştir
        if coarse: force=True
        today=date.today().isoformat()
        con.execute('CREATE TABLE IF NOT EXISTS daily_history_verified (symbol TEXT PRIMARY KEY)')
        verified = con.execute('SELECT 1 FROM daily_history_verified WHERE symbol=?',(symbol,)).fetchone()
        legacy_daily = False
        if cached and not verified:
            dates = [date.fromisoformat(bar[0]) for bar in cached]
            gaps = [(b-a).days for a,b in zip(dates, dates[1:])]
            # A legacy weekly prefix can be followed by a later daily refresh.
            legacy_daily = bool(gaps) and any(gap < 5 for gap in gaps[:20]) and any(gap < 5 for gap in gaps[-20:])
        if offline:
            if cached and not (verified or legacy_daily):
                raise ValueError("Günlük mumları yüklemek için kayıtlı veri seçeneğini kapatıp raporu tekrar çalıştırın.")
            if not cached: raise ValueError("Önbellekte veri yok; normal tarama gerekli")
            return cached
        if verified and cached and old and old[0]==today and not force and (symbol!='USDTRY' or cached[0][0]<='2020-03-18'): return cached
        if symbol=='USDTRY':
            data=normalize(data_provider.daily_df('USDTRY',start='2020-03-01',end=None),True)
            was_full=True
            if not data: raise ValueError('USD kuru alınamadı')
        else:
            last_full=con.execute('SELECT day FROM full_checks WHERE symbol=?',(symbol,)).fetchone()
            full=not verified or force or not last_full or (date.today()-date.fromisoformat(last_full[0])).days>=7
            data,was_full=stock_history(symbol,cached,full)
        if symbol!='USDTRY':
            data=[b for b in data if b[0]<today]
            cached=[b for b in cached if b[0]<today]
        if not data: raise ValueError('Veri boş veya geçersiz')
        if (verified or legacy_daily) and not coarse and cached and (data[0][0]>cached[0][0] or data[-1][0]<cached[-1][0]): raise ValueError('Yeni geçmiş öncekinden kısa; kayıt korunuyor')
        if symbol=='USDTRY' and data[-1][0] < (date.today()-timedelta(days=4)).isoformat(): raise ValueError('USD kuru güncel değil; tekrar deneyin')
        if symbol=='USDTRY' or was_full:
            con.execute('DELETE FROM bars WHERE symbol=?',(symbol,)); changed=data
        else:
            con.execute('DELETE FROM bars WHERE symbol=? AND d>=?',(symbol,today))
            old_bars={b[0]:b for b in cached}
            changed=[b for b in data if old_bars.get(b[0])!=b]
        con.executemany('INSERT OR REPLACE INTO bars VALUES (?,?,?,?,?,?,?)',[(symbol,*b) for b in changed])
        if symbol!='USDTRY' and was_full:
            con.execute('INSERT OR REPLACE INTO full_checks VALUES (?,?)',(symbol,today))
        con.execute('INSERT OR IGNORE INTO daily_history_verified VALUES (?)',(symbol,))
        con.execute('INSERT OR REPLACE INTO updates VALUES (?,?)',(symbol,today))
        return data


MARK_KEYS=('dip','fake','real','retest','signal')

def slim(r, keep=320):
    """Telefon belleği için sonucu küçült: son `keep` mum + yapı işaretlerini TARİH olarak sakla.
    (yapı indeksleri tam seriye göredir; kırpmadan önce tarihe çevrilir)"""
    out=dict(r); series=r['series']
    st=r['structure']
    out['marks']={k:series[st[k]][0] for k in MARK_KEYS if st.get(k) is not None and st[k]<len(series)}
    out['series']=series[-keep:]; out['tlsp']=r['tlsp'][-keep:]
    for k in ('usp','usd_series'): out.pop(k,None)
    return out


def fetch_backtest_history(symbol, db, offline=False):
    """Read the same daily, completed BIST candles as the EVRE scanner.

    Network failures may fall back to an existing local cache, clearly flagged
    so users do not mistake cached data for a live refresh.
    """
    symbol = str(symbol).strip().upper()
    if not re.fullmatch(r'[A-Z0-9]{1,12}', symbol):
        raise ValueError('Geçerli bir BIST hisse kodu gerekli')
    try:
        series = fetch(symbol, db, force=False, offline=offline)
        source = 'SQLite önbelleği (çevrimdışı)' if offline else 'EVRE fetch / günlük veri'
    except Exception as exc:
        if offline:
            raise
        try:
            series = fetch(symbol, db, force=False, offline=True)
        except Exception:
            raise RuntimeError(f'{symbol} günlük verileri alınamadı: {exc}') from exc
        source = f'ÖNBELLEK (canlı veri alınamadı: {exc})'
    today = date.today().isoformat()
    # The EVRE signal engine takes (date, open, high, low, close, volume).
    series = sorted((tuple(b) for b in series if b[0] < today), key=lambda b: b[0])
    if len(series) < 35:
        raise ValueError(f'{symbol} için {len(series)} tamamlanmış günlük mum var; en az 35 gerekli.')
    return series, source


