# -*- coding: utf-8 -*-
"""Kendi kendini güncelleme: yeni sürümü indirir veya ZIP dosyasından alır, kodu değiştirir, yeniden başlatır.

Yalnızca standart kütüphane kullanır. Kullanıcı verisi (favoriler, işlemler, SQLite arşivleri) kod klasörünün
dışında durur; `.venv` klasörü ve önbellekler de güncellemede korunur. Her güncellemeden önce değişen dosyaların
yedeği alınır ve "Önceki sürüme dön" ile geri yüklenebilir.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import subprocess
import sys
import time
import zipfile
from pathlib import Path
from urllib.parse import urljoin, urlparse
from urllib.request import Request, urlopen

RESTART_CODE = 75
APP_DIR = Path(__file__).resolve().parent
KEEP_BACKUPS = 5
MAX_ZIP_BYTES = 200 * 1024 * 1024

# Güncelleme paketinde bulunmak zorunda olan dosyalar: eksik veya iskelet paket asla uygulanmaz.
REQUIRED_FILES = ("piyasa_mobile.py", "version.py", "requirements.txt", "chart_workshop.py",
                  "evre_core.py", "data_provider.py", "terminal_core.py", "updater.py")
PROTECTED_DIRS = {".venv", "venv", "__pycache__", "yedek", "guncelleme", "exports", ".git"}
PROTECTED_SUFFIXES = {".sqlite3", ".db", ".log", ".pyc", ".yeni"}
META_NAME = "__guncelleme__.json"
USER_AGENT = "PiyasaTerminali-Updater/1.0"


class UpdateError(Exception):
    """Kullanıcıya olduğu gibi gösterilebilecek güncelleme hatası."""


# ---------------------------------------------------------------- sürüm
def parse_version(text) -> tuple:
    found = re.findall(r"\d+", str(text))
    return tuple(int(part) for part in found[:4]) if found else ()


def version_from_filename(name: str) -> str | None:
    match = re.search(r"[vV](\d+(?:[._]\d+)+)", name)
    return match.group(1).replace("_", ".") if match else None


def is_newer(candidate, current) -> bool:
    return bool(parse_version(candidate)) and parse_version(candidate) > parse_version(current)


def installed_version(app_dir: Path | None = None) -> str:
    path = Path(app_dir or APP_DIR) / "version.py"
    try:
        match = re.search(r"""(?:APP_VERSION|__version__)\s*=\s*["']([^"']+)["']""", path.read_text(encoding="utf-8"))
    except OSError:
        match = None
    return match.group(1) if match else "0"


# ---------------------------------------------------------------- ağ
def _read(url: str, timeout: int = 20) -> bytes:
    if urlparse(url).scheme not in ("http", "https"):
        raise UpdateError("Yalnızca http ve https adresleri desteklenir.")
    try:
        with urlopen(Request(url, headers={"User-Agent": USER_AGENT}), timeout=timeout) as response:
            return response.read()
    except Exception as exc:
        raise UpdateError(f"Adrese ulaşılamadı: {exc}") from exc


def fetch_manifest(source: str) -> dict:
    """`github:kullanici/depo` veya bir manifest.json adresi. {version, url, sha256, notes} döndürür."""
    source = source.strip()
    if not source:
        raise UpdateError("Güncelleme adresi girilmemiş.")
    if source.lower().startswith("github:"):
        repo = source[7:].strip("/ ")
        if not re.fullmatch(r"[\w.-]+/[\w.-]+", repo):
            raise UpdateError("GitHub adresi kullanici/depo biçiminde olmalı.")
        release = json.loads(_read(f"https://api.github.com/repos/{repo}/releases/latest"))
        assets = [a for a in release.get("assets", []) if str(a.get("name", "")).lower().endswith(".zip")]
        if not assets:
            raise UpdateError("Son sürümde ZIP dosyası yok.")
        asset = next((a for a in assets if re.fullmatch(r"PiyasaTerminal_v[0-9.]+_V39_Windows\.zip", str(a["name"]), re.I)), None)
        if asset is None:
            raise UpdateError("Son GitHub yayınında Windows terminal paketi bulunamadı.")
        digest = str(asset.get("digest") or "")
        return {"version": str(release.get("tag_name", "")).lstrip("vV"), "url": asset["browser_download_url"],
                "sha256": digest.split(":", 1)[1] if digest.startswith("sha256:") else "",
                "notes": str(release.get("body") or "")[:1500]}
    try:
        manifest = json.loads(_read(source).decode("utf-8-sig"))
        version, url = str(manifest["version"]), str(manifest["url"])
    except (ValueError, KeyError) as exc:
        raise UpdateError("manifest.json okunamadı: 'version' ve 'url' alanları gerekli.") from exc
    return {"version": version, "url": urljoin(source, url),
            "sha256": str(manifest.get("sha256") or "").lower(), "notes": str(manifest.get("notes") or "")[:1500]}


def check(source: str, current: str) -> dict:
    manifest = fetch_manifest(source)
    manifest["current"] = current
    manifest["available"] = is_newer(manifest["version"], current)
    return manifest


def check_chatgpt_channel(source: str, current: str) -> dict:
    """Check a configured publication channel, not a ChatGPT conversation."""
    source = source.strip()
    if not source:
        raise UpdateError("Önce yayın kanalını ayarlayın: github:kullanici/depo veya HTTPS manifest adresi.")
    if not source.lower().startswith("github:") and urlparse(source).scheme != "https":
        raise UpdateError("İnternet güncellemeleri için HTTPS gereklidir.")
    info = check(source, current)
    if not re.fullmatch(r"\d+\.\d+\.\d+", info["version"]):
        raise UpdateError("Geçersiz sürüm numarası.")
    if info["available"]:
        if urlparse(info["url"]).scheme != "https":
            raise UpdateError("Paket adresi HTTPS olmalıdır.")
        if not re.fullmatch(r"[a-fA-F0-9]{64}", info.get("sha256", "")):
            raise UpdateError("Yayın paketinin SHA-256 özeti eksik veya geçersiz.")
    return info


def install_checked_release(info, current, dest, progress=None, app_dir=None, backup_dir=None):
    if not is_newer(info.get("version", ""), current):
        raise UpdateError("Paket yeni sürüm değil.")
    if urlparse(info["url"]).scheme != "https" or not re.fullmatch(r"[a-fA-F0-9]{64}", info.get("sha256", "")):
        raise UpdateError("Güvenli paket adresi veya SHA-256 özeti eksik.")
    path = download(info["url"], dest, progress, info["sha256"])
    _, version = inspect_zip(path)
    if version != info["version"] or not is_newer(version, installed_version(app_dir)):
        raise UpdateError("Paket sürümü yayın bilgisiyle uyuşmuyor veya kurulu sürümden yeni değil.")
    return apply_zip(path, app_dir=app_dir, backup_dir=backup_dir)


def download(url: str, dest: Path, progress=None, sha256: str = "", timeout: int = 30) -> Path:
    if urlparse(url).scheme not in ("http", "https"):
        raise UpdateError("Yalnızca http ve https adresleri desteklenir.")
    dest = Path(dest)
    dest.parent.mkdir(parents=True, exist_ok=True)
    digest, size = hashlib.sha256(), 0
    partial = dest.with_suffix(dest.suffix + ".kismi")
    try:
        with urlopen(Request(url, headers={"User-Agent": USER_AGENT}), timeout=timeout) as response, \
                open(partial, "wb") as out:
            total = int(response.headers.get("Content-Length") or 0)
            while True:
                chunk = response.read(64 * 1024)
                if not chunk:
                    break
                size += len(chunk)
                if size > MAX_ZIP_BYTES:
                    raise UpdateError("Güncelleme dosyası beklenenden büyük.")
                digest.update(chunk)
                out.write(chunk)
                if progress and total:
                    progress(min(1.0, size / total))
    except UpdateError:
        partial.unlink(missing_ok=True)
        raise
    except Exception as exc:
        partial.unlink(missing_ok=True)
        raise UpdateError(f"İndirilemedi: {exc}") from exc
    if sha256 and digest.hexdigest().lower() != sha256.lower():
        partial.unlink(missing_ok=True)
        raise UpdateError("İndirilen dosyanın sha256 özeti manifest ile uyuşmuyor; güncelleme iptal edildi.")
    partial.replace(dest)
    if progress:
        progress(1.0)
    return dest


# ---------------------------------------------------------------- ZIP denetimi
def _safe(name: str) -> bool:
    path = Path(name.replace("\\", "/"))
    return not (path.is_absolute() or ".." in path.parts or ":" in name)


def inspect_zip(zip_path) -> tuple[str, str]:
    """(klasör öneki, sürüm). Geçerli bir tam paket değilse UpdateError."""
    try:
        archive = zipfile.ZipFile(zip_path)
    except (zipfile.BadZipFile, OSError) as exc:
        raise UpdateError(f"ZIP dosyası açılamadı: {exc}") from exc
    with archive:
        names = [n.replace("\\", "/") for n in archive.namelist()]
        if not all(_safe(n) for n in names):
            raise UpdateError("ZIP güvenli olmayan yollar içeriyor; reddedildi.")
        roots = [n[:-len("piyasa_mobile.py")] for n in names
                 if n.endswith("piyasa_mobile.py") and n.count("/") <= 1]
        if not roots:
            raise UpdateError("Bu ZIP bir Piyasa Terminali paketi değil (piyasa_mobile.py yok).")
        prefix = min(roots, key=len)
        missing = [name for name in REQUIRED_FILES if prefix + name not in names]
        if missing:
            raise UpdateError("Paket eksik, uygulanmadı. Eksik dosyalar: " + ", ".join(missing))
        text = archive.read(prefix + "version.py").decode("utf-8", "ignore")
    match = re.search(r"""(?:APP_VERSION|__version__)\s*=\s*["']([^"']+)["']""", text)
    if not match:
        raise UpdateError("Paketin sürüm numarası okunamadı.")
    return prefix, match.group(1)


def _members(archive: zipfile.ZipFile, prefix: str):
    for info in archive.infolist():
        name = info.filename.replace("\\", "/")
        if info.is_dir() or not name.startswith(prefix):
            continue
        relative = name[len(prefix):]
        parts = Path(relative).parts
        if not parts or PROTECTED_DIRS & set(parts) or Path(relative).suffix.lower() in PROTECTED_SUFFIXES:
            continue
        yield info, relative


# ---------------------------------------------------------------- uygulama ve geri alma
def _prune(backup_dir: Path):
    backups = sorted(backup_dir.glob("yedek_v*.zip"), key=lambda p: p.stat().st_mtime, reverse=True)
    for old in backups[KEEP_BACKUPS:]:
        old.unlink(missing_ok=True)


def _restore(backup_zip: Path, app_dir: Path):
    with zipfile.ZipFile(backup_zip) as archive:
        meta = json.loads(archive.read(META_NAME))
        for name in archive.namelist():
            if name != META_NAME and _safe(name):
                target = app_dir / name
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(archive.read(name))
    for relative in meta.get("added", []):
        (app_dir / relative).unlink(missing_ok=True)
    return meta


def apply_zip(zip_path, app_dir=None, backup_dir=None) -> dict:
    app_dir = Path(app_dir or APP_DIR)
    backup_dir = Path(backup_dir or app_dir / "yedek")
    prefix, new_version = inspect_zip(zip_path)
    old_version = installed_version(app_dir)
    backup_dir.mkdir(parents=True, exist_ok=True)
    backup_zip = backup_dir / f"yedek_v{old_version}_{time.strftime('%Y%m%d_%H%M%S')}.zip"
    old_requirements = (app_dir / "requirements.txt").read_bytes() if (app_dir / "requirements.txt").exists() else b""

    with zipfile.ZipFile(zip_path) as archive:
        members = list(_members(archive, prefix))
        added = [relative for _, relative in members if not (app_dir / relative).exists()]
        with zipfile.ZipFile(backup_zip, "w", zipfile.ZIP_DEFLATED) as backup:
            for _, relative in members:
                if (app_dir / relative).exists():
                    backup.write(app_dir / relative, relative)
            backup.writestr(META_NAME, json.dumps({"old_version": old_version, "new_version": new_version,
                                                   "added": added}))
        try:
            for info, relative in members:
                target = app_dir / relative
                target.parent.mkdir(parents=True, exist_ok=True)
                pending = target.with_name(target.name + ".yeni")
                pending.write_bytes(archive.read(info))
                os.replace(pending, target)
            new_requirements = (app_dir / "requirements.txt").read_bytes()
        except Exception as exc:
            _restore(backup_zip, app_dir)
            raise UpdateError(f"Dosyalar yazılamadı, eski sürüm geri yüklendi: {exc}") from exc
    _prune(backup_dir)
    return {"old": old_version, "new": new_version, "files": len(members), "added": len(added),
            "requirements_changed": old_requirements != new_requirements, "backup": str(backup_zip)}


def latest_backup(backup_dir) -> Path | None:
    backups = sorted(Path(backup_dir).glob("yedek_v*.zip"), key=lambda p: p.stat().st_mtime, reverse=True)
    return backups[0] if backups else None


def rollback_latest(app_dir=None, backup_dir=None) -> dict:
    app_dir = Path(app_dir or APP_DIR)
    backup_dir = Path(backup_dir or app_dir / "yedek")
    backup = latest_backup(backup_dir)
    if backup is None:
        raise UpdateError("Geri dönülecek yedek yok.")
    meta = _restore(backup, app_dir)
    backup.unlink(missing_ok=True)
    return {"old": meta.get("new_version", ""), "new": meta.get("old_version", ""), "rollback": True}


def find_local_updates(folders, current: str) -> list[dict]:
    """Klasörlerdeki PiyasaTerminal*.zip dosyalarından, kurulu sürümden yeni ve geçerli olanlar (yeniden eskiye)."""
    found = {}
    for folder in folders:
        folder = Path(folder)
        if not folder.is_dir():
            continue
        for path in folder.glob("PiyasaTerminal*.zip"):
            try:
                _, version = inspect_zip(path)
            except UpdateError:
                continue
            if is_newer(version, current) and (version not in found or path.stat().st_mtime > found[version]["mtime"]):
                found[version] = {"version": version, "path": str(path), "mtime": path.stat().st_mtime}
    return sorted(found.values(), key=lambda item: parse_version(item["version"]), reverse=True)


# ---------------------------------------------------------------- yeniden başlatma
def restart():
    """BASLAT_WINDOWS.bat 75 koduyla çıkışı görünce uygulamayı yeniden açar; başka yerde kendini yeniden başlatır."""
    if os.environ.get("PIYASA_LAUNCHER") == "1":
        os._exit(RESTART_CODE)
    subprocess.Popen([sys.executable, *sys.argv], cwd=str(APP_DIR))
    os._exit(0)
