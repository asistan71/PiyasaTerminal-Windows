@echo off
setlocal
title Piyasa Terminali v4.9.75 V39
pushd "%~dp0" || goto :error
if not exist "piyasa_mobile.py" goto :missing_files
if not exist "requirements.txt" goto :missing_files

set "VENV_PY=.venv\Scripts\python.exe"
if not exist "%VENV_PY%" goto :create_venv

rem Daha once olusmus sanal ortamda pip eksik veya bozuk olabilir.
"%VENV_PY%" -m pip --version >nul 2>&1
if not errorlevel 1 goto :packages
echo Sanal ortamda pip bulunamadi. Onariliyor...
"%VENV_PY%" -m ensurepip --upgrade >nul 2>&1
"%VENV_PY%" -m pip --version >nul 2>&1
if not errorlevel 1 goto :packages
echo Onarilamadi. Sanal ortam bastan olusturuluyor...
rmdir /s /q ".venv" >nul 2>&1
if exist ".venv" goto :venv_locked

:create_venv
where py >nul 2>&1
if errorlevel 1 goto :try_python
py -3.12 -c "import sys" >nul 2>&1
if errorlevel 1 goto :try_launcher
py -3.12 -m venv .venv
if errorlevel 1 goto :error
goto :dependencies

:try_launcher
py -3 -c "import sys; assert sys.version_info >= (3, 10)" >nul 2>&1
if errorlevel 1 goto :try_python
py -3 -m venv .venv
if errorlevel 1 goto :error
goto :dependencies

:try_python
python -c "import sys; assert sys.version_info >= (3, 10)" >nul 2>&1
if errorlevel 1 goto :missing_python
python -m venv .venv
if errorlevel 1 goto :error

:dependencies
"%VENV_PY%" -m pip --version >nul 2>&1
if not errorlevel 1 goto :packages
"%VENV_PY%" -m ensurepip --upgrade
"%VENV_PY%" -m pip --version >nul 2>&1
if errorlevel 1 goto :no_pip

:packages
rem Paketler yalnizca ilk kurulumda veya requirements.txt degistiginde kurulur.
"%VENV_PY%" kurulum_kontrol.py
if not errorlevel 1 goto :start
echo Gerekli paketler kuruluyor. Ilk kurulum icin internet gerekir.
"%VENV_PY%" -m pip --disable-pip-version-check install -r requirements.txt "flet[desktop]==1.1.3"
if errorlevel 1 goto :error
"%VENV_PY%" kurulum_kontrol.py --kaydet

:start
set "PIYASA_LAUNCHER=1"
echo Piyasa Terminali aciliyor...
"%VENV_PY%" -u "baslat_teshis.py" %*
set "EXIT_CODE=%errorlevel%"
if "%EXIT_CODE%"=="75" goto :restart
if not "%EXIT_CODE%"=="0" goto :error
echo Program kapandi. Ayrinti: baslatma_log.txt
pause
popd
exit /b 0

:restart
echo.
echo Guncelleme uygulandi. Yeniden baslatiliyor...
goto :packages

:missing_files
echo ZIP dosyasina sag tiklayip Tumunu ayikla secenegini kullanin.
goto :error

:missing_python
echo Python 3.10 veya daha yeni bir surum bulunamadi. Python 3.12 onerilir.
goto :error

:venv_locked
echo .venv klasoru silinemedi. Acik pencereleri kapatip .venv klasorunu elle silin, sonra tekrar deneyin.
goto :error

:no_pip
echo Bu Python kurulumunda pip yok. python.org adresinden Python 3.12 kurun,
echo kurulumda "pip" secenegini isaretleyin, sonra .venv klasorunu silip tekrar deneyin.
goto :error

:error
echo.
echo Terminal acilamadi. Yukaridaki hata mesajini kontrol edin.
echo Varsa baslatma_log.txt dosyasini paylasin.
pause
exit /b 1
